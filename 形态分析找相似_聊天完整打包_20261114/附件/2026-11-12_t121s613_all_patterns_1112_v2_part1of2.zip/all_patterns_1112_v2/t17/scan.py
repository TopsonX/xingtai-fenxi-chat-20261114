from pathlib import Path
import pandas as pd,numpy as np,json,re,collections,multiprocessing as mp,time
O=Path('/workspace/fuyao/all_patterns_1112_v2/t17');D=Path('/workspace/fuyao/market_daily');OLD=Path('/workspace/fuyao/ma_coil_600821_1108');ASOF='2026-11-12';W=[5,10,20,45,60,180]
q=json.load(open('/workspace/fuyao/summary_1104/qt_all.json'));names={k:v[1] for k,v in q.items() if isinstance(v,list) and len(v)>1}
old=json.load(open(OLD/'summary.json'))['scan'];STALE={r['code'] for r in old['stale'] if r['last']<'2026-09-01' or not (q.get(r['code'],['']*61)+['']*61)[60].strip()}
calendar=pd.read_csv(D/'sh601398.csv').date.tolist();calpos={dt:i for i,dt in enumerate(calendar)}
THRESHOLDS={
 '均线与窗口':'收盘简单MA5/10/20/45/60/180全序列计算后切图；六线离散=max/min−1。前粘合固定取破位前120根（另测180根供核对），不将洗盘期混入前粘合窗口。',
 '前粘合共同入口':'前120日离散中位≤7.5%，≤8%占比≥60%，高/低−1≤40%，MA180前60根变化绝对值≤8%；破位前一根离散≤8%，收盘/MA180在0.94～1.08。',
 '破位定义':'当日收盘跌幅≤−2%，或近3根累计≤−3%；并且收盘低于MA20及1.01×MA180。从满足条件日作为候选起点；多起点时优先最早的有效结构。',
 '阴跌结构':'破位至已见最低价15～50根（含首尾），低点相对破位前收盘跌4%～22%，且跌5%～18%或相对破位前30日高点跌8%～20%；相对该高点不超22%；起点第4根至低点期间收盘不得完整收复破位前收盘（防止把早先已修复下跌误拼作本段）。低价≤破位前40根最低×1.005（阶段新低）。低点日收盘/MA180−1在−12%～−2%；MA5/10/20均低于MA180，MA5<MA20，MA5较5根前下降、MA20较10根前下降。',
 '打开与缩量':'截至低点的最大六线离散≥破位前离散×1.15且至少增0.5个百分点；洗盘MA180变化绝对值≤5%；破位至低点≥60%收盘在MA20下；剔除破位日和一根最大量后，阴跌成交量中位≤破位前40根中位。',
 '当前对齐':'破位至锚点≤65根；低点距锚点≤15根或收盘距该最低价≤3%；收盘相对低点日收盘升幅≤12%；低后曾有最高价相对低点日收盘升幅>18%则已离段、剔除；收盘/MA180在0.88～1.06，20/60日收益≤12%/20%，前180根最高/当前MA180≤1.50，最近300根有效。',
 '更贴':'前120日离散中位≤5.5%、紧密占比≥80%、箱体≤30%、|MA180前60根变化|≤5%；前收盘至低价跌6%～15%、阴跌20～40根、低点收盘偏离MA180在−8%～−3%；MA5高于5根前且收盘≥MA5；低点距锚点≤10根或距最低价≤2.5%；从低点收盘升幅≤8%、当日离散≤14%。',
 '次贴':'未达更贴；前120日中位≤6.5%、紧密占比≥70%、箱体≤35%、|MA180前60根变化|≤7%；前收盘至低价跌5%～18%、阴跌15～50根、低点偏离−10%～−2%；已经MA5上拐收复MA5，或仍距最低价≤3%且处于阴跌末段。',
 '观察':'仅满足共同入口及当前对齐；不为填满层级而放宽。技术层级不等于基本面评级或上涨概率。',
 '历史取点与去重':'与当前完全相同的前粘合/阴跌/对齐结构，另要求MA5高于5根前、收盘≥MA5且低点至少在1根以前，取第一个合格拐头锚点。按时间先后每股60根冷却，后续涨幅不参与入选。低点是当时已见最低，不借未来倒找最终最低。最近尚无完整10/20/40根后续的事件仍保留，分期限剔除未成熟分母。',
 '连续性与排除':'以工商银行交易日历，前粘合起点前180根至锚点之间相邻记录缺失>3个市场交易日则剔除；后验各期限另查未来连续性。ST/*ST/名称含退、北交所、长期停更/报价失效18只排除；最新不足基准日不入当前。名称标签为当前快照，历史ST状态无法完整复原。',
 '后验观察':'入选后才计算10/20/40根最高/锚点收盘−1（MFE）、最低/锚点收盘−1（MAE）、期末收益；报告MFE≥10%/20%/35%/60%比例、MAE≤−10%比例，均是样本描述非预测胜率。',
 '层内排序':'100−200×前120日离散中位−35×箱体−100×|低点偏离+6.4%|−70×|深度−8%|−0.25×|阴跌根数−29|+8×紧密占比+3×已拐头−30×从低点抬升；不使用资金流、筹码、龙虎榜或未来涨幅。'}
def prep(p):
 d=pd.read_csv(p).sort_values('date').drop_duplicates('date',keep='last');d=d[d.date<=ASOF].copy().reset_index(drop=True)
 for k in ['open','high','low','close','vol']:d[k]=pd.to_numeric(d[k],errors='coerce')
 bad=d[['open','high','low','close','vol']].isna().any(axis=1)|(d.low<=0)|(d.high<d.low)|(d.vol<=0)|(d.high<d[['open','close']].max(axis=1))|(d.low>d[['open','close']].min(axis=1))
 d.loc[bad,['open','high','low','close','vol']]=np.nan
 for w in W:d['ma'+str(w)]=d.close.rolling(w).mean()
 ma=d[['ma'+str(w)for w in W]];d['spread']=ma.max(axis=1)/ma.min(axis=1)-1;d.loc[d.ma180.isna(),'spread']=np.nan
 for n in [120,180]:
  d['med'+str(n)]=d.spread.rolling(n).median();d['tight'+str(n)]=(d.spread<=.08).rolling(n).mean();d['range'+str(n)]=d.high.rolling(n).max()/d.low.rolling(n).min()-1
 d['slope60']=d.ma180/d.ma180.shift(60)-1;d['ret20']=d.close/d.close.shift(20)-1;d['ret60']=d.close/d.close.shift(60)-1;d['peak180']=d.high.rolling(180).max()/d.ma180
 d['vol20']=d.vol.rolling(20).mean();d['valid300']=d.close.rolling(300).count()==300
 pos=np.array([calpos.get(x,-100000)for x in d.date]);gap=np.r_[False,np.diff(pos)>4];d['gapcum']=np.cumsum(gap)
 return d,int(bad.sum())
def structure(a,s,t):
 p=s-1;lo=a['low'][s:t+1]
 if not np.isfinite(lo).all():return
 l=s+int(np.argmin(lo));dur=l-s+1;age=t-l
 if not 15<=dur<=50:return
 ref=a['close'][p];low=a['low'][l];dep=1-low/ref;swing=1-low/np.max(a['high'][s-30:s])
 if not (.04<=dep<=.22 and (.05<=dep<=.18 or .08<=swing<=.20) and swing<=.22):return
 if low>np.min(a['low'][s-40:s])*1.005:return
 # A fully recovered selloff is not the start of this wash. Prevent unrelated earlier dips from swallowing the red box.
 if np.max(a['close'][s+3:l+1])>=ref:return
 bias=a['close'][l]/a['ma180'][l]-1
 if not -.12<=bias<=-.02:return
 if not (max(a['ma5'][l],a['ma10'][l],a['ma20'][l])<a['ma180'][l] and a['ma5'][l]<a['ma20'][l] and a['ma5'][l]<a['ma5'][l-5] and a['ma20'][l]<a['ma20'][l-10]):return
 mx=np.max(a['spread'][s:l+1]);pre=a['spread'][p]
 if mx<max(pre*1.15,pre+.005):return
 slope=a['ma180'][l]/a['ma180'][s]-1
 if abs(slope)>.05:return
 under=np.mean(a['close'][s:l+1]<a['ma20'][s:l+1])
 if under<.6:return
 vols=a['vol'][s+1:l+1];grind=float(np.median(np.delete(vols,np.argmax(vols))));vprior=float(np.median(a['vol'][s-40:s]));vr=grind/vprior
 if vr>1:return
 lift=a['close'][t]/a['close'][l]-1;near=a['close'][t]/low-1;nowbias=a['close'][t]/a['ma180'][t]-1
 if not ((age<=15 or near<=.03) and lift<=.12 and -.12<=nowbias<=.06 and a['ret20'][t]<=.12 and a['ret60'][t]<=.20 and a['peak180'][t]<=1.5 and a['valid300'][t]):return
 if np.max(a['high'][l:t+1])/a['close'][l]-1>.18:return
 if a['gapcum'][t]!=a['gapcum'][max(0,s-300)]:return
 turn=bool(a['ma5'][t]>a['ma5'][t-5] and a['close'][t]>=a['ma5'][t])
 f={'date':a['date'][t],'t':int(t),'close':float(a['close'][t]),'wash_start':a['date'][s],'start_t':int(s),'wash_low_date':a['date'][l],'low_t':int(l),'wash_low':float(low),'wash_low_close':float(a['close'][l]),'reference_close':float(ref),'wash_duration':int(dur),'wash_total_bars':int(t-s+1),'low_age':int(age),'depth':float(dep),'swing_depth':float(swing),'low_bias180':float(bias),'bias180':float(nowbias),'lift':float(lift),'near_low':float(near),'spread':float(a['spread'][t]),'pre_spread':float(pre),'wash_max_spread':float(mx),'wash_ma180_change':float(slope),'grind_vol_ratio':float(vr),'under_ma20_share':float(under),'turn':turn,'ma180':float(a['ma180'][t]),'ret20':float(a['ret20'][t]),'ret60':float(a['ret60'][t]),'peak180':float(a['peak180'][t])}
 for k in ['med120','tight120','range120','slope60','med180','tight180','range180']:f[k]=float(a[k][p])
 if f['med120']<=.055 and f['tight120']>=.8 and f['range120']<=.3 and abs(f['slope60'])<=.05 and .06<=dep<=.15 and 20<=dur<=40 and -.08<=bias<=-.03 and turn and (age<=10 or near<=.025) and lift<=.08 and f['spread']<=.14:f['tier']='更贴'
 elif f['med120']<=.065 and f['tight120']>=.7 and f['range120']<=.35 and abs(f['slope60'])<=.07 and .05<=dep<=.18 and -.1<=bias<=-.02 and (turn or near<=.03):f['tier']='次贴'
 else:f['tier']='观察'
 f['score']=round(100-200*f['med120']-35*f['range120']-100*abs(bias+.064)-70*abs(dep-.08)-.25*abs(dur-29)+8*f['tight120']+3*turn-30*lift,2)
 return f

def outcomes(a,f):
 t=f['t'];out={}
 for n in [10,20,40]:
  ok=t+n<len(a['date']) and a['gapcum'][t+n]==a['gapcum'][t] and np.isfinite(a['low'][t+1:t+n+1]).all()
  out['mature'+str(n)]=bool(ok)
  out['mfe'+str(n)]=float(np.max(a['high'][t+1:t+n+1])/a['close'][t]-1) if ok else None
  out['mae'+str(n)]=float(np.min(a['low'][t+1:t+n+1])/a['close'][t]-1) if ok else None
  out['ret'+str(n)+'f']=float(a['close'][t+n]/a['close'][t]-1) if ok else None
 return out

def run(p):
 code=p.stem;name=names.get(code,'');out={'code':code,'name':name,'events':[]}
 try:
  # Read every file for coverage statistics, even excluded names.
  d,bad=prep(p);out.update(bars=len(d),bad_bars=bad,last=d.date.iloc[-1]if len(d)else None,first=d.date.iloc[0]if len(d)else None)
  if not name or 'ST'in name.upper() or '退'in name:out['excluded']='ST_delisting'if name else'unknown_name';return out
  if code in STALE or (len(d) and d.date.iloc[-1]<'2026-09-01'):out['excluded']='long_stale_or_delisted';return out
  if len(d)<300:return out
  a={k:d[k].to_numpy() for k in d.columns};prev=d.shift(1)
  pre=(prev.med120<=.075)&(prev.tight120>=.6)&(prev.range120<=.4)&(prev.slope60.abs()<=.08)&(prev.spread<=.08)&(prev.close/prev.ma180>=.94)&(prev.close/prev.ma180<=1.08)
  roll=(d.close/d.close.shift(1)<=.98)|(d.close/d.close.shift(3)<=.97)
  starts=np.flatnonzero((pre&roll&(d.close<d.ma20)&(d.close<=d.ma180*1.01)).to_numpy())
  # Earliest chronological turn, not best future outcome or best tier.
  possible={};current=[]
  for s in starts:
   if s<300:continue
   if s+14<=len(d)-1<=s+64 and out['last']==ASOF:
    f=structure(a,int(s),len(d)-1)
    if f:current.append(f)
   for t in range(s+14,min(len(d),s+65)):
    if t==len(d)-1:continue
    # Very cheap alignment test before computing the wash window.
    if not (a['valid300'][t] and a['ma5'][t]>a['ma5'][t-5] and a['close'][t]>=a['ma5'][t] and .88<=a['close'][t]/a['ma180'][t]<=1.06):continue
    f=structure(a,int(s),int(t))
    if f and f['low_age']>=1:
     possible.setdefault(int(t),f);break
  last=-100
  for t,f in sorted(possible.items()):
   if t<=last+60:continue
   f.update(outcomes(a,f));f.update(code=code,name=name);out['events'].append(f);last=t
  if current:
   # same structure: earliest valid start, no best-score optimization across starts
   f=min(current,key=lambda f:f['start_t']);f.update(code=code,name=name);out['current']=f
 except Exception as e:out['error']=repr(e)
 return out

def clean(x):
 if isinstance(x,dict):return {k:clean(v)for k,v in x.items()}
 if isinstance(x,list):return [clean(v)for v in x]
 if isinstance(x,(float,np.floating))and not np.isfinite(x):return None
 if isinstance(x,np.generic):return x.item()
 return x

def make_template():
 d,_=prep(D/'sh600821.csv');a={k:d[k].to_numpy()for k in d};ix=lambda dt:int(d.index[d.date==dt][0]);s=ix('2025-11-21');l=ix('2025-12-31');t=ix('2026-01-13');f=structure(a,s,t);assert f,'Frozen thresholds must include template'
 z=d[(d.date>='2025-05-06')&(d.date<='2025-11-20')]
 out={'pattern':'粘合后阴跌洗盘：用户红框，不是整段粘合或后续主升','coil_start':'2025-05-06','coil_end':'2025-11-20','coil_bars':len(z),'coil_spread_median':float(z.spread.median()),'coil_tight8_share':float((z.spread<=.08).mean()),'coil_low':float(z.low.min()),'coil_high':float(z.high.max()),'coil_range':float(z.high.max()/z.low.min()-1),'box_start':'2025-11-21','box_end':'2026-01-13','default_start':'2025-06-05','default_end':'2026-01-23','anchor':f,'anchor_outcomes':outcomes(a,f),'measured_rows':d[d.date.isin(['2025-11-20','2025-11-21','2025-12-31','2026-01-05','2026-01-08','2026-01-09','2026-01-12','2026-01-13','2026-11-06'])][['date','open','high','low','close','vol','ma5','ma10','ma20','ma45','ma60','ma180','spread']].to_dict('records'),'latest_is_current':False,'latest_close':float(d.close.iloc[-1]),'latest_spread':float(d.spread.iloc[-1]),'correction':'2026-01-13收盘5.35已高于MA45约5.32，并非仍低于MA45；仍低于MA180。2月5/6日是相对12月31日5.09的更高低点，不是红框最低点。'}
 out['additional_measurements']={'prebreak_reference_date':'2025-11-20','low_intraday_bias180':float(d.low.iloc[l]/d.ma180.iloc[l]-1),'depth_vs_2025_11_11_high':float(1-d.low.iloc[l]/d.high.iloc[ix('2025-11-11')]),'depth_vs_2025_10_14_high':float(1-d.low.iloc[l]/d.high.iloc[ix('2025-10-14')]),'breakdown_close_return':float(d.close.iloc[s]/d.close.iloc[s-1]-1),'breakdown_vol_vs_pre40_median':float(d.vol.iloc[s]/d.vol.iloc[s-40:s].median()),'2026_01_12_vol_vs_prior20_median':float(d.vol.iloc[ix('2026-01-12')]/d.vol.iloc[ix('2026-01-12')-20:ix('2026-01-12')].median())}
 (O/'template.json').write_text(json.dumps(clean(out),ensure_ascii=False,indent=2));(O/'frozen_thresholds.json').write_text(json.dumps(THRESHOLDS,ensure_ascii=False,indent=2));return out
if __name__=='__main__':
 make_template();files=sorted(p for p in D.glob('*.csv')if re.match(r'^(sh(?:60|68)|sz(?:00|30))\d{4}\.csv$',p.name));start=time.time()
 with mp.Pool(8)as pool:res=pool.map(run,files,chunksize=15)
 events=[f for r in res for f in r['events']];current=[r['current']for r in res if'current'in r]
 for a in [events,current]:a.sort(key=lambda f:({'更贴':0,'次贴':1,'观察':2}[f['tier']],-f['score'],f['code'],f['date']))
 log={'asof':ASOF,'library_files':len(list(D.glob('*.csv'))),'sh_sz_files':len(files),'other_market_files':len(list(D.glob('*.csv')))-len(files),'eligible_named_nonST':sum(not r.get('excluded')for r in res),'excluded':dict(collections.Counter(r['excluded']for r in res if r.get('excluded'))),'bars_scanned':sum(r.get('bars',0)for r in res),'invalid_bars':sum(r.get('bad_bars',0)for r in res),'short_lt300':sum(r.get('bars',300)<300 for r in res if not r.get('excluded')),'stale':[{'code':r['code'],'name':r['name'],'last':r['last']}for r in res if r.get('last')and r['last']!=ASOF],'errors':[r for r in res if r.get('error')],'date_start':min(r['first']for r in res if r.get('first')),'historical_events':len(events),'historical_stocks':len({f['code']for f in events}),'historical_tiers':dict(collections.Counter(f['tier']for f in events)),'current_stocks':len(current),'current_tiers':dict(collections.Counter(f['tier']for f in current)),'runtime_sec':round(time.time()-start,2)}
 J=clean({'log':log,'current':current,'events':events});(O/'scan_results.json').write_text(json.dumps(J,ensure_ascii=False,indent=2,allow_nan=False))
 for key,fn in [('current','current_candidates.csv'),('events','historical_events.csv')]:
  df=pd.DataFrame(J[key]);cols=['code','name']+[k for k in df.columns if k not in ['code','name']];df.reindex(columns=cols).to_csv(O/fn,index=False)
 print(json.dumps(log,ensure_ascii=False,indent=2));print('CURRENT',[(f['code'],f['name'],f['tier'],f['wash_start'],f['wash_low_date'],round(f['depth']*100,2),round(f['lift']*100,2))for f in current]);print('JINKAI',[(f['date'],f['tier'],f['wash_start'])for f in events if f['code']=='sh600821'])
