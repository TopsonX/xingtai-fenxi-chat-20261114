import pickle, json, html, os, numpy as np, pandas as pd, sys, collections, math
import tpl, crit
from crit import C, SLUG
ASOF = sys.argv[1] if len(sys.argv) > 1 else '2026-11-12'
ROOT = '/workspace/fuyao/all_patterns_1112_v2/'; OUT = ROOT + 'engine/out/'
D = '/workspace/fuyao/market_daily/'
Z = pickle.load(open(OUT + 'stageC.pkl', 'rb')); F, g, per, nm = Z['F'], Z['g'], Z['per'], Z['nm']
ST = json.load(open(OUT + 'stats.json')); TS = ST['templates']; B = ST['baseline']
if os.path.exists(OUT + 'stats_t17.json'): TS['17'] = json.load(open(OUT + 'stats_t17.json'))
MK = json.load(open(OUT + 'market.json')); RF = json.load(open(OUT + 'refresh_summary.json')) if os.path.exists(OUT + 'refresh_summary.json') else {}
CAL = json.load(open(OUT + 'calibration.json')) if os.path.exists(OUT + 'calibration.json') else {}
QT = json.load(open('/workspace/fuyao/summary_1104/qt_all.json'))
esc = html.escape
TN = tpl.TNAMES
def nm_(c): q = QT.get(c); return q[1] if q else c
def P(x, d=1):
    if x is None or (isinstance(x, float) and not math.isfinite(x)): return '—'
    return f'{x*100:+.{d}f}%'
def Y(x, d=2):
    if x is None or (isinstance(x, float) and not math.isfinite(x)): return '—'
    return f'{x:+.{d}f}'
def N(x, d=2):
    if x is None or (isinstance(x, float) and not math.isfinite(x)): return '—'
    return f'{x:.{d}f}'
_cache = {}
def load(code):
    if code not in _cache:
        d = tpl.prep(pd.read_csv(D + code + '.csv')); _cache[code] = (d, tpl.A(d))
        if len(_cache) > 300: _cache.pop(next(iter(_cache)))
    return _cache[code]
def kpack(d, i0, i1):
    x = d.iloc[i0:i1]
    r = lambda v: None if not np.isfinite(v) else round(float(v), 3)
    return [[a.date, r(a.open), r(a.high), r(a.low), r(a.close), r(a.vol), r(a.m7), r(a.m45), r(a.m120), r(a.m200), r(a.m180), r(a.v20)] for a in x.itertuples()]
def segbox(d, s0, s1, label, color='#ffb020'):
    s0 = max(0, int(s0)); s1 = min(len(d) - 1, int(s1))
    return dict(start=d.date.iloc[s0], end=d.date.iloc[s1], top=float(d.high.iloc[s0:s1+1].max()) * 1.02, bottom=float(d.low.iloc[s0:s1+1].min()) * .98, color=color, label=label)
def seg_idx(d, seg):
    if isinstance(seg[0], str):
        dates = d.date.tolist()
        s0 = next((i for i, x in enumerate(dates) if x >= seg[0]), 0); s1 = len(dates) - 1
        return s0, s1
    return int(seg[0]), int(seg[1])
def invalid(k, a, t, s0):
    c = a['close']; lo = a['low']; L = tpl.lim('sz000001')
    def mn(x0): return float(lo[max(0, x0):t+1].min())
    m45 = a['m45'][t]; m200 = a['m200'][t]
    if k == 1: v, s = mn(s0), '收盘跌破回踩段低点'
    elif k == 2: v, s = float(lo[s0:s0+5].min()) * .97, '跌破堆量区低点'
    elif k in (3, 7, 10): v, s = mn(t-4), '跌破启动阳线/板的最低价'
    elif k in (4, 5, 6, 9): v, s = m45 * .97, 'MA7 重新跌回、收盘跌破 MA45×0.97'
    elif k == 8: v, s = mn(t-19), '收盘跌破底座 20 日低点'
    elif k == 11: v, s = float(lo[min(t, s0+15)]) * .97, '跌破首板最低价×0.97（结构破坏）'
    elif k == 12: v, s = float(c[min(t, s0+20)-1]) * .97, '跌破涨停起点（板前收盘×0.97）'
    elif k == 13: v, s = float(lo[t-119:t+1].min()), '跌破近 120 日低点（试盘失败）'
    elif k == 14: v, s = mn(min(t, s0+95)), '跌破坑后二次低点'
    elif k == 15: v, s = mn(t-59), '跌破鸭颈低点'
    elif k == 16: v, s = float(a['high'][t-4]), '回补跳空缺口（跌破缺口下沿）'
    elif k == 17: v, s = mn(t-29), '跌破洗盘低点'
    elif k == 18: v, s = m200 * .97, '收盘重回 MA200×0.97 下方'
    elif k == 19: v, s = m45 * .97, '收盘跌破 MA45×0.97（强势调整失败）'
    elif k == 20: v, s = m200 * .98, '再次收在 MA200×0.98 下方'
    elif k == 21: v, s = float(lo[min(t, s0+15)]) * .93, '跌破连板首板最低价×0.93'
    elif k == 22: v, s = m200 * .97, '收回 MA200×0.97 下方（起飞失败）'
    elif k == 23: v, s = max(m45 * .97, mn(t-44)), '跌破 MA45×0.97 / 坑底'
    elif k == 24: v, s = mn(t-59), '跌破 60 日底座下沿'
    else: v, s = m45 * .97, '跌破 MA45×0.97'
    return float(v), s
LVL = {3: '更像', 2: '较像', 1: '部分像'}
def growth(r):
    ry, ny, npv = r['rev_yoy'], r['np_yoy'], r['np']
    if not (isinstance(ry, float) and math.isfinite(ry)): return '无三季报口径数据，增长无法判断。'
    if npv is not None and npv <= 0:
        return f'营收同比{ry:+.1f}%，但归母净利为负（{npv:.2f}亿），属{"减亏/扭亏前" if (ny or 0) > 0 else "亏损扩大或持平"}阶段——增长质量弱。'
    if ry > 30 and (ny or 0) > 30: return f'营收+{ry:.1f}%、净利{ny:+.1f}%，双高增长——市场最认的类型。'
    if ry > 15 and (ny or 0) > 0: return f'营收+{ry:.1f}%、净利{ny:+.1f}%，稳健增长。'
    if (ny or 0) > 30 and ry <= 15: return f'净利{ny:+.1f}% 快于营收{ry:+.1f}%，利润率改善驱动，持续性需看营收。'
    if ry < 0 and (ny or 0) < 0: return f'营收{ry:+.1f}%、净利{ny:+.1f}%，双降——增长不支持，偏题材/资金驱动。'
    return f'营收{ry:+.1f}%、净利{ny:+.1f}%，增长一般。'
def capline(r):
    mf = '无主力资金流数据' if not math.isfinite(r['mf10'] if r['mf10'] is not None else float('nan')) else \
        f"主力净额(新浪，超大+大单，截至{r['mf_last']})：当日{Y(r['mf1'])}、5日{Y(r['mf5'])}、10日{Y(r['mf10'])}、20日{Y(r['mf20'])}亿，10日净占比均值{N(r['mfr10'],1)}%、10日中{int(r['pos10'] or 0)}天净流入，超大单10日{Y(r['xl10'])}亿"
    lhb = f"龙虎榜近60日上榜{int(r['lhb_n60'])}次：机构净{Y(r['org_net60'])}亿、游资净{Y(r['hot_net60'])}亿（近20日机构{Y(r['org_net20'])}/游资{Y(r['hot_net20'])}）" if r['lhb_n60'] else '近60日未上龙虎榜'
    oth = f"融资余额变化{P(r['rz_chg'])}(11-03快照)；股东户数环比{N(r['hn_ratio'],1)}%；筹码获利盘{N(r['winner']*100 if r['winner']==r['winner'] else None,0)}%、90%集中度{N(r['conc90'],2)}、上方15%套牢{N(r['over15']*100 if r['over15']==r['over15'] else None,0)}%；20日阳/阴量比{N(r['ud20'])}、OBV60 {N(r['obv60'])}；60日试盘巨量{int(r['trial60'])}次"
    return f"{mf}。{lhb}。{oth}。→ 资金分 {r['cap']:.1f}，{r['style']}。"
def techline(k, h, r, a, t):
    return (f"{TN[k]} · {h['phase']}（{LVL.get(h['level'], h['level'])}）：{h['note']}。收盘{N(r['close'])}；MA45 {N(a['m45'][t])}/MA120 {N(a['m120'][t])}/MA200 {N(a['m200'][t])}（MA200 20日{P(r['ma200_s20'])}），MA180(黄线) {N(a['m180'][t])}；"
            f"距均线簇上沿{P(r['ext'])}；5日{P(r['ret5'])}、20日{P(r['ret20'])}；20日均量/250日均量 {N(r['v20_v250'])}，20日换手均值{N(r['to20'],1)}%；一年涨停{int(r['lu250'])}次。")
def themeline(r):
    s = f"行业：{r['ind'] or '—'}。核心题材：{r['theme'] or '（F10 未取到）'}。"
    if isinstance(r['lu_reason'], str) and r['lu_reason']: s += f"最近涨停 {r['lu_last']}：{r['lu_reason']}。"
    if r['theme_pt']: s += r['theme_pt'] + '…'
    return s
def finline(r):
    if not (isinstance(r['rev_yoy'], float) and math.isfinite(r['rev_yoy'])): return '未取到 2026 三季报。'
    return f"2026三季报：营收{N(r['rev'],1)}亿（同比{r['rev_yoy']:+.1f}%），归母净利{N(r['np'],2)}亿（同比{(r['np_yoy'] if r['np_yoy']==r['np_yoy'] else float('nan')):+.1f}%），毛利率{N(r['gm'],1)}%，ROE{N(r['roe'],1)}%。"
def entry_for(code, k, h, tierlab, idx, extra_tags=(), links=None, id_=None, sus_note=None):
    r = F.loc[code]; d, a = load(code); t = len(d) - 1
    s0, s1 = seg_idx(d, h['seg'])
    inv_v, inv_s = invalid(k, a, t, s0)
    i0 = max(0, t - 420)
    boxes = [segbox(d, max(s0, i0), s1, f"T{k:02d} {h['phase'][:14]}")]
    gaps = []
    if k == 16 and t >= 4:
        gaps.append(dict(date=d.date.iloc[t-3], top=float(a['low'][t-3]), bottom=float(a['high'][t-4]), color='#ffb020', label='跳空缺口'))
    marks = [dict(date=d.date.iloc[t], price=float(inv_v), color='#ff6b81', text=f'失效 {inv_v:.2f}')]
    w = [['技术形态', techline(k, h, r, a, t)], ['资金面（优先）', capline(r)], ['题材', themeline(r)], ['业绩', finline(r)], ['增长', growth(r)]]
    if sus_note: w.append(['持续性', sus_note])
    risk = list(r['risk'])
    e = dict(id=id_ or f'{code}_{k}', code=code, name=r['name'], tier=tierlab, rank=idx, score=None, kline=kpack(d, i0, t + 1), segBoxes=boxes, gaps=gaps, markers=marks,
             defaultCount=min(220, t + 1 - i0), defaultStart=max(0, (t + 1 - i0) - 220), w=w, risk=risk, inv=f'失效：{inv_s}（{inv_v:.2f}）；或放量跌破 MA45。',
             tags=[f'资金分{r["cap"]:.1f}', r['style'], f'流通{N(r["fcap"],0)}亿', r['board']] + list(extra_tags), links=links or [], sub=f"T{k:02d}·{LVL.get(h['level'])}")
    return e
def sample_entry(k, code, name, date, note, idx):
    d, a = load(code); dates = d.date.tolist()
    ti = next((i for i, x in enumerate(dates) if x >= date), len(dates) - 1)
    h = tpl.FUNCS[k](a, ti, code) if k in tpl.FUNCS else None
    i0 = max(0, ti - 300); i1 = min(len(d), ti + 90)
    boxes = []; marks = [dict(date=dates[ti], price=float(a['close'][ti]), color='#c6f68d', text=f'标定日 {dates[ti]}')]
    if h:
        s0, s1 = seg_idx(d, h['seg']); boxes.append(segbox(d, max(s0, i0), s1, f'T{k:02d} 识别段'))
        hl = f"规则在标定日识别为“{LVL[h['level']]}”：{h['phase']}；{h['note']}。"
    else:
        hl = '规则在标定日当天未触发（见校准表的偏移）。'
    cal = CAL.get(f'{k}|{code}|{date}', {})
    off = cal.get('fired', {})
    offs = '、'.join(f"{('+' if int(o)>0 else '')}{o}日({LVL[v[0]]})" for o, v in sorted(off.items(), key=lambda z: int(z[0]))) or '无'
    w = [['用户样例说明', note], ['识别结果', hl], ['标定日前后±15日触发', offs]]
    o = []
    for n_ in (10, 20, 40):
        if ti + n_ < len(d): o.append(f"{n_}日 MFE {P(a['high'][ti+1:ti+n_+1].max()/a['close'][ti]-1)} / MAE {P(a['low'][ti+1:ti+n_+1].min()/a['close'][ti]-1)}")
    w.append(['标定日之后（事后，仅供对照）', '；'.join(o) or '—'])
    return dict(id=f'S_{code}_{date}', code=code, name=name, tier='样例', rank=idx, kline=kpack(d, i0, i1), segBoxes=boxes, gaps=[], markers=marks,
                defaultCount=min(240, i1 - i0), defaultStart=max(0, (ti - i0) - 170), w=w, risk=[], inv='', tags=['用户样例', f'标定 {dates[ti]}'], links=[], sub='样例')
def stat_table(S, title):
    if not S or not S.get('n'): return f'<p class=note>{title}：无事件。</p>'
    rows = ''
    for h in (10, 20, 40):
        if f'mfe{h}' not in S: continue
        rows += (f"<tr><td>{h}日</td><td>{S[f'n{h}']}</td><td>{P(S[f'mfe{h}'][0])} / <b>{P(S[f'mfe{h}'][1])}</b> / {P(S[f'mfe{h}'][2])}</td><td>{P(S[f'mae{h}'][0])} / <b>{P(S[f'mae{h}'][1])}</b> / {P(S[f'mae{h}'][2])}</td>"
                 f"<td>{P(S[f'ret{h}'][1])}</td><td>{S[f'win{h}']*100:.0f}%</td><td>{S[f'p_mfe10_{h}']*100:.0f}%</td><td>{S[f'p_mfe20_{h}']*100:.0f}%</td><td>{S[f'p_mae10_{h}']*100:.0f}%</td></tr>")
    return (f"<h3>{title}（事件 {S['n']}，40日成熟 {S.get('n_mature40',0)}）</h3><table><tr><th>期限</th><th>样本</th><th>MFE 25/50/75分位</th><th>MAE 25/50/75分位</th><th>收益中位</th><th>上涨占比</th><th>MFE≥10%</th><th>MFE≥20%</th><th>MAE≤-10%</th></tr>{rows}</table>")
def lab_row(name, S):
    if not S or not S.get('n_mature40'): return f'<tr><td>{name}</td><td colspan=6>样本不足</td></tr>'
    lift = (S['p_行情起点'] / B['p_行情起点']) if B['p_行情起点'] else 0
    return (f"<tr><td>{name}</td><td>{S['n_mature40']}</td><td><b>{S['p_行情起点']*100:.1f}%</b></td><td>{lift:.2f}</td><td>{S['p_几日游']*100:.1f}%</td><td>{S['p_无行情']*100:.1f}%</td><td>{S['p_一般']*100:.1f}%</td></tr>")
HEAD = lambda title, depth: f"""<!doctype html><html lang=zh-CN><head><meta charset=utf-8><meta name=viewport content="width=device-width,initial-scale=1"><title>{esc(title)}</title><link rel=stylesheet href="{depth}assets/style.css"></head><body><main>"""
def viewer_html(title, show_tier=True):
    return f"""<div id=app><section class=card id=viewer><h2>{title}</h2>
<div class=ctl>层级 <select v-model=tier><option v-for="t in tiers">{{{{t}}}}</option></select> 搜索 <input v-model=q placeholder="代码/名称" size=10> ｜ <button @click="zoom(1/1.3)">放大</button><button @click="zoom(1.3)">缩小</button><button @click="pan(-20)">◀</button><button @click="pan(20)">▶</button><button @click=reset>复位</button> <span class=note>图可拖动、滚轮缩放；键盘 ↑↓ 切换；黄色虚线=MA180</span></div>
<div class=wrap><div class=list><table><tr><th>#</th><th>代码</th><th>名称</th><th>层级</th><th>说明</th></tr>
<tr v-for="e in filtered" :key=e.id :class="{{sel:e.id===sel}}" @click="select(e.id)"><td>{{{{e.rank}}}}</td><td>{{{{e.code}}}}</td><td>{{{{e.name}}}}</td><td :class="'t-'+e.tier">{{{{e.tier}}}}</td><td>{{{{e.sub}}}}</td></tr></table></div>
<div><canvas ref=cv @pointerdown=down @pointermove=move @pointerup=up @pointerleave=leave @wheel.prevent=wheel></canvas><div class=status v-html=status></div>
<div v-if=stock class=w><p class=kv><b>{{{{stock.name}}}} {{{{stock.code}}}}</b> <span :class="'t-'+stock.tier">{{{{stock.tier}}}}</span> <span class=tag v-for="t in stock.tags">{{{{t}}}}</span></p>
<p v-if="stock.links&&stock.links.length">来源模板报告：<a v-for="l in stock.links" :href=l.href style="margin-right:8px">{{{{l.text}}}}</a></p>
<p v-for="kv in stock.w"><b>{{{{kv[0]}}}}</b>：{{{{kv[1]}}}}</p>
<p class=risk v-if="stock.tier!=='样例'"><b>风险</b>：{{{{stock.risk.length?stock.risk.join('；'):'无硬性风险标签（不代表无风险）'}}}}。{{{{stock.inv}}}}</p></div></div></div></section></div>"""
def tail_js(depth, data):
    return f"""<script src="{depth}assets/vue.global.prod.js"></script><script src="{depth}assets/renderer.js"></script>
<script id=data type="application/json">{json.dumps(data, ensure_ascii=False).replace('</', '<\\/')}</script><script src="{depth}assets/viewer.js"></script></body></html>"""
DISC = '<p class=disc>以上仅为形态与数据研究，不构成投资建议。</p>\n</main>'
SUMMARY = {}
# ======================= per-template reports
for k in sorted(list(tpl.FUNCS) + [17]):
    cr = C[k]; S = TS.get(str(k), {}); rows = per.get(k, []); near = nm.get(k, [])
    tc = collections.Counter(x['tier'] for x in rows)
    ents = []; i = 0
    for code, name, date, note in [(s[0], s[1], s[2], s[3]) for s in cr['samples']]:
        i += 1; ents.append(sample_entry(k if k in tpl.FUNCS else 17, code, name, date, note, i) if k in tpl.FUNCS else sample_entry_17(code, name, date, note, i) if False else None)
    ents = [e for e in ents if e]
    if k == 17:
        d, a = load('sh600821'); dates = d.date.tolist(); ti = dates.index('2026-01-09') if '2026-01-09' in dates else len(dates) - 1
        i0 = max(0, ti - 260); i1 = min(len(d), ti + 90)
        s0 = dates.index('2025-11-21'); s1 = dates.index('2026-01-13')
        ents = [dict(id='S_sh600821', code='sh600821', name='金开新能', tier='样例', rank=1, kline=kpack(d, i0, i1), segBoxes=[segbox(d, s0, s1, '你的红框 2025-11-21~2026-01-13')], gaps=[],
                     markers=[dict(date='2026-01-09', price=float(a['close'][ti]), color='#c6f68d', text='原引擎判定 2026-01-09')], defaultCount=min(240, i1 - i0), defaultStart=max(0, ti - i0 - 170),
                     w=[['用户样例说明', cr['samples'][0][3]], ['识别结果', CAL.get('17', {}).get('text', '原引擎在 2026-01-09 将其判定为“更贴”（11-08 研究已对齐红框）。')]], risk=[], inv='', tags=['用户样例'], links=[], sub='样例')]
    shown = [x for x in rows if x['tier'] in ('更贴', '次贴')] + [x for x in rows if x['tier'] == '观察'][:40]
    for x in shown:
        i += 1
        sv = S
        sus_note = (f"该模板历史 40 日“行情起点”概率 {S['p_行情起点']*100:.1f}%（基准 {B['p_行情起点']*100:.1f}%），“几日游”{S['p_几日游']*100:.1f}%。" if S.get('p_行情起点') is not None else None)
        e = entry_for(x['code'], k, x['hit'], x['tier'], i, sus_note=sus_note); e['sub'] = f"{LVL.get(x['level'])}·分{x['score']}"; ents.append(e)
    for x in near[:10]:
        i += 1
        try:
            e = entry_for(x['code'], k, x['hit'], '近似', i, id_=f"N_{x['code']}_{k}"); e['sub'] = x['why'][:16]; e['w'].insert(0, ['为什么没入选', x['why']]); ents.append(e)
        except Exception as ex:
            pass
    # tables
    cand_rows = ''.join(f"<tr><td>{j+1}</td><td><a href='#{x['code']}'>{x['code']}</a></td><td>{esc(F.loc[x['code'],'name'])}</td><td class='t-{x['tier']}'>{x['tier']}</td><td>{LVL.get(x['level'])}</td><td>{x['score']}</td><td>{F.loc[x['code'],'cap']:.1f}</td><td>{Y(F.loc[x['code'],'mf10'])}</td><td>{Y(F.loc[x['code'],'org_net60'])}</td><td>{F.loc[x['code'],'style']}</td><td>{N(F.loc[x['code'],'rev_yoy'],0)}%/{N(F.loc[x['code'],'np_yoy'],0)}%</td><td>{esc(x['hit']['phase'][:24])}</td></tr>" for j, x in enumerate(rows[:200]))
    near_rows = ''.join(f"<tr><td><a href='#{x['code']}'>{x['code']}</a></td><td>{esc(nm_(x['code']))}</td><td>{esc(x['why'])}</td><td>{x['cap']:.1f}</td><td>{esc(x['hit']['phase'][:30])}</td></tr>" for x in near[:20])
    labs = '<table><tr><th>分组</th><th>40日成熟事件</th><th>行情起点</th><th>相对基准倍数</th><th>几日游</th><th>无行情</th><th>一般</th></tr>' + lab_row('全部事件', S) + lab_row('其中“更像”', S.get('L3')) + lab_row('2019–2023', S.get('era_le2023')) + lab_row('2024–2026', S.get('era_ge2024')) + lab_row('事件时60日≥3板(游资活跃)', S.get('hot_lu60ge3')) + lab_row('事件时60日≤1板', S.get('calm_lu60le1')) + lab_row('MA200 20日上行', S.get('m200up')) + lab_row('MA200 20日下行', S.get('m200down')) + lab_row('一年无涨停', S.get('nolu250')) + lab_row('创业板/科创板', S.get('cy_kc')) + lab_row('机构型(MA200上行且60日≤1板)', S.get('inst_like')) + (lab_row('剔除银行/公用类', S.get('non_util')) if S.get('non_util') else '') + lab_row('全市场基准(每10日抽样)', B) + '</table>'
    ex = [e for e in (S.get('examples_recent') or []) if e[4][2] is not None][-15:]
    ex_rows = ''.join(f"<tr><td>{e[0]}</td><td>{esc(nm_(e[0]))}</td><td>{e[1]}</td><td>{LVL.get(e[2])}</td><td>{P(e[4][1][0])}</td><td>{P(e[4][1][1])}</td><td>{P(e[4][2][0])}</td><td>{P(e[4][2][2])}</td><td>{e[6]}</td></tr>" for e in ex)
    cal_rows = ''
    for s in cr['samples']:
        key = f'{k}|{s[0]}|{s[2]}'; cv = CAL.get(key, {})
        fired = cv.get('fired', {})
        near5 = [int(o) for o in fired if -5 <= int(o) <= 5]
        res = ('✅ 识别（' + '、'.join(f"{('+' if int(o)>0 else '')}{o}日{LVL[v[0]]}" for o, v in sorted(fired.items(), key=lambda z: int(z[0])) if -5 <= int(o) <= 5) + '）') if near5 else ('—' if k == 17 else '❌ 未识别')
        if k == 17: res = CAL.get('17', {}).get('short', '✅ 原引擎 2026-01-09 判定更贴')
        cal_rows += f"<tr><td>{s[1]} {s[0]}</td><td>{s[2]}</td><td>{esc(s[3])}</td><td>{res}</td></tr>"
    lift = S.get('lift_起点')
    verdict = ('历史上相对基准有正向超额' if (lift or 0) >= 1.1 else '历史上与随机基准差不多（单靠形态没有统计优势，必须叠资金面）' if (lift or 0) >= .9 else '历史上弱于基准（只作辅助）')
    SUMMARY[k] = dict(name=TN[k], slug=SLUG[k], n=S.get('n'), n_mature40=S.get('n_mature40'), p_start=S.get('p_行情起点'), p_trip=S.get('p_几日游'), lift=lift, mfe20=(S.get('mfe20') or [None, None])[1], mae20=(S.get('mae20') or [None, None])[1],
                      tiers=dict(tc), n_cand=len(rows), n_near=len(near), calib=[(s[1], s[2], (CAL.get(f'{k}|{s[0]}|{s[2]}', {}).get('ok', k == 17))) for s in cr['samples']], verdict=verdict)
    body = HEAD(f'T{k:02d} {TN[k]} · {ASOF}', '../') + f"""
<p><a href="../index.html">← 总目录</a> ｜ <a href="../top50/report.html">综合前50</a></p>
<h1>T{k:02d} · {esc(TN[k])}</h1><div class=meta>数据截至 <b>{ASOF} 收盘</b>（新加坡时间 UTC+8，同北京时间）｜ 生成于 {pd.Timestamp.now().strftime('%Y-%m-%d %H:%M')} UTC+8</div>
<section class=card><h2>结论先看</h2><ul>
<li>当前候选（已过相位过滤）：<b>更贴 {tc.get('更贴',0)}</b> / <b>次贴 {tc.get('次贴',0)}</b> / 观察 {tc.get('观察',0)}；近似未入选 {len(near)}。分层不凑数：资金面不达标的一律放观察。</li>
<li>历史回测：全库 {S.get('n','—')} 个事件，40日“行情起点”概率 <b>{(S.get('p_行情起点') or 0)*100:.1f}%</b>（基准 {B['p_行情起点']*100:.1f}%，倍数 {N(lift)}），“几日游” {(S.get('p_几日游') or 0)*100:.1f}%（基准 {B['p_几日游']*100:.1f}%）；20日 MFE 中位 {P((S.get('mfe20') or [0,0])[1])}、MAE 中位 {P((S.get('mae20') or [0,0])[1])}。→ {verdict}。</li>
</ul></section>
<section class=card><h2>1. 你的原始标准与样例</h2><p><b>原话/意思</b>：{esc(cr['user'])}</p><p><b>机械化规则</b>：{esc(cr['rule'])}</p><p class=note>K线颜色：MA7 白、MA45 蓝、MA120 橙、MA200 紫、<b>MA180 黄色虚线</b>；橙框=模板识别段；绿竖线=样例标定日；红点=当前候选的失效价。</p></section>
<section class=card><h2>2. 先校准：规则能否在你的样例上、在对的阶段识别</h2><table><tr><th>样例</th><th>标定日</th><th>为什么标这一天（推断依据）</th><th>结果（±5日内）</th></tr>{cal_rows}</table>
<p><b>本轮调整</b>：{esc(cr['fix'])}</p><p class=note>标定日是根据你提问日期之前最近、最符合描述的那段走势推断的（记忆里只有金开新能、视源、华正、瑞芯微有明确日期）。如果你图上标的是另一段，告诉我日期即可重新对齐。</p></section>
{viewer_html('3. 样例与当前候选 K 线（样例在最前；点选切换）')}
<section class=card><h2>4. 历史回测（全库 2019-01 至 {ASOF}，无未来函数）</h2>
<p class=note>事件=规则在某日首次触发（同一只票 30 个交易日内不重复计）、且当日20日均成交额≥3000万、股价≥2元、非当前ST。以触发日收盘为基准算未来 10/20/40 日最大浮盈(MFE)、最大浮亏(MAE)和收益；不足期限的事件不计入该期限。
<b>行情起点</b>=40日内 MFE≥25% 且第40日仍≥+10%；<b>几日游</b>=10日MFE≥10%或20日MFE≥12%、但第40日收益≤+2%；<b>无行情</b>=40日MFE&lt;8%；其余为一般。基准=全库所有股票每10个交易日抽样一次（同样的流动性过滤）。所有事件都计入，不挑赢家；但库里只有现存股票（已退市的不在），会有一定幸存者偏差。</p>
{stat_table(S, '全部事件')}{stat_table(S.get('L3'), '其中“更像”(level 3)')}{stat_table(B, '全市场基准')}
<h3>行情起点 vs 几日游（40日成熟事件）</h3>{labs}
<h3>最近 15 个已满 40 日的事件（按时间，不挑选）</h3><table><tr><th>代码</th><th>名称</th><th>触发日</th><th>相似度</th><th>20日MFE</th><th>20日MAE</th><th>40日MFE</th><th>40日收益</th><th>结果</th></tr>{ex_rows}</table></section>
<section class=card><h2>5. 当前候选清单（资金面优先排序）</h2>
<p class=note>相位过滤（已走出一段的不要）：20日涨>30%、5日涨>20%、距均线簇上沿>15%、20日≥3板、股价&lt;2、流通值&lt;15亿、ST 一律剔除。<b>更贴</b>=形态“更像” + 资金分≥3.5 + 主力10日不为净流出 + 非游资偏向 + 盈利且营收或净利同比为正 + 非低波动公用类 + 60日试盘巨量<3次；<b>次贴</b>=形态≥“较像” + 资金分≥2.5 + 无明显主力净流出 + 盈利或营收高增；其余为<b>观察</b>。同层内按 0.45×资金分位 + 0.25×业绩分位 + 0.15×启动特征分位 + 0.15×相似度 排序。图中只放更贴、次贴全部和观察前40；完整名单见 candidates.csv。</p>
<table><tr><th>#</th><th>代码</th><th>名称</th><th>层级</th><th>相似度</th><th>排序分</th><th>资金分</th><th>主力10日(亿)</th><th>龙虎榜机构60日(亿)</th><th>风格</th><th>营收/净利同比</th><th>相位</th></tr>{cand_rows or '<tr><td colspan=12>今日无通过相位过滤的候选。</td></tr>'}</table></section>
<section class=card><h2>6. 近似未入选（near-miss）</h2><p class=note>包括：今天触发但被相位/流动性过滤剔除的（多为已经走出一段，不追）；以及近 15 个交易日内触发过、今天条件已不满足的。按资金分排序，前 20。</p>
<table><tr><th>代码</th><th>名称</th><th>原因</th><th>资金分</th><th>形态</th></tr>{near_rows or '<tr><td colspan=5>无</td></tr>'}</table></section>
<section class=card><h2>7. 局限</h2><ul class=note>
<li>规则是对你口述形态的机械代理，标定日是推断的；历史统计说明的是“这个规则”的胜率，不等于你看图挑票的胜率。</li>
<li>资金面：新浪“主力净额”（超大单+大单）按单笔金额划分，不等于真实机构；龙虎榜只覆盖上榜日（已补到 {Z['LHB_RANGE'][1]}）；融资（11-03）、股东户数、机构持股为旧快照；筹码为按换手衰减的近似分布。</li>
<li>只含沪深（库内无北交所）；名称快照排除 ST；前复权口径。</li></ul></section>
{DISC}""" + tail_js('../', dict(entries=ents))
    os.makedirs(ROOT + SLUG[k], exist_ok=True)
    open(ROOT + SLUG[k] + '/report.html', 'w').write(body)
    # csv
    if rows:
        pd.DataFrame([dict(code=x['code'], name=F.loc[x['code'], 'name'], tier=x['tier'], level=x['level'], score=x['score'], cap=F.loc[x['code'], 'cap'], mf10=F.loc[x['code'], 'mf10'], org_net60=F.loc[x['code'], 'org_net60'], style=F.loc[x['code'], 'style'], rev_yoy=F.loc[x['code'], 'rev_yoy'], np_yoy=F.loc[x['code'], 'np_yoy'], phase=x['hit']['phase'], note=x['hit']['note']) for x in rows]).to_csv(ROOT + SLUG[k] + '/candidates.csv', index=False, encoding='utf-8-sig')
    else:
        open(ROOT + SLUG[k] + '/candidates.csv', 'w', encoding='utf-8-sig').write('code,name,tier\n')
    print('T', k, 'entries', len(ents), 'cands', len(rows), dict(tc))
json.dump(SUMMARY, open(OUT + 'template_summary.json', 'w'), ensure_ascii=False, indent=1, default=str)
