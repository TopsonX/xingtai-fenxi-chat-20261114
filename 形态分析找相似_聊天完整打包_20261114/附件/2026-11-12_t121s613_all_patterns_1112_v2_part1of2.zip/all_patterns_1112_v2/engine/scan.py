import pandas as pd, numpy as np, json, os, sys, time, pickle
from multiprocessing import Pool
import tpl
D = '/workspace/fuyao/market_daily/'
ASOF = sys.argv[1] if len(sys.argv) > 1 else '2026-11-12'
OUT = '/workspace/fuyao/all_patterns_1112_v2/engine/out'
os.makedirs(OUT, exist_ok=True)
QT = json.load(open('/workspace/fuyao/summary_1104/qt_all.json'))
COOL = 30

def masks(d, code):
    L = tpl.lim(code); c = d.close; p = d.pct; vr = d.vr
    lu = (p >= L)
    r = lambda s, w: s.astype(float).rolling(w, min_periods=1).max().astype(bool)
    xall = (d.m7 > d.mmax) & (d.m7.shift(1) <= d.mmax.shift(1))
    x45 = (d.m7 > d.m45) & (d.m7.shift(1) <= d.m45.shift(1))
    big = lambda a, b: (vr >= a) & (p >= b)
    M = {}
    M[1] = (d.m200 >= d.m200.shift(120) * 1.03) & (c >= d.m200 * .98) & (d.m7 >= d.m7.shift(3)) & (c >= d.m45 * .98)
    M[2] = (d.vol.rolling(10).mean() <= .45 * d.v5.rolling(101).max().shift(15)) & (d.m7 >= d.m7.shift(3))
    M[3] = r(big(1.8, min(L, 5.5)), 5)
    M[4] = r(xall, 8); M[5] = r(x45, 3); M[6] = r(xall, 30); M[9] = r(xall, 5)
    M[7] = r(big(2.0, 3), 3)
    M[8] = d.spread4 <= .08
    M[10] = r(big(1.8, min(7, L-2)), 5)
    M[11] = lu | lu.shift(1, fill_value=False)
    M[12] = (lu.shift(8, fill_value=False).astype(float).rolling(63, min_periods=1).max() > 0) if code[2:].startswith(('300', '301')) else pd.Series(False, index=d.index)
    M[13] = ((vr >= 1.8).astype(int).rolling(10).sum() >= 3) & (c <= d.high.rolling(251).max() * .6)
    M[14] = (c >= d.m45) & (d.m45 >= d.m45.shift(10))
    M[15] = (d.m200 > d.m200.shift(40)) & (c >= d.m45 * .97) & (d.m7 >= d.m7.shift(2))
    M[16] = d.low.shift(3) > d.high.shift(4)
    M[18] = (c >= d.m200 * .97) & (c <= d.m200 * 1.12)
    M[19] = d.m7 >= d.m45
    M[20] = (d.m200 >= d.m200.shift(60) * 1.02) & (c > d.m200) & ((c / d.m200).rolling(25).min() < .98)
    has2 = lu & lu.shift(1, fill_value=False)
    M[21] = r(lu | big(2.0, 5), 2) & (has2.shift(3, fill_value=False).astype(float).rolling(100, min_periods=1).max() > 0) | ((lu.shift(5, fill_value=False).astype(float).rolling(60, min_periods=1).max() > 0) & (d.sp7 <= .08))
    M[22] = r(big(1.8, 3), 5)
    M[23] = r(x45, 6)
    M[24] = ((vr >= 1.8) & (c >= d.open)).astype(int).rolling(10).sum() >= 2
    return {k: v.fillna(False).to_numpy(dtype=bool) for k, v in M.items()}

def outc(a, t, n):
    c = a['close']; N = len(c)
    if t + n >= N: return None
    return (a['high'][t+1:t+n+1].max() / c[t] - 1, a['low'][t+1:t+n+1].min() / c[t] - 1, c[t+n] / c[t] - 1)

def work(f):
    code = f[:-4]
    try:
        q = QT.get(code[2:]) if isinstance(QT, dict) else None
        d = pd.read_csv(D + f)
        if len(d) < 300: return None
        d = tpl.prep(d); a = tpl.A(d); dates = d.date.tolist(); n = len(d)
        L = tpl.lim(code)
        M = masks(d, code)
        liq = (a['amt20'] >= 3e7) & (a['close'] >= 2)
        res = dict(code=code, n=n, last=dates[-1], events={}, cur={}, near={}, base=[])
        cur_ok = dates[-1] == ASOF
        for k, fn in tpl.FUNCS.items():
            idx = np.where(M[k])[0]
            idx = idx[idx >= 262]
            last_ev = -999; evs = []; fires = []
            for t in idx:
                try:
                    r = fn(a, int(t), code)
                except Exception:
                    r = None
                if not r: continue
                fires.append((int(t), r))
                if r['level'] >= 2 and t - last_ev >= COOL and liq[t]:
                    o = [outc(a, int(t), m) for m in (10, 20, 40)]
                    lu60 = int((a['pct'][t-59:t+1] >= L).sum())
                    lu250 = int((a['pct'][t-249:t+1] >= L).sum())
                    m2up = bool(a['m200'][t] >= a['m200'][t-20])
                    evs.append([int(t), dates[t], r['level'], float(a['close'][t]), o, lu60, lu250, m2up])
                    last_ev = t
                elif r['level'] >= 2 and t - last_ev < COOL:
                    pass
            res['events'][k] = evs
            if cur_ok and fires:
                lt, lr = fires[-1]
                if lt == n - 1:
                    lr = dict(lr); lr['seg'] = [int(lr['seg'][0]), int(lr['seg'][1])]
                    res['cur'][k] = lr
                elif lt >= n - 15:
                    lr = dict(lr); lr['seg'] = [int(lr['seg'][0]), int(lr['seg'][1])]
                    lr['last_fire'] = dates[lt]; res['near'][k] = lr
        for t in range(262, n - 1, 10):
            if liq[t]:
                o = [outc(a, t, m) for m in (10, 20, 40)]
                res['base'].append([t, dates[t], o])
        return res
    except Exception as e:
        return dict(code=code, err=repr(e))

if __name__ == '__main__':
    files = sorted(x for x in os.listdir(D) if x.endswith('.csv') and x[:2] in ('sh', 'sz'))
    if len(sys.argv) > 2: files = files[:int(sys.argv[2])]
    t0 = time.time()
    with Pool(8) as P:
        R = [r for r in P.imap_unordered(work, files, chunksize=8) if r]
    pickle.dump(R, open(f'{OUT}/scan_raw.pkl', 'wb'))
    print('done', len(R), 'errs', sum(1 for r in R if 'err' in r), round(time.time() - t0, 1), 's')
