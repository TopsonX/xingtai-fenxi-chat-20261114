import pandas as pd, numpy as np, json, sys, importlib
import tpl; importlib.reload(tpl)
D='/workspace/fuyao/market_daily/'
S=[(1,'sz003816','2026-08-26'),(2,'sz000779','2026-07-06'),(3,'sz002172','2026-08-12'),(4,'sh688052','2026-08-20'),(5,'sz002614','2026-08-04'),
(6,'sh600388','2026-08-13'),(7,'sh603538','2026-03-06'),(8,'sh603019','2026-06-24'),(8,'sz002361','2025-12-08'),(9,'sz301110','2026-01-09'),(9,'sz002940','2026-05-20'),
(10,'sz301187','2026-10-30'),(11,'sz002164','2026-10-19'),(12,'sz301550','2026-10-16'),(13,'sz002865','2026-10-28'),(14,'sz301190','2026-09-21'),
(15,'sh603893','2024-12-12'),(15,'sh603893','2025-08-05'),(16,'sz002841','2026-07-03'),(16,'sh603186','2026-08-11'),(18,'sz300759','2026-06-29'),(19,'sz300450','2025-08-14'),
(20,'sz300433','2026-05-11'),(21,'sh603089','2026-10-22'),(21,'sh603330','2026-10-19'),(21,'sz002580','2026-06-23'),(21,'sz002242','2026-10-20'),(21,'sz002730','2025-08-07'),
(22,'sh603391','2025-09-15'),(23,'sh600802','2026-08-10'),(24,'sh600909','2026-05-13')]
only=[int(x) for x in sys.argv[1:]]
out=[]
for k,c,dt in S:
    if only and k not in only: continue
    d=tpl.prep(pd.read_csv(D+c+'.csv')); a=tpl.A(d); dates=d.date.tolist()
    ti=next(i for i,x in enumerate(dates) if x>=dt)
    fired={}
    for off in range(-15,11):
        t=ti+off
        if t>=len(dates): break
        r=tpl.FUNCS[k](a,t,c)
        if r: fired[off]=(r['level'],dates[t][5:])
    near=[o for o in fired if -5<=o<=5]
    out.append(dict(k=k,code=c,date=dt,fired=fired,ok=bool(near)))
    print(k,c,dt,'OK' if near else 'MISS',{o:v for o,v in fired.items()})

cal={f"{o['k']}|{o['code']}|{o['date']}":dict(fired={str(a):b for a,b in o['fired'].items()},ok=o['ok']) for o in out}
if not only: json.dump(cal,open('/workspace/fuyao/all_patterns_1112_v2/engine/out/calibration.json','w'),ensure_ascii=False,indent=1)
