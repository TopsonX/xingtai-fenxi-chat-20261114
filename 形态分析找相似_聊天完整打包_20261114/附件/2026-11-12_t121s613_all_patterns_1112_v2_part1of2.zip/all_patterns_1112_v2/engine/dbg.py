import pandas as pd, numpy as np, tpl
D='/workspace/fuyao/market_daily/'
def get(c,dt):
    d=tpl.prep(pd.read_csv(D+c+'.csv')); a=tpl.A(d); dates=d.date.tolist()
    return a, next(i for i,x in enumerate(dates) if x>=dt), dates
