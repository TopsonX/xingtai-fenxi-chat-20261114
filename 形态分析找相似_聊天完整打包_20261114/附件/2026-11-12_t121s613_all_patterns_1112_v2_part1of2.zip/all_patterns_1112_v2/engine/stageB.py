# fetch main-force flow (push2his, through ASOF) + F10 themes + Q3 finance for codes
import pandas as pd, requests, json, os, concurrent.futures as cf, time, random, sys
OUT = '/workspace/fuyao/all_patterns_1112_v2/engine/out'
FD = '/workspace/fuyao/all_patterns_1112_v2/flows/'; SD = '/workspace/fuyao/all_patterns_1112_v2/sources/'
os.makedirs(FD, exist_ok=True); os.makedirs(SD, exist_ok=True)
ASOF = sys.argv[1] if len(sys.argv) > 1 else '2026-11-12'
codes = json.load(open(f'{OUT}/need_codes.json'))
H = {'User-Agent': 'Mozilla/5.0', 'Referer': 'https://quote.eastmoney.com/'}
def flow(code):
    p = FD + code + '.json'
    if os.path.exists(p):
        try:
            k = json.load(open(p))['data']['klines']
            if k and k[-1][:10] >= ASOF: return code, 'cached'
        except Exception: pass
    c = code[2:]
    params = {'lmt': 60, 'klt': 101, 'secid': ('1.' if c[0] == '6' else '0.') + c, 'fields1': 'f1,f2,f3,f7', 'fields2': 'f51,f52,f53,f54,f55,f56,f57,f58,f59,f60,f61,f62,f63', 'ut': 'b2884a393a59ad64002292a3e90d46a5'}
    for k in range(9):
        try:
            host = ['push2his.eastmoney.com', 'push2.eastmoney.com'][k % 2]
            r = requests.get(f'https://{host}/api/qt/stock/fflow/daykline/get', params=params, headers=H, timeout=15); j = r.json()
            if (j.get('data') or {}).get('klines'):
                json.dump(j, open(p, 'w'), ensure_ascii=False); return code, 'ok' if j['data']['klines'][-1][:10] >= ASOF else 'ok_stale'
            return code, 'empty'
        except Exception:
            time.sleep(.5 + k * .5 + random.random() * .5)
    return code, 'fail'
U2 = 'https://datacenter.eastmoney.com/securities/api/data/v1/get'
def theme(code):
    p = SD + code + '.json'
    if os.path.exists(p):
        j = json.load(open(p))
        if j.get('theme') is not None: return code, 'cached'
    out = {'code': code, 'fetched_at': time.strftime('%Y-%m-%d %H:%M') + ' Asia/Singapore (UTC+8)'}
    sec = code[2:] + ('.SH' if code.startswith('sh') else '.SZ')
    par = {'reportName': 'RPT_F10_CORETHEME_CONTENT', 'columns': 'SECUCODE,KEY_CLASSIF,KEYWORD,MAINPOINT_CONTENT', 'filter': f'(SECUCODE="{sec}")', 'pageSize': 40}
    for k in range(3):
        try:
            r = requests.get(U2, params=par, timeout=15, headers={'User-Agent': 'Mozilla/5.0'})
            out['theme'] = (r.json().get('result') or {}).get('data') or []; out['theme_url'] = r.url
            json.dump(out, open(p, 'w'), ensure_ascii=False); return code, 'ok'
        except Exception as e:
            time.sleep(1 + k)
    return code, 'fail'
if __name__ == '__main__':
    import collections
    what = sys.argv[2] if len(sys.argv) > 2 else 'both'
    t0 = time.time()
    if what in ('both', 'flow'):
        with cf.ThreadPoolExecutor(2) as ex: res = list(ex.map(flow, codes))
        bad = [c for c, s in res if s == 'fail']
        if bad:
            time.sleep(20); r2 = dict(map(flow, bad)); res = [(c, r2.get(c, s)) for c, s in res]
        print('flows', len(codes), collections.Counter(s for _, s in res), round(time.time() - t0), 's')
        json.dump(res, open(f'{OUT}/flows_manifest.json', 'w'))
    if what in ('both', 'theme'):
        with cf.ThreadPoolExecutor(6) as ex: res = list(ex.map(theme, codes))
        print('themes', collections.Counter(s for _, s in res), round(time.time() - t0), 's')
