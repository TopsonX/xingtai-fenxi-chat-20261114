# v2 templates: 24 user launch-setup templates as mechanical proxies evaluated at bar t (no future data).
# Each returns None or dict(level=1..3, phase, seg=(i0,i1), note). level 3=更像 2=较像 1=部分像
import numpy as np, pandas as pd

def prep(d):
    d = d.copy()
    for w in [7, 45, 120, 180, 200]:
        d['m%d' % w] = d.close.rolling(w).mean()
    d['pct'] = d.close.pct_change() * 100
    d['v20'] = d.vol.rolling(20).mean()
    d['vr'] = d.vol / d.v20.shift(1)
    d['v250'] = d.vol.rolling(250, min_periods=120).mean()
    d['mmax'] = d[['m45', 'm120', 'm200']].max(axis=1)
    d['mmin'] = d[['m45', 'm120', 'm200']].min(axis=1)
    mm = d[['m7', 'm45', 'm120', 'm200']]
    d['spread4'] = mm.max(axis=1) / mm.min(axis=1) - 1
    d['sp7'] = d[['m7', 'm45', 'm120']].max(axis=1) / d[['m7', 'm45', 'm120']].min(axis=1) - 1
    d['spread3'] = d['mmax'] / d['mmin'] - 1
    d['amt20'] = (d.vol * 100 * d.close).rolling(20).mean()
    d['v5'] = d.vol.rolling(5).mean()
    d['r30'] = d.close / d.close.rolling(30).min() - 1
    return d

def lim(code):
    return 19.5 if code[2:].startswith(('300', '301', '688', '689')) else 9.7

def A(d):
    return {k: d[k].to_numpy() for k in d.columns}

def cross_all_within(a, t, k=5):
    for j in range(t - k + 1, t + 1):
        if a['m7'][j] > a['mmax'][j] and a['m7'][j - 1] <= a['mmax'][j - 1]:
            return j
    return None

def ext_ok(a, t, cap=1.10):
    return a['close'][t] / a['mmax'][t] <= cap

R = lambda x, y: x / y - 1

# ---------------- T01 中国广核 多头趋势回踩MA45/120(甚至MA200)洗盘末·突破前高前
def T01(a, t, code):
    if t < 330: return None
    c = a['close']; m45, m120, m200 = a['m45'], a['m120'], a['m200']
    if not (m200[t] >= m200[t-120] * 1.03 and m200[t] >= m200[t-60] * 0.995): return None
    w = slice(t-200, t-30)
    stk = ((m45[w] > m120[w]) & (m120[w] > m200[w]) & (c[w] > m120[w])).mean()
    if stk < .35: return None
    hs = t - 150; hi_i = hs + int(np.argmax(a['high'][hs:t-9])); H = a['high'][hi_i]
    lo_i = hi_i + int(np.argmin(a['low'][hi_i:t+1])); L = a['low'][lo_i]
    dd = L / H - 1
    if not (-.28 <= dd <= -.07 and lo_i > hi_i): return None
    touch = L <= m120[lo_i] * 1.03 or L <= m45[lo_i] * 1.02
    if not touch or L < m200[lo_i] * .92: return None
    if not (c[t] >= m200[t] * .98 and c[t] <= H * .97 and R(c[t], c[t-20]) <= .12): return None
    if not (a['m7'][t] >= a['m7'][t-3] and c[t] >= m45[t] * .98): return None
    vx = np.nanmax(a['vr'][t-4:t+1])
    lvl = 3 if (vx >= 1.5 and c[t] >= m45[t] and L <= m120[lo_i] * 1.03 and stk >= .5) else 2
    return dict(level=lvl, phase='多头回踩洗盘末/待突破前高', seg=(hi_i, t), note=f'前高{H:.2f}回撤{dd:.0%}触及MA120/MA45，多头排列占比{stk:.0%}，近5日最大量比{vx:.1f}')

# ---------------- T02 甘咨询 堆量后缩量整理/待再启
def T02(a, t, code):
    v = a['vol']; c = a['close']
    if t < 300: return None
    base = np.median(v[t-250:t-60])
    win = v[t-120:t-15]
    if base <= 0: return None
    roll = a['v5'][t-116:t-15]
    j = int(np.nanargmax(roll)) + 4; pile = roll[j-4]
    if pile < 3.0 * base: return None
    pe = t - 120 + j
    shrink = np.mean(v[t-9:t+1]) / pile
    pile_low = a['low'][pe-4:pe+1].min()
    if not (shrink <= .45 and c[t] >= pile_low * .85 and a['m7'][t] >= a['m7'][t-3] and -.08 <= R(c[t], a['m45'][t]) <= .12 and R(c[t], c[t-20]) <= .15): return None
    lvl = 3 if shrink <= .4 and c[t] >= a['m45'][t] else 2
    return dict(level=lvl, phase='堆量后缩量整理/待再启', seg=(pe-4, t), note=f'堆量5日均{pile/base:.1f}倍基准，近10日缩至堆量的{shrink:.2f}')

# ---------------- T03 澳洋健康 无量下杀后V反首板
def T03(a, t, code):
    c = a['close']; L = lim(code)
    if t < 140: return None
    for j in range(t-4, t+1):
        if a['pct'][j] >= min(L, 5.5) and a['vr'][j] >= 1.8:
            lo_i = j - 60 + int(np.argmin(a['low'][j-60:j+1]))
            if lo_i >= j: continue
            hi_i = lo_i - 70 + int(np.argmax(a['high'][lo_i-70:lo_i+1]))
            drop = a['low'][lo_i] / a['high'][hi_i] - 1
            dv = np.mean(a['vol'][hi_i:lo_i+1]) / max(np.mean(a['vol'][hi_i-40:hi_i]), 1)
            prior_lu = (a['pct'][lo_i:j] >= L).sum()
            if drop <= -.20 and dv <= .85 and prior_lu == 0 and lo_i - hi_i >= 8 and c[t] / a['low'][lo_i] - 1 <= .45:
                lvl = 3 if (drop <= -.25 and dv <= .8 and a['pct'][j] >= L) else 2
                return dict(level=lvl, phase='无量下杀后V反首板/首根放量阳', seg=(hi_i, t), note=f'下杀{drop:.0%}，下杀段均量为前期{dv:.2f}倍，低点后首次{"涨停" if a["pct"][j]>=L else "放量阳"}')
    return None

# ---------------- T04 纳芯微 MA7刚上穿全部均线
def T04(a, t, code):
    if t < 210: return None
    j = cross_all_within(a, t, 8)
    if j is None or not ext_ok(a, t, 1.08): return None
    lvl = 3 if a['close'][t] / a['mmax'][t] <= 1.05 and a['m200'][t] >= a['m200'][t-20] else 2
    return dict(level=lvl, phase='MA7刚上穿全部均线', seg=(j-20, t), note=f'上穿于{t-j}日前，距均线簇上沿{R(a["close"][t], a["mmax"][t]):.1%}')

# ---------------- T05 奥佳华 MA7刚上穿MA45
def T05(a, t, code):
    if t < 210: return None
    for j in range(t-2, t+1):
        if a['m7'][j] > a['m45'][j] and a['m7'][j-1] <= a['m45'][j-1]:
            if a['close'][t] / a['m45'][t] <= 1.07:
                lvl = 3 if a['m45'][t] >= a['m45'][t-5] else 2
                return dict(level=lvl, phase='MA7刚上穿MA45', seg=(j-20, t), note='MA45%s' % ('走平/上行' if lvl == 3 else '仍下行'))
    return None

# ---------------- T06 紫金龙净 温和上穿全部均线后贴线运行
def T06(a, t, code):
    if t < 240: return None
    j = cross_all_within(a, t, 30)
    if j is None: return None
    held = (a['m7'][j:t+1] > a['mmax'][j:t+1]).mean()
    mx = np.max(a['pct'][t-9:t+1])
    if held < .8 or mx > 7 or not ext_ok(a, t, 1.07) or a['spread3'][t] > .10: return None
    lvl = 3 if mx <= 5 and a['spread3'][t] <= .06 and a['close'][t] / a['mmax'][t] <= 1.05 else 2
    return dict(level=lvl, phase='温和上穿全部均线后贴线运行', seg=(j-20, t), note=f'上穿{t-j}日，近10日最大涨幅{mx:.1f}%，长均线离散{a["spread3"][t]:.1%}')

# ---------------- T07 美诺华 前期放量→长缩量粘合垫→突然放量
def T07(a, t, code):
    v = a['vol']
    if t < 320: return None
    for j in range(t-2, t+1):
        pad = slice(j-55, j)
        padv = np.mean(v[pad])
        early = np.nanmax(a['v20'][j-241:j-70])
        sp = np.median(a['spread4'][j-20:j]); rng = a['high'][pad].max() / a['low'][pad].min() - 1
        if early >= 2.0 * padv and sp <= .09 and rng <= .30 and v[j] >= 2.0 * padv and a['vr'][j] >= 2.0 and a['pct'][j] >= 3 and a['close'][t] / a['close'][j-1] - 1 <= .15:
            lvl = 3 if sp <= .08 and v[j] >= 2.5 * padv and early >= 2.5 * padv else 2
            return dict(level=lvl, phase='长缩量粘合垫后首放量', seg=(j-55, t), note=f'前期放量段20日均量为垫的{early/padv:.1f}倍；放量前20日四线离散中位{sp:.1%}，垫55日、振幅{rng:.0%}；放量{v[j]/padv:.1f}倍')
    return None

# ---------------- T08 曙光/神剑 长底座均线交汇
def T08(a, t, code):
    if t < 300: return None
    sp_now = a['spread4'][t]; sp15 = np.nanmin(a['spread4'][t-14:t+1])
    if sp_now > .08 or sp15 > .05: return None
    sp60 = np.nanmedian(a['spread4'][t-60:t+1])
    rng = a['high'][t-119:t+1].max() / a['low'][t-119:t+1].min() - 1
    near = abs(a['close'][t] / a['m45'][t] - 1)
    if sp60 <= .12 and rng <= .40 and near <= .05 and a['close'][t] / a['close'][t-20] - 1 <= .10:
        lvl = 3 if sp15 <= .04 and sp60 <= .08 else 2
        return dict(level=lvl, phase='长底座均线交汇/待发', seg=(t-120, t), note=f'四线离散{sp_now:.1%}(15日最小{sp15:.1%})，60日中位{sp60:.1%}，120日箱体{rng:.0%}')
    return None

# ---------------- T09 青木/昂利康 粘合后5日内MA7上穿全部
def T09(a, t, code):
    if t < 240: return None
    j = cross_all_within(a, t, 5)
    if j is None or not ext_ok(a, t, 1.25): return None
    ext = a['close'][t] / a['mmax'][t] - 1
    spmin = np.nanmin(a['sp7'][j-30:j+1]); spmed = np.nanmedian(a['sp7'][j-40:j])
    if not (spmin <= .07 or spmed <= .10): return None
    lvl = 3 if ((spmin <= .05 or spmed <= .07) and ext <= .08) else 2
    return dict(level=lvl, phase='粘合后MA7上穿全部(5日内)', seg=(j-40, t), note=f'上穿前30日MA7/45/120最小离散{spmin:.1%}、40日中位{spmed:.1%}，距均线簇上沿{ext:.0%}')

# ---------------- T10 欧圣电气 涨后回踩均线汇合→放量板回前高
def T10(a, t, code):
    if t < 200: return None
    c = a['close']; L = lim(code)
    for j in range(t-4, t+1):
        if a['vr'][j] >= 1.8 and a['pct'][j] >= min(7, L-2):
            h_i = j-50 + int(np.argmax(a['high'][j-50:j-4])); H = a['high'][h_i]
            lo_i = h_i + int(np.argmin(a['low'][h_i:j])); lo = a['low'][lo_i]
            base = a['low'][h_i-40:h_i].min()
            if H / base - 1 >= .15 and -.35 <= lo / H - 1 <= -.10:
                lc_i = h_i + int(np.argmin(c[h_i:j])); lc = c[lc_i]
                conf = min(abs(lc / a['m45'][lc_i] - 1), abs(lc / a['m120'][lc_i] - 1), abs(lc / a['m200'][lc_i] - 1))
                glue = abs(a['m7'][j-1] / a['m45'][j-1] - 1)
                if (conf <= .07 or (glue <= .03 and conf <= .10)) and .88 <= c[t] / H <= 1.08:
                    lvl = 3 if conf <= .04 and a['pct'][j] >= L and H / base - 1 >= .25 else 2
                    return dict(level=lvl, phase='涨后回踩均线粘合→放量板回前高', seg=(h_i-40, t), note=f'前段涨{H/base-1:.0%}至前高{H:.2f}，回撤{lo/H-1:.0%}至均线区(偏离{conf:.0%})，MA7/MA45粘合{glue:.1%}，现价/前高{c[t]/H:.2f}')
    return None

# ---------------- T11 宁波东力 涨停→姿势下来→再涨停(再启动日)
def T11(a, t, code):
    if t < 120: return None
    L = lim(code); p = a['pct']
    for j in range(t-1, t+1):
        if p[j] < L or p[j-1] >= L: continue
        prev = [k for k in range(j-40, j-2) if p[k] >= L]
        if not prev: continue
        k = prev[-1]
        while k-1 >= 0 and p[k-1] >= L: k -= 1   # first board of that streak
        k2 = prev[-1]
        hi_i = k2 + int(np.argmax(a['high'][k2:j])); hi = a['high'][hi_i]
        lo = a['low'][hi_i:j].min() if hi_i < j else a['low'][j-1]
        wash = lo / hi - 1
        if wash <= -.07 and lo >= a['low'][k] * .97 and (p[j-2:j] >= L).sum() == 0:
            nboard = sum(1 for x in range(j-40, j) if p[x] >= L)
            lvl = 3 if (wash <= -.10 and (p[k-20:k] >= L).sum() <= 1 and a['close'][j] <= a['close'][k2] * 1.35) else 2
            return dict(level=lvl, phase='板→姿势下来→再板(再启动)', seg=(k-15, t), note=f'首板距今{t-k}日，板后回落{wash:.0%}未破首板低点，40日内{nboard}板')
    return None

# ---------------- T12 斯菱 创业板涨停后横盘守结构、趋势向上
def T12(a, t, code):
    if not code[2:].startswith(('300', '301')) or t < 120: return None
    p = a['pct']; idx = [k for k in range(t-70, t-7) if p[k] >= 19.5]
    if not idx: return None
    k = idx[-1]
    if (p[k+1:t+1] >= 19.5).sum(): return None
    rng = a['high'][k+1:t+1].max() / a['low'][k+1:t+1].min() - 1
    if rng <= .30 and a['low'][k+1:t+1].min() >= a['close'][k-1] * .97 and a['m45'][t] > a['m45'][t-10] and a['close'][t] >= a['m45'][t] * .97 and a['m7'][t] > a['m45'][t] * .99 and a['close'][t] / a['close'][k] <= 1.18:
        lvl = 3 if rng <= .22 and a['m7'][t] > a['m45'][t] and a['close'][t] >= a['m45'][t] else 2
        return dict(level=lvl, phase='创业板板后横盘守结构', seg=(k-20, t), note=f'板后{t-k}日箱体{rng:.0%}，未破涨停起点(板前收盘)，MA45上行')
    return None

# ---------------- T13 钧达 深跌低位多日异动量
def T13(a, t, code):
    c = a['close']
    if t < 260: return None
    h250 = a['high'][t-250:t+1].max(); dd = c[t] / h250 - 1
    lo120 = a['low'][t-119:t+1].min()
    if dd > -.40 or c[t] / lo120 - 1 > .30: return None
    z = slice(t-9, t+1); ab = (a['vr'][z] >= 1.8).sum()
    rng = a['high'][z] - a['low'][z]; ush = a['high'][z] - np.maximum(a['open'][z], c[z])
    cg = ((ush >= .5 * rng) & (a['vr'][z] >= 1.8)).sum()
    if ab >= 3 and cg >= 1 and c[t] / c[t-10] - 1 <= .18 and (a['pct'][t-9:t+1] >= lim(code)).sum() <= 2:
        lvl = 3 if ab >= 4 and c[t] >= a['m45'][t] * .95 else 2
        return dict(level=lvl, phase='深跌低位多日异动量(冲高回落试盘)', seg=(t-60, t), note=f'距年高{dd:.0%}，10日内{ab}天≥1.8倍量，冲高回落{cg}次')
    return None

# ---------------- T14 善水 黄金坑：平台→急挖坑→坑内修复、二次探底抬高，待收复平台
def T14(a, t, code):
    if t < 260: return None
    c = a['close']
    lo_i = t-90 + int(np.argmin(a['low'][t-90:t-9])); P = a['low'][lo_i]
    plat = np.median(c[lo_i-90:lo_i-25])
    pit = P / plat - 1
    if not (-.50 <= pit <= -.20): return None
    hb = a['high'][lo_i-25:lo_i].max()
    if hb < plat * .95: pass
    rec = c[t] / plat
    if not (.78 <= rec <= 1.05): return None
    rl = a['low'][lo_i+5:t+1].min() if t > lo_i + 5 else a['low'][t]
    if rl < P * 1.06: return None
    spike = (a['vr'][lo_i:t+1] >= 2.5).any()
    if not (c[t] >= a['m45'][t] and a['m45'][t] >= a['m45'][t-10] and spike and R(c[t], c[t-10]) <= .18): return None
    lvl = 3 if (a['m7'][t] > a['m45'][t] and rl >= P * 1.10 and rec >= .85) else 2
    return dict(level=lvl, phase='黄金坑修复/待收复平台', seg=(lo_i-90, t), note=f'坑深{pit:.0%}，坑后二次低点抬高{rl/P-1:.0%}，现价/坑前平台{rec:.2f}')

# ---------------- T15 瑞芯微 老鸭头前夕：鸭头冲高(含涨停)→鸭颈回落不破长均线→缩量鸭嘴待张口
def T15(a, t, code):
    if t < 300: return None
    c = a['close']; L = lim(code)
    p_i = t-200 + int(np.argmax(a['high'][t-200:t-14])); Pk = a['high'][p_i]
    b_i = p_i-60 + int(np.argmin(a['low'][p_i-60:p_i])); B = a['low'][b_i]
    imp = Pk / B - 1
    if imp < .40 or (a['pct'][b_i:p_i+1] >= L).sum() < 1: return None
    n_i = p_i + int(np.argmin(a['low'][p_i:t+1])); N = a['low'][n_i]
    neck = N / Pk - 1
    if not (-.40 <= neck <= -.12): return None
    if N < a['m200'][n_i] * .97: return None
    if not (a['m200'][t] > a['m200'][t-40] and c[t] <= Pk * .97 and c[t] >= a['m45'][t] * .97 and a['m7'][t] >= a['m7'][t-2]): return None
    impv = np.mean(a['vol'][b_i:p_i+1]); eve = np.mean(a['vol'][t-9:t+1])
    rng10 = a['high'][t-9:t+1].max() / a['low'][t-9:t+1].min() - 1
    if eve > .75 * impv or rng10 > .16 or R(c[t], c[t-10]) > .15: return None
    lvl = 3 if (eve <= .6 * impv and rng10 <= .12 and abs(R(a['m7'][t], a['m45'][t])) <= .05) else 2
    return dict(level=lvl, phase='老鸭头前夕(鸭嘴缩量待张口)', seg=(b_i, t), note=f'鸭头涨幅{imp:.0%}，鸭颈回撤{neck:.0%}守MA200，前夕量为鸭头段{eve/impv:.2f}倍')

# ---------------- T16 视源/华正 深洗后向上跳空，3日不回补
def T16(a, t, code):
    if t < 200: return None
    g = t - 3
    if a['low'][g] <= a['high'][g-1]: return None
    gap = a['low'][g] / a['high'][g-1] - 1
    h_i = g-120 + int(np.argmax(a['high'][g-120:g-5])); H = a['high'][h_i]
    lo = a['low'][h_i:g].min(); wash = lo / H - 1
    if wash > -.15: return None
    if a['close'][g] / lo - 1 > .40: return None
    if a['low'][g+1:t+1].min() <= a['high'][g-1]: return None
    if a['close'][t] < a['close'][g] * .98: return None
    hl = a['low'][g+1] >= a['low'][g] * .99
    lvl = 3 if (a['vr'][g] >= 1.8 and wash <= -.20 and hl and a['close'][t] >= a['close'][g]) else 2
    return dict(level=lvl, phase='深洗后向上跳空，3日不补', seg=(h_i, t), note=f'前高{H:.2f}洗盘{wash:.0%}；跳空缺口{gap:.1%}，3日最低{a["low"][g+1:t+1].min():.2f}未补缺口{a["high"][g-1]:.2f}')

# ---------------- T18 康龙化成 长横盘→跌破平MA200挖深坑→放量V回MA200
def T18(a, t, code):
    if t < 360: return None
    c = a['close']; m200 = a['m200']
    lo_i = t-60 + int(np.argmin(a['low'][t-60:t-2])); P = a['low'][lo_i]
    if P > m200[lo_i] * .85: return None
    s0 = lo_i - 30
    base = slice(s0-120, s0)
    if abs(R(m200[s0], m200[s0-60])) > .08: return None
    within = (np.abs(c[base] / m200[base] - 1) <= .12).mean()
    if within < .6: return None
    if not (m200[t] * .97 <= c[t] <= m200[t] * 1.12): return None
    sp = [x for x in range(lo_i, t+1) if a['vr'][x] >= 2 and a['pct'][x] >= 4]
    if not sp or R(c[t], P) > .55: return None
    lvl = 3 if (c[t] >= m200[t] and within >= .75 and P <= m200[lo_i] * .82) else 2
    return dict(level=lvl, phase='破MA200挖坑后放量V回MA200', seg=(s0-120, t), note=f'横盘期贴MA200占比{within:.0%}，坑底低于MA200 {P/m200[lo_i]-1:.0%}，放量阳{len(sp)}根')

# ---------------- T19 先导智能 一波放量上涨→缩量强势调整(守MA45)→待主升
def T19(a, t, code):
    if t < 260: return None
    c = a['close']; v = a['vol']
    p_i = t-60 + int(np.argmax(a['high'][t-60:t-9])); Pk = a['high'][p_i]
    b_i = p_i-50 + int(np.argmin(a['low'][p_i-50:p_i])); B = a['low'][b_i]
    if Pk / B - 1 < .20: return None
    rv = np.sort(v[b_i:p_i+1])[::-1]; runv = np.mean(rv[:10]); pre = np.mean(v[b_i-60:b_i])
    if runv < 1.8 * pre: return None
    adj = slice(p_i+1, t+1)
    if t - p_i < 8: return None
    dd = a['low'][adj].min() / Pk - 1
    if dd < -.18: return None
    if (c[adj] < a['m45'][adj] * .97).mean() > .1 or a['m45'][t] < a['m45'][p_i]: return None
    sv = np.mean(v[t-14:t+1]) / runv
    if sv > .6 or c[t] < Pk * .88 or c[t] > Pk * 1.08: return None
    if a['m7'][t] < a['m45'][t]: return None
    lvl = 3 if (sv <= .45 and dd >= -.12 and c[t] <= Pk * 1.03) else 2
    return dict(level=lvl, phase='首波后缩量强调整，守MA45待主升', seg=(b_i-20, t), note=f'首波{Pk/B-1:.0%}，调整{t-p_i}日最大回撤{dd:.0%}，近15日均量为首波放量日的{sv:.2f}倍')

# ---------------- T20 蓝思科技 回踩上行MA200→缩量短暂跌破→阳包阴收回
def T20(a, t, code):
    if t < 330: return None
    c = a['close']; o = a['open']; m200 = a['m200']
    if m200[t] < m200[t-60] * 1.02: return None
    if (c[t-120:t-25] > m200[t-120:t-25]).mean() < .6: return None
    dip = [x for x in range(t-25, t) if c[x] < m200[x] * .98]
    if not dip: return None
    if a['low'][t-25:t+1].min() < m200[t] * .82: return None
    for j in range(t-2, t+1):
        if c[j] > m200[j] and c[j-1] <= m200[j-1] * 1.01 and a['pct'][j] >= 3 and c[j] > max(o[j-1], c[j-1]) and o[j] <= c[j-1] * 1.02:
            dv = np.mean(a['vol'][dip]) / max(np.mean(a['vol'][t-70:t-25]), 1)
            lvl = 3 if (c[j-1] < o[j-1] and dv <= 1.0 and c[t] <= m200[t] * 1.08) else 2
            return dict(level=lvl, phase='回踩MA200短破后阳包阴收回', seg=(t-120, t), note=f'跌破MA200 {len(dip)}日，破位期量为前期{dv:.2f}倍，收回日{a["pct"][j]:.1f}%')
    return None

# ---------------- T21 连板家族(正裕/天洋/圣阳/九阳/电光) ≥2连板→调整缩量(不破首板起点)→再放量 / 收敛待发
def T21(a, t, code):
    if t < 200: return None
    L = lim(code); p = a['pct']; c = a['close']; v = a['vol']
    relaunch = None
    for j in range(t-1, t+1):
        if (p[j] >= L or (a['vr'][j] >= 2.0 and p[j] >= 5)) and p[j-1] < L:
            relaunch = j; break
    end = (relaunch if relaunch is not None else t + 1) - 3
    k2 = None
    for x in range(end, t-100, -1):
        if p[x] >= L and p[x-1] >= L: k2 = x; break
    if k2 is None and relaunch is None:
        for x in range(end, t-60, -1):
            if p[x] >= L: k2 = x; break
    if k2 is None: return None
    k1 = k2
    while p[k1-1] >= L: k1 -= 1
    nb = k2 - k1 + 1
    stop = relaunch if relaunch is not None else t + 1
    if stop - k2 < 3: return None
    hi_i = k2 + int(np.argmax(a['high'][k2:stop])); hi = a['high'][hi_i]
    lo = a['low'][hi_i:stop].min(); dd = lo / hi - 1
    last_b = max(x for x in range(k2, stop) if p[x] >= L)
    start_low = a['low'][k1]
    bv = np.mean(v[k1:hi_i+1])
    sm = np.nanmin(a['v5'][hi_i+4:stop]) if stop - hi_i >= 5 else np.mean(v[hi_i:stop])
    if relaunch is not None:
        if nb < 2 or dd > -.10 or lo < start_low * .93 or c[t] > hi * 1.12: return None
        lvl = 3 if (sm <= .45 * bv and lo >= start_low and dd <= -.12) else 2
        return dict(level=lvl, phase='连板后调整(不破首板起点)→再放量/再板', seg=(k1-15, t), note=f'{nb}连板后回撤{dd:.0%}，调整期最低5日量为板期{sm/bv:.2f}倍，{"未破" if lo >= start_low else "略破"}首板起点；再启动{"涨停" if p[relaunch] >= L else "放量阳"}')
    if t - last_b < 5 or lo < start_low * .93: return None
    w0 = max(t-9, last_b+1)
    rng10 = a['high'][w0:t+1].max() / a['low'][w0:t+1].min() - 1
    sp = min(a['sp7'][t], max(a['m7'][t], a['m45'][t], a['m200'][t]) / min(a['m7'][t], a['m45'][t], a['m200'][t]) - 1)
    if rng10 <= .14 and np.mean(v[w0:t+1]) <= .6 * bv and sp <= .06 and c[t] >= a['m45'][t] * .97:
        lvl = 2 if nb >= 2 and sp <= .04 else 1
        return dict(level=lvl, phase='板后缩量收敛平台(待放量)', seg=(k1-15, t), note=f'{nb}板后回撤{dd:.0%}，10日振幅{rng10:.0%}、均线收敛{sp:.1%}、量为板期{np.mean(v[w0:t+1])/bv:.2f}倍')
    return None

# ---------------- T22 力聚热能 贴平MA200长期低波底座→首次放量起飞
def T22(a, t, code):
    if t < 262: return None
    c = a['close']; m200 = a['m200']; v = a['vol']
    for j in range(t-4, t+1):
        if not (a['vr'][j] >= 1.8 and a['pct'][j] >= 3 and c[j] > a['mmax'][j]): continue
        base = slice(j-120, j)
        if not np.isfinite(m200[j-61]) or abs(R(m200[j-1], m200[j-61])) > .04: continue
        mb = m200[base]; ok = np.isfinite(mb)
        if ok.sum() < 60: continue
        within = (np.abs(c[base][ok] / mb[ok] - 1) <= .08).mean()
        amp = a['high'][base].max() / a['low'][base].min() - 1
        lowv = np.mean(v[base]) / max(np.mean(v[j-250:j-120]), 1)
        prior = (a['vr'][base] >= 2.5).sum()
        if within >= .6 and amp <= .35 and prior <= 3 and R(c[t], c[j-1]) <= .15:
            lvl = 3 if within >= .75 and amp <= .28 and lowv <= 1.0 else 2
            return dict(level=lvl, phase='贴平MA200低波底座首次放量', seg=(j-120, t), note=f'120日贴MA200±8%占比{within:.0%}，底座振幅{amp:.0%}，放量{a["vr"][j]:.1f}倍')
    return None

# ---------------- T23 福建水泥 深跌底部刚反转
def T23(a, t, code):
    if t < 300: return None
    c = a['close']
    h_i = t-250 + int(np.argmax(a['high'][t-250:t-30])); H = a['high'][h_i]
    lo_i = t-45 + int(np.argmin(a['low'][t-45:t-3])); P = a['low'][lo_i]
    if P / H - 1 > -.35 or lo_i - h_i < 50: return None
    if P > a['m200'][lo_i] * .80: return None
    if a['low'][lo_i:t+1].min() < P: return None
    if not (1.10 <= c[t] / P <= 1.35 and c[t] > a['m45'][t]): return None
    jx = None
    for j in range(t-5, t+1):
        if a['m7'][j] > a['m45'][j] and a['m7'][j-1] <= a['m45'][j-1]: jx = j
    if jx is None: return None
    lvl = 3 if (P / H - 1 <= -.40 and a['m45'][t] >= a['m45'][t-3]) else 2
    return dict(level=lvl, phase='深坑底部刚反转(MA7上穿MA45)', seg=(h_i, t), note=f'高点回撤{P/H-1:.0%}，坑底低于MA200 {P/a["m200"][lo_i]-1:.0%}，离底{c[t]/P-1:.0%}')

# ---------------- T24 华安证券 抛物线后深回撤→MA120/200附近筑底→再现放量
def T24(a, t, code):
    if t < 420: return None
    c = a['close']
    ss = t-500 if t >= 500 else 0
    r30 = np.nanmax(a['r30'][ss+29:t-60])
    if not r30 >= .6: return None
    pk = ss + int(np.argmax(a['high'][ss:t-60])); Pk = a['high'][pk]
    if a['low'][pk:t+1].min() / Pk - 1 > -.30: return None
    nr = max(abs(R(c[t], a['m200'][t])), abs(R(c[t], a['m120'][t])))
    if nr > .12: return None
    rng60 = a['high'][t-59:t+1].max() / a['low'][t-59:t+1].min() - 1
    if rng60 > .28: return None
    sp = [x for x in range(t-9, t+1) if a['vr'][x] >= 1.8 and c[x] >= a['open'][x]]
    if len(sp) < 2 or R(c[t], c[t-10]) > .10: return None
    lvl = 3 if (len(sp) >= 3 and rng60 <= .20 and nr <= .06) else 2
    return dict(level=lvl, phase='抛物线后深回撤·长均线附近筑底再放量', seg=(t-120, t), note=f'前期30日涨幅峰值{r30:.0%}，前高回撤{a["low"][pk:t+1].min()/Pk-1:.0%}，近10日放量阳{len(sp)}根')

FUNCS = {1: T01, 2: T02, 3: T03, 4: T04, 5: T05, 6: T06, 7: T07, 8: T08, 9: T09, 10: T10, 11: T11, 12: T12,
         13: T13, 14: T14, 15: T15, 16: T16, 18: T18, 19: T19, 20: T20, 21: T21, 22: T22, 23: T23, 24: T24}
TNAMES = {1: '中国广核·多头回踩洗盘突破前', 2: '甘咨询·堆量后缩量待再启', 3: '澳洋健康·无量下杀V反首板', 4: '纳芯微·MA7刚上穿全部均线',
          5: '奥佳华·MA7刚上穿MA45', 6: '紫金龙净·温和上穿全部贴线', 7: '美诺华·缩量粘合垫后首放量', 8: '中科曙光/神剑·长底座均线交汇',
          9: '青木/昂利康·粘合后MA7上穿全部', 10: '欧圣电气·回踩汇合放量板回前高', 11: '宁波东力·板-姿势下来-再板', 12: '斯菱·创业板板后横盘守结构',
          13: '钧达·深跌低位多日异动量', 14: '善水·黄金坑修复', 15: '瑞芯微·老鸭头前夕', 16: '视源/华正·深洗后跳空三日不补',
          17: '金开新能·粘合后阴跌洗盘末', 18: '康龙化成·破MA200挖坑放量V回', 19: '先导智能·首波后缩量强调整待主升', 20: '蓝思科技·回踩MA200短破阳包阴收回',
          21: '正裕/天洋/圣阳/九阳/电光·连板后缩量再放量', 22: '力聚热能·贴平MA200底座首次放量', 23: '福建水泥·深坑底部刚反转', 24: '华安证券·抛物线后长均线筑底再放量'}
