import json, asyncio, glob, os, sys
from playwright.async_api import async_playwright
ROOT = '/workspace/fuyao/all_patterns_1112_v2/'
QA = ROOT + 'qa/'; os.makedirs(QA, exist_ok=True)
pages = sorted(glob.glob(ROOT + 'T*/report.html')) + [ROOT + 'top50/report.html']
FULL = '--full' in sys.argv
async def check(b, path):
    res = {'page': path.replace(ROOT, ''), 'errors': [], 'checks': {}}
    pg = await b.new_page(viewport={'width': 1480, 'height': 1000})
    pg.on('console', lambda m: res['errors'].append(m.text) if m.type == 'error' else None)
    pg.on('pageerror', lambda e: res['errors'].append(str(e)))
    await pg.goto('file://' + path); await pg.wait_for_timeout(1200)
    n = await pg.evaluate('window.__qa ? window.__qa.entries.length : -1'); res['checks']['entries'] = n
    idxs = list(range(n)) if FULL else sorted(set([0, 1, n // 2, n - 1]))
    cols = []
    for i in idxs:
        if i < 0 or i >= n: continue
        await pg.evaluate(f'window.__qa.select(window.__qa.entries[{i}].id)'); await pg.wait_for_timeout(50)
        v = await pg.evaluate('''()=>{const c=document.querySelector('canvas');const x=c.getContext('2d').getImageData(0,0,c.width,c.height).data;let s=new Set();for(let i=0;i<x.length;i+=4000)s.add(x[i]+','+x[i+1]+','+x[i+2]);return s.size}''')
        cols.append(v)
    res['checks']['canvas_colorful'] = bool(cols) and all(v > 20 for v in cols); res['checks']['min_colors'] = min(cols) if cols else 0; res['checks']['n_checked'] = len(cols)
    await pg.evaluate('window.__qa.select(window.__qa.entries[0].id)'); await pg.wait_for_timeout(150)
    cvs = await pg.query_selector('canvas'); await cvs.scroll_into_view_if_needed(); await pg.wait_for_timeout(150)
    box = await cvs.bounding_box()
    await pg.evaluate('window.__qa.zoom(0.6)'); await pg.wait_for_timeout(80)
    s0 = await pg.evaluate('window.__qa.view.start')
    await pg.mouse.move(box['x'] + 500, box['y'] + 200); await pg.mouse.down(); await pg.mouse.move(box['x'] + 800, box['y'] + 200, steps=8); await pg.mouse.up()
    s1 = await pg.evaluate('window.__qa.view.start')
    res['checks']['drag'] = [s0, s1, s0 != s1]
    c0 = await pg.evaluate('window.__qa.view.count')
    await pg.mouse.move(box['x'] + 500, box['y'] + 250); await pg.mouse.wheel(0, 300); await pg.wait_for_timeout(100)
    c1 = await pg.evaluate('window.__qa.view.count'); res['checks']['wheel'] = [c0, c1, c0 != c1]
    html = open(path, encoding='utf-8').read()
    res['checks']['disclaimer_end'] = html.rstrip().count('不构成投资建议') >= 1 and html.find('不构成投资建议。</p>\n</main>') > 0
    res['checks']['no_echarts'] = 'echarts' not in html.lower()
    res['checks']['links_ok'] = True
    import re
    for href in set(re.findall(r'href="([^"#]+)', html)) | set(re.findall(r"href='([^'#]+)", html)):
        if href.startswith('http'): continue
        if not os.path.exists(os.path.normpath(os.path.join(os.path.dirname(path), href))): res['checks']['links_ok'] = False; res.setdefault('bad_links', []).append(href)
    for src in re.findall(r'src="([^"]+)"', html):
        if not os.path.exists(os.path.normpath(os.path.join(os.path.dirname(path), src))): res['checks']['links_ok'] = False; res.setdefault('bad_links', []).append(src)
    if 'top50' in path or 'T01' in path or 'T13' in path:
        el = await pg.query_selector('.wrap'); await el.scroll_into_view_if_needed()
        await pg.screenshot(path=QA + res['page'].split('/')[0] + '_viewer.png', clip={'x': 0, 'y': (await el.bounding_box())['y'] - 60, 'width': 1480, 'height': 980})
    await pg.close()
    res['ok'] = (not res['errors']) and res['checks']['canvas_colorful'] and res['checks']['drag'][2] and res['checks']['wheel'][2] and res['checks']['disclaimer_end'] and res['checks']['no_echarts'] and res['checks']['links_ok']
    return res
async def main():
    out = []
    async with async_playwright() as p:
        b = await p.chromium.launch(executable_path='/usr/bin/google-chrome', args=['--no-sandbox'])
        for path in pages: out.append(await check(b, path)); print(out[-1]['page'], out[-1]['ok'], out[-1]['checks'], [e[:150] for e in out[-1]['errors'][:2]], out[-1].get('bad_links'))
        pg = await b.new_page(viewport={'width': 1280, 'height': 900}); errs = []
        pg.on('pageerror', lambda e: errs.append(str(e)))
        await pg.goto('file://' + ROOT + 'index.html'); await pg.wait_for_timeout(500)
        nl = await pg.evaluate('document.querySelectorAll("a").length'); await pg.screenshot(path=QA + 'index.png')
        out.append({'page': 'index.html', 'ok': not errs and nl >= 25, 'links': nl, 'errors': errs})
        await b.close()
    json.dump(out, open(QA + 'browser_validation.json', 'w'), ensure_ascii=False, indent=1)
    print('ALL OK' if all(x['ok'] for x in out) else 'SOME FAIL', sum(x['ok'] for x in out), '/', len(out))
asyncio.run(main())
