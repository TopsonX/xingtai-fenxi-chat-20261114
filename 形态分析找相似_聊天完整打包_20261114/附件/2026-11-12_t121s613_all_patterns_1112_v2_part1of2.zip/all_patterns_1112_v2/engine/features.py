import pandas as pd, numpy as np, json, sys
sys.path.insert(0, '/workspace/fuyao/summary_1104')
D = '/workspace/fuyao/market_daily/'
QT = json.load(open('/workspace/fuyao/summary_1104/qt_all.json'))
src = open('/workspace/fuyao/summary_1104/feat.py').read()
ns = {'np': np}
exec(src[src.index('def chips('):src.index('def proc(')], ns)
chips = ns['chips']
def lim(code): return 19.5 if code[2:].startswith(('300', '301', '688', '689')) else 9.7
def feats(code):
    d = pd.read_csv(D + code + '.csv').dropna()
    d = d[(d.low > 0) & (d.vol > 0)].reset_index(drop=True)
    f = QT.get(code); fs = float(f[72] or 0) if f else 0; fcap_1104 = float(f[44] or 0) if f else 0; c1104 = float(f[3] or 0) if f else 0
    o, h, l, c, v = [d[k].values.astype(float) for k in ['open', 'high', 'low', 'close', 'vol']]
    C = pd.Series(c); V = pd.Series(v); pct = C.pct_change() * 100
    L = lim(code); lu = (pct >= L).values
    m = {w: C.rolling(w).mean().values for w in (7, 45, 120, 180, 200)}
    mmax = max(m[45][-1], m[120][-1], m[200][-1])
    v20 = V.shift(1).rolling(20).mean(); vr = V / v20
    up = pct > 0; dn = pct < 0
    obv = (np.sign(pct.fillna(0)) * V).cumsum()
    to = v * 100 / fs if fs > 0 else np.zeros(len(v))
    w, cc, ov, co = chips(o, h, l, c, to)
    n = len(c)
    r = dict(code=code, name=(f[1] if f else code), close=c[-1], date=d.date.iloc[-1],
             ret5=c[-1] / c[-6] - 1, ret20=c[-1] / c[-21] - 1, ret60=c[-1] / c[-61] - 1,
             ext=c[-1] / mmax - 1, lu20=int(lu[-20:].sum()), lu60=int(lu[-60:].sum()), lu250=int(lu[-250:].sum()),
             amp250=c[-250:].max() / c[-250:].min() - 1, dd250=c[-1] / h[-250:].max() - 1,
             ud20=float((V * up).iloc[-20:].sum() / ((V * dn).iloc[-20:].sum() + 1)),
             obv60=float((obv.iloc[-1] - obv.iloc[-61]) / V.iloc[-60:].sum()),
             v20_v250=float(V.iloc[-20:].mean() / V.iloc[-250:].mean()),
             trial60=int((vr.shift(1).iloc[-60:] >= 2.5).sum()),
             to20=float(np.mean(to[-20:]) * 100) if fs > 0 else np.nan, to_d=float(to[-1] * 100) if fs > 0 else np.nan,
             fcap=(fcap_1104 * c[-1] / c1104) if (fcap_1104 > 0 and c1104 > 0) else np.nan,
             ma200_s20=m[200][-1] / m[200][-21] - 1,
             winner=float(w[-1]), conc90=float(cc[-1]), over15=float(ov[-1]), cost_r=float(co[-1]),
             board='创业板' if code[2:5] in ('300', '301') else ('科创板' if code[2:5] in ('688', '689') else '主板'))
    return r
if __name__ == '__main__':
    print(feats(sys.argv[1]))
