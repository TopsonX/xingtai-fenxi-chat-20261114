import json, numpy as np, pickle
src = open('stats.py').read()
exec(src[src.index('def label('):src.index('# baseline')])
B = json.load(open('out/stats.json'))['baseline']
J = json.load(open('/workspace/fuyao/all_patterns_1112_v2/t17/scan_results.json'))
QT = json.load(open('/workspace/fuyao/summary_1104/qt_all.json'))
import pandas as pd
rk = pd.read_parquet('/workspace/fuyao/summary_1104/ranked.parquet').set_index('code')
UTIL = ('银行', '电力', '燃气', '水务', '铁路公路', '证券', '环境治理', '航运港口', '保险')
rows = []; recs = []; rows_nu = []
for e in J['events']:
    o = []
    for h in (10, 20, 40):
        o.append((e[f'mfe{h}'], e[f'mae{h}'], e[f'ret{h}f']) if e.get(f'mature{h}') else None)
    lvl = {'更贴': 3, '次贴': 2, '观察': 1}.get(e.get('tier'), 2)
    if lvl < 2: continue
    rows.append((o[0], o[1], o[2], lvl, 0, e['date']))
    ind = str(rk.ind.get(e['code'], ''))
    if not any(u in ind for u in UTIL): rows_nu.append((o[0], o[1], o[2], lvl, 0, e['date']))
    recs.append((e['code'], e['date'], lvl, e['close'], o, 0, label(o), 0, None))
S = summarize(rows); S['L3'] = summarize([x for x in rows if x[3] == 3])
S['era_le2023'] = summarize([x for x in rows if x[5] < '2024-01-01']); S['era_ge2024'] = summarize([x for x in rows if x[5] >= '2024-01-01'])
S['non_util'] = summarize(rows_nu)
S['lift_起点'] = S['p_行情起点'] / B['p_行情起点'] if S.get('p_行情起点') is not None else None
S['examples_recent'] = [list(x) for x in sorted(recs, key=lambda z: z[1])[-400:]]
json.dump(S, open('out/stats_t17.json', 'w'), ensure_ascii=False, indent=1, default=str)
cal = [e for e in J['events'] if e['code'] == 'sh600821']
print('T17 n', S['n'], 'p起点', S.get('p_行情起点'), 'lift', S.get('lift_起点'), '几日游', S.get('p_几日游'), 'jinkai events', [(e['date'], e['tier']) for e in cal])
