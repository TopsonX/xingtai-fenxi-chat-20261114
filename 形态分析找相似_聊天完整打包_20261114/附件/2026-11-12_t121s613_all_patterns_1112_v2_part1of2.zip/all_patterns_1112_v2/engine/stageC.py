# capital / fundamentals / theme / tiers per template + composite
import pandas as pd, numpy as np, json, os, glob, collections, sys, pickle
import tpl
OUT = '/workspace/fuyao/all_patterns_1112_v2/engine/out'
FD = '/workspace/fuyao/all_patterns_1112_v2/flows/'; SD = '/workspace/fuyao/all_patterns_1112_v2/sources/'
ASOF = sys.argv[1] if len(sys.argv) > 1 else '2026-11-12'
F = pd.read_pickle(f'{OUT}/stageA.pkl')
ST = json.load(open(f'{OUT}/stats.json'))
TS = ST['templates']; TS['17'] = json.load(open(f'{OUT}/stats_t17.json')) if os.path.exists(f'{OUT}/stats_t17.json') else TS.get('17', {})
UTIL = ('银行', '电力', '燃气', '水务', '铁路公路', '证券', '环境治理', '航运港口', '保险', '高速公路', '港口')
# ---- LHB aggregate
P = '/workspace/fuyao_lhb_market/'
rows = json.load(open(P + 'market_all.json'))
have = set(r.get('trade_date') for r in rows)
for f in sorted(glob.glob(P + 'daily/all/2026-1*.json')):
    j = json.load(open(f)); dd = j.get('data') or {}
    if dd.get('trade_date') in have: continue
    for it in dd.get('stock_items') or []:
        it = dict(it); it['trade_date'] = dd.get('trade_date'); rows.append(it)
df = pd.DataFrame(rows)
df = df[df.ticker.astype(str).str.match(r'^(60|68|00|30)\d{4}$')]
df['code'] = df.ticker.astype(str).map(lambda x: ('sh' if x.startswith('6') else 'sz') + x)
df = df.sort_values('range_days').drop_duplicates(['code', 'trade_date'], keep='first')
dates = sorted(df.trade_date.dropna().unique())
LHB_RANGE = [dates[0], dates[-1], len(dates)]
l60, l20, l5 = set(dates[-60:]), set(dates[-20:]), set(dates[-5:])
LH = {}
for code, g in df.groupby('code'):
    r = {}
    for lab, S in [('60', l60), ('20', l20), ('5', l5)]:
        x = g[g.trade_date.isin(S)]
        r['lhb_n' + lab] = int(len(x)); r['org_net' + lab] = float(x.org_net_value.fillna(0).sum() / 1e8); r['hot_net' + lab] = float(x.hot_money_net_value.fillna(0).sum() / 1e8)
    r['lhb_last'] = g.trade_date.max(); LH[code] = r
for k in ['lhb_n60', 'org_net60', 'hot_net60', 'lhb_n20', 'org_net20', 'hot_net20', 'lhb_n5', 'org_net5', 'hot_net5']:
    F[k] = [LH.get(c, {}).get(k, 0) for c in F.index]
F['lhb_last'] = [LH.get(c, {}).get('lhb_last') for c in F.index]
# ---- snapshots
rk = pd.read_parquet('/workspace/fuyao/summary_1104/ranked.parquet').set_index('code')
for c in ['ind', 'rz_chg', 'hn_ratio', 'org_q3', 'org_h1', 'fund_h1', 'fund_q1', 'hn_end']:
    F[c] = rk[c].reindex(F.index)
cpd = pd.read_parquet('/workspace/fuyao/summary_1104/cpd.parquet'); cpd['R'] = pd.to_datetime(cpd.REPORTDATE)
q3 = cpd[cpd.R == pd.Timestamp('2026-09-30')].sort_values('NOTICE_DATE').drop_duplicates('SECURITY_CODE', keep='last')
q3['code'] = q3.SECURITY_CODE.astype(str).str.zfill(6).map(lambda x: ('sh' if x.startswith('6') else 'sz') + x); q3 = q3.set_index('code')
F['rev_yoy'] = q3.YSTZ.reindex(F.index); F['np_yoy'] = q3.SJLTZ.reindex(F.index)
F['np'] = q3.PARENT_NETPROFIT.reindex(F.index) / 1e8; F['rev'] = q3.TOTAL_OPERATE_INCOME.reindex(F.index) / 1e8
F['gm'] = q3.XSMLL.reindex(F.index); F['roe'] = q3.WEIGHTAVG_ROE.reindex(F.index)
F['ind'] = F['ind'].fillna(q3.PUBLISHNAME.reindex(F.index)).fillna('')
F['fin_src'] = np.where(F.rev_yoy.notna(), '2026三季报(东财CPD)', '无三季报数据')
# limit-up archive
la = pd.read_csv('/workspace/archive_limitup_2y.csv', dtype={'code': str})
la['code'] = la.code.str.zfill(6).map(lambda x: ('sh' if x.startswith('6') else 'sz') + x)
lag = la.sort_values('date').groupby('code')
F['lu_last'] = lag.date.last().reindex(F.index); F['lu_reason'] = lag.reason.last().reindex(F.index)
F['concept'] = lag.concept.last().reindex(F.index) if 'concept' in la else None
# ---- flows
def flow(code):
    p = FD + code + '.json'
    if not os.path.exists(p): return {}
    try: k = [x.split(',') for x in json.load(open(p))['data']['klines'] if x[:10] <= ASOF]
    except Exception: return {}
    if not k: return {}
    m = [float(x[1]) / 1e8 for x in k]; ratio = [float(x[6]) for x in k]; sup = [float(x[5]) / 1e8 for x in k]
    return dict(mf1=m[-1], mf5=sum(m[-5:]), mf10=sum(m[-10:]), mf20=sum(m[-20:]), mf60=sum(m[-60:]), mfr10=float(np.mean(ratio[-10:])), xl10=sum(sup[-10:]), mf_last=k[-1][0], mf_days=len(k),
                pos10=sum(1 for x in m[-10:] if x > 0))
FL = pd.DataFrame({c: flow(c) for c in F.index}).T
for c in ['mf1', 'mf5', 'mf10', 'mf20', 'mf60', 'mfr10', 'xl10', 'mf_last', 'mf_days', 'pos10']:
    F[c] = FL[c].reindex(F.index) if c in FL else np.nan
for c in ['mf1', 'mf5', 'mf10', 'mf20', 'mf60', 'mfr10', 'xl10', 'pos10']: F[c] = pd.to_numeric(F[c], errors='coerce')
# ---- themes
def theme(code):
    p = SD + code + '.json'
    if not os.path.exists(p): return ''
    th = json.load(open(p)).get('theme') or []
    kw = []; boards = []
    GEN = ('所属板块', '经营范围', '主营业务', '公司简介', '行业地位')
    for t in th:
        k = (t.get('KEYWORD') or '').strip()
        if k == '所属板块':
            boards = [b for b in str(t.get('MAINPOINT_CONTENT') or '').split() if b and not any(x in b for x in ('标准普尔', '富时罗素', 'MSCI', '融资融券', '深股通', '沪股通', '预盈预增', '预亏预减', '创业板综', '深成500', '中证500', '上证380', 'HS300', '转债标的', '机构重仓', 'QFII', '社保重仓', '基金重仓', '专精特新'))][:8]
            continue
        if k and k not in kw and k not in GEN:
            kw.append(k)
    out = '、'.join(kw[:6])
    if boards: out += ('；' if out else '') + '所属板块：' + ' '.join(boards)
    return out
F['theme'] = [theme(c) for c in F.index]
def theme_pt(code):
    p = SD + code + '.json'
    if not os.path.exists(p): return ''
    th = json.load(open(p)).get('theme') or []
    for t in th:
        if t.get('MAINPOINT_CONTENT') and t.get('KEYWORD') not in ('所属板块',):
            return (t.get('KEYWORD') or '') + '：' + t['MAINPOINT_CONTENT'][:90]
    return ''
F['theme_pt'] = [theme_pt(c) for c in F.index]
# ---- scores
f = lambda s: s.fillna(False).astype(float)
cap = (f(F.ud20 > 1.2) + f(F.obv60 > .1) + f(F.v20_v250.between(1.0, 2.2)) - f(F.v20_v250 > 3) + f(F.rz_chg > .05) + f(F.hn_ratio < -3)
       + f((F.org_q3 > F.org_h1) | (F.fund_h1 > F.fund_q1)) + .5 * f(F.winner > .6) + .5 * f(F.over15 < .1)
       + 1.5 * f(F.org_net60 > .3) + .5 * f(F.org_net60 > 0) - 1 * f(F.org_net60 < -.5) - .5 * f((F.hot_net60 > 1) & (F.org_net60 <= 0)) - .5 * f(F.lhb_n60 >= 3) - 1 * f(F.trial60 >= 3)
       + 1 * f(F.mf10 > 0) + .5 * f(F.mf20 > 0) + .5 * f(F.mfr10 > 2) + .5 * f(F.mf5 > 0) - 1 * f((F.mf10 < 0) & (F.mfr10 < -3)))
trait = (f(F.lu250 <= 2) + f(F.to20 < 5) + .5 * f(F.to_d < 3) + f(F.board != '主板') + f(F.trial60 == 0) + f(F.ma200_s20 > 0) + .5 * f(F.fcap.between(30, 500)) + .5 * f(F.conc90 > .27))
fund = (f(F.rev_yoy > 20) + .5 * f(F.rev_yoy > 50) + f(F.np_yoy > 30) + .5 * f(F.np > 0) - 1.5 * f(F.np <= 0) - 1 * f(F.np_yoy < -30))
F['cap'] = cap; F['trait'] = trait; F['fund'] = fund
F['style'] = np.where((F.lu60 >= 4) | (F.to20 >= 15) | ((F.hot_net20 > .5) & (F.org_net20 <= 0)), '游资偏向', np.where((F.lu60 <= 1) & (F.to20 < 8) & (F.org_net60 >= 0), '机构偏向', '中性'))
F['lowvol'] = (F.amp250 < .40) | F['ind'].str.contains('|'.join(UTIL))
FAM = {4: 'cross', 5: 'cross', 6: 'cross', 9: 'cross', 7: 'coil', 8: 'coil', 17: 'coil', 22: 'coil', 1: 'pull', 2: 'pull', 14: 'pull', 19: 'pull', 20: 'pull', 24: 'pull',
       10: 'board', 3: 'board', 11: 'board', 12: 'board', 21: 'board', 13: 'low', 18: 'low', 23: 'low', 15: 'duck', 16: 'gap'}
BAR = ('cross', 'coil', 'pull')
def lift(k):
    s = TS.get(str(k), {}); return float(np.clip(s.get('lift_起点') or 1.0, .7, 1.6))
def sus(k):
    s = TS.get(str(k), {}); return (s.get('p_行情起点') or .17) - (s.get('p_几日游') or .15)
def risk(r):
    x = []
    if r['style'] == '游资偏向': x.append('游资偏向')
    if not (r['np'] > 0): x.append('亏损或无三季报')
    if r['lu20'] >= 2: x.append('近20日≥2板')
    if (r['fcap'] or 0) < 30 and (r['to20'] or 0) > 10: x.append('小盘高换手')
    if r['trial60'] >= 3: x.append('60日≥3次试盘巨量')
    if r['hot_net20'] > .5 and r['org_net20'] <= 0: x.append('龙虎榜游资净买主导')
    if r['mf10'] < 0 and r['mfr10'] < -3: x.append('主力10日明显净流出')
    if r['lowvol']: x.append('低波动/公用类(粘合是常态)')
    return x
F['risk'] = F.apply(risk, axis=1)
def ttier(k, h, r):
    lvl = h['level']; barred = r['lowvol'] and FAM[k] in BAR
    neg = (r['mf10'] < 0 and r['mfr10'] < -3)
    if lvl == 3 and r['cap'] >= 3.5 and not (r['mf10'] < 0) and r['style'] != '游资偏向' and r['np'] > 0 and ((r['rev_yoy'] or -1) > 0 or (r['np_yoy'] or -1) > 0) and not barred and r['trial60'] < 3:
        return '更贴'
    if lvl >= 2 and r['cap'] >= 2.5 and not neg and not barred and (r['np'] > 0 or (r['rev_yoy'] or 0) > 30):
        return '次贴'
    return '观察'
g = F[F.gate == ''].copy()
g = g[g.cur.map(len) > 0]
# per template candidate tables
per = {}
for k in list(tpl.FUNCS) + [17]:
    rows = []
    for c, r in g.iterrows():
        if k not in r.cur: continue
        h = r.cur[k]; t = ttier(k, h, r)
        rows.append(dict(code=c, tier=t, level=h['level'], hit=h))
    # sort: tier, then capital-led score
    if rows:
        sub = g.loc[[x['code'] for x in rows]]
        sc = (.45 * sub.cap.rank(pct=True) + .25 * sub.fund.rank(pct=True) + .15 * sub.trait.rank(pct=True)).to_dict()
        for x in rows: x['score'] = round(100 * (sc[x['code']] + .15 * x['level'] / 3), 1)
        rows.sort(key=lambda x: ({'更贴': 0, '次贴': 1, '观察': 2}[x['tier']], -x['score']))
    per[k] = rows
# near-misses: gated-out current hits + fired within 15 bars
nm = {}
for k in list(tpl.FUNCS) + [17]:
    L = []
    for c, r in F.iterrows():
        if r['lowvol'] and FAM.get(k) in BAR: continue
        if k in r.cur and r.gate:
            L.append(dict(code=c, why='相位/流动性过滤：' + r.gate.rstrip(';'), hit=r.cur[k], cap=r.cap))
        elif k in r.near and not r.gate and k not in r.cur:
            L.append(dict(code=c, why=f"{r.near[k].get('last_fire')} 曾触发，今日条件已不满足", hit=r.near[k], cap=r.cap))
    L.sort(key=lambda x: -x['cap'])
    nm[k] = L[:20]
# composite
def tf(h, lv):
    fam = collections.defaultdict(list)
    for k, v in h.items():
        fam[FAM[k]].append(v['level'] * lift(k) * (.5 if lv and FAM[k] in BAR else 1))
    return min(10, sum(max(v) + .25 * (len(v) - 1) for v in fam.values()))
g['TF'] = [tf(h, lv) for h, lv in zip(g.cur, g.lowvol)]
g['sus'] = [np.mean([sus(k) for k in h]) + (.05 if s == '机构偏向' else -.05 if s == '游资偏向' else 0) for h, s in zip(g.cur, g['style'])]
g['ttiers'] = [{k: ttier(k, h[k], r) for k in h} for (c, r), h in zip(g.iterrows(), g.cur)]
g['score'] = 100 * (.35 * g.cap.rank(pct=True) + .20 * g.TF.rank(pct=True) + .20 * g.fund.rank(pct=True) + .10 * g.trait.rank(pct=True) + .15 * g.sus.rank(pct=True))
def ctier(r):
    tt = list(r.ttiers.values())
    n1 = tt.count('更贴'); n2 = tt.count('次贴')
    if n1 >= 1 and len(r.risk) == 0 and r.mf10 >= 0: return '更贴'
    if n1 + n2 >= 1 and len(r.risk) <= 1: return '次贴'
    return '观察'
g['ctier'] = g.apply(ctier, axis=1)
g['tord'] = g.ctier.map({'更贴': 0, '次贴': 1, '观察': 2})
g = g.sort_values(['tord', 'score'], ascending=[True, False])
pickle.dump(dict(F=F, g=g, per=per, nm=nm, LHB_RANGE=LHB_RANGE), open(f'{OUT}/stageC.pkl', 'wb'))
print('LHB', LHB_RANGE, 'flows有', int(F.mf10.notna().sum()), '/', len(F))
print('composite tiers', g.ctier.value_counts().to_dict())
for k, rows in per.items():
    c = collections.Counter(x['tier'] for x in rows)
    print(k, tpl.TNAMES[k][:14], len(rows), dict(c), 'near', len(nm[k]))
pd.set_option('display.width', 250)
print(g.head(60)[['name', 'ctier', 'score', 'cap', 'TF', 'fund', 'trait', 'sus', 'style', 'mf10', 'org_net60', 'rev_yoy', 'np_yoy', 'ret20', 'ext']].round(2).to_string())
