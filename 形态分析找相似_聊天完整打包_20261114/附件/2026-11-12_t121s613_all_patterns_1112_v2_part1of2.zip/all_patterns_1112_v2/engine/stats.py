import pickle, json, numpy as np, pandas as pd, sys
import tpl
OUT = '/workspace/fuyao/all_patterns_1112_v2/engine/out'
R = pickle.load(open(f'{OUT}/scan_raw.pkl', 'rb'))
QT = json.load(open('/workspace/fuyao/summary_1104/qt_all.json'))
def isst(code):
    q = QT.get(code); return bool(q and ('ST' in q[1] or '退' in q[1]))
def label(o):
    o10, o20, o40 = o
    if o40 is None: return None
    if o40[0] >= .25 and o40[2] >= .10: return '行情起点'
    if ((o10 and o10[0] >= .10) or (o20 and o20[0] >= .12)) and o40[2] <= .02: return '几日游'
    if o40[0] < .08: return '无行情'
    return '一般'
def summarize(rows):
    # rows: list of (o10,o20,o40,level,lu60,date)
    out = {'n': len(rows)}
    for i, h in enumerate((10, 20, 40)):
        x = np.array([r[i] for r in rows if r[i] is not None], dtype=float)
        if len(x) == 0: continue
        out[f'n{h}'] = len(x)
        out[f'mfe{h}'] = [float(np.percentile(x[:, 0], q)) for q in (25, 50, 75)]
        out[f'mae{h}'] = [float(np.percentile(x[:, 1], q)) for q in (25, 50, 75)]
        out[f'ret{h}'] = [float(np.percentile(x[:, 2], q)) for q in (25, 50, 75)]
        out[f'win{h}'] = float((x[:, 2] > 0).mean())
        out[f'p_mfe10_{h}'] = float((x[:, 0] >= .10).mean())
        out[f'p_mfe20_{h}'] = float((x[:, 0] >= .20).mean())
        out[f'p_mae10_{h}'] = float((x[:, 1] <= -.10).mean())
    labs = [label(r[:3]) for r in rows]; labs = [l for l in labs if l]
    out['n_mature40'] = len(labs)
    for l in ('行情起点', '几日游', '无行情', '一般'):
        out['p_' + l] = (labs.count(l) / len(labs)) if labs else None
    return out
# baseline
base = []
for r in R:
    if 'err' in r or isst(r['code'][2:]): continue
    for t, dt, o in r['base']: base.append((o[0], o[1], o[2], 0, 0, dt))
B = summarize(base)
ST = {'baseline': B, 'templates': {}}
ev_all = {}
for k in tpl.FUNCS:
    rows = []; recs = []
    for r in R:
        if 'err' in r or isst(r['code'][2:]): continue
        for t, dt, lvl, c, o, lu60, lu250, m2up in r['events'].get(k, []):
            brd = r['code'][2:5] in ('300', '301', '688', '689')
            rows.append((o[0], o[1], o[2], lvl, lu60, dt, lu250, m2up, brd)); recs.append((r['code'], dt, lvl, c, o, lu60, label(o), lu250, m2up))
    S = summarize(rows)
    S['examples_recent'] = [list(x) for x in sorted(recs, key=lambda z: z[1])[-400:]]
    S['L3'] = summarize([x for x in rows if x[3] == 3])
    S['era_le2023'] = summarize([x for x in rows if x[5] < '2024-01-01'])
    S['era_ge2024'] = summarize([x for x in rows if x[5] >= '2024-01-01'])
    S['hot_lu60ge3'] = summarize([x for x in rows if x[4] >= 3])
    S['calm_lu60le1'] = summarize([x for x in rows if x[4] <= 1])
    S['m200up'] = summarize([x for x in rows if x[7]])
    S['m200down'] = summarize([x for x in rows if not x[7]])
    S['nolu250'] = summarize([x for x in rows if x[6] == 0])
    S['cy_kc'] = summarize([x for x in rows if x[8]])
    S['inst_like'] = summarize([x for x in rows if x[7] and x[4] <= 1])
    if S.get('p_行情起点') is not None and B['p_行情起点']:
        S['lift_起点'] = S['p_行情起点'] / B['p_行情起点']
    ST['templates'][k] = S
    ev_all[k] = recs
json.dump(ST, open(f'{OUT}/stats.json', 'w'), ensure_ascii=False, indent=1)
pickle.dump(ev_all, open(f'{OUT}/events_all.pkl', 'wb'))
print('baseline n', B['n'], 'p起点 %.3f p几日游 %.3f mfe20 med %.3f' % (B['p_行情起点'], B['p_几日游'], B['mfe20'][1]))
for k, S in ST['templates'].items():
    print(k, tpl.TNAMES[k][:12], 'n', S['n'], 'L3', S['L3']['n'], 'p起点 %.3f lift %.2f 几日游 %.3f 无 %.3f mfe20 %.3f mae20 %.3f ret40 %.3f | le23 %.3f ge24 %.3f' % (
        S['p_行情起点'] or 0, S.get('lift_起点', 0), S['p_几日游'] or 0, S['p_无行情'] or 0, S['mfe20'][1], S['mae20'][1], S['ret40'][1],
        S['era_le2023'].get('p_行情起点') or 0, S['era_ge2024'].get('p_行情起点') or 0))
