import pickle, json, os, numpy as np, pandas as pd, sys, collections, math
sys.argv = sys.argv[:2]
exec(open('build.py').read().split('# ======================= per-template reports')[0])
SUMMARY = json.load(open(OUT + 'template_summary.json'))
top = g.head(50).copy()
ents = []; rows = ''
for i, (code, r) in enumerate(top.iterrows(), 1):
    hits = r.cur
    # main template: best (ttier, level*lift)
    order = sorted(hits, key=lambda k: ({'更贴': 0, '次贴': 1, '观察': 2}[r.ttiers[k]], -hits[k]['level'] * lift_(k) if False else -hits[k]['level'], k))
    mk = order[0]
    links = [dict(href=f"../{SLUG[k]}/report.html#{code}", text=f"T{k:02d} {TN[k].split('·')[0]}({r.ttiers[k]})") for k in sorted(hits)]
    sus_note = '；'.join(f"T{k:02d} 历史行情起点{(TS.get(str(k),{}).get('p_行情起点') or 0)*100:.0f}%/几日游{(TS.get(str(k),{}).get('p_几日游') or 0)*100:.0f}%" for k in sorted(hits)) + f"（基准 {B['p_行情起点']*100:.0f}%/{B['p_几日游']*100:.0f}%）；风格 {r['style']}。"
    e = entry_for(code, mk, hits[mk], r.ctier, i, links=links, id_=code, sus_note=sus_note)
    others = [f"T{k:02d}{TN[k].split('·')[1][:10]}({LVL.get(hits[k]['level'])}·{r.ttiers[k]})" for k in sorted(hits)]
    e['w'].insert(0, ['共振', f"命中 {len(hits)} 个模板：" + '、'.join(others) + f"。综合分 {r.score:.1f}（资金{r.cap:.1f}/形态{r.TF:.1f}/业绩{r.fund:.1f}/启动特征{r.trait:.1f}）。"])
    e['sub'] = f"{r.score:.0f}·{len(hits)}模板"; e['score'] = round(r.score, 1)
    feats = []
    if r.board != '主板': feats.append('创业/科创')
    if r.lu250 == 0: feats.append('一年无涨停')
    if (r.to_d or 9) < 3: feats.append('换手<3%')
    if r.trial60 == 0: feats.append('60日无试盘巨量')
    if (r.conc90 or 0) > .27: feats.append('筹码分散>27%')
    if (r.fcap or 0) > 150: feats.append('流通>150亿')
    if (r.rev_yoy or 0) > 20: feats.append('营收>20%')
    if r.ma200_s20 > 0: feats.append('MA200上行')
    e['tags'] += feats
    ents.append(e)
    one = f"{TN[mk].split('·')[1]}；主力10日{Y(r.mf10)}亿、机构龙虎榜60日{Y(r.org_net60)}亿；营收{N(r.rev_yoy,0)}%/净利{N(r.np_yoy,0)}%；{r['style']}"
    rows += (f"<tr><td>{i}</td><td><a href='#{code}'>{code}</a></td><td>{esc(r['name'])}</td><td class='t-{r.ctier}'>{r.ctier}</td><td>{r.score:.1f}</td><td>{' '.join(f'<a href=\"../{SLUG[k]}/report.html#{code}\">T{k:02d}</a>' for k in sorted(hits))}</td>"
             f"<td>{r.cap:.1f}</td><td>{Y(r.mf10)}</td><td>{Y(r.org_net60)}</td><td>{N(r.rev_yoy,0)}%/{N(r.np_yoy,0)}%</td><td>{esc(r['style'])}</td><td>{esc('；'.join(r.risk) or '—')}</td></tr>")
tc = collections.Counter(top.ctier)
gc = collections.Counter(g.ctier)
tsum = ''.join(f"<tr><td><a href='../{v['slug']}/report.html'>T{int(k):02d}</a></td><td>{esc(v['name'])}</td><td>{'；'.join(f'{a} {b}' + ('✅' if c else '❌') for a, b, c in v['calib'])}</td><td>{v['n'] or '—'}</td><td>{(v['p_start'] or 0)*100:.1f}%</td><td>{N(v['lift'])}</td><td>{(v['p_trip'] or 0)*100:.1f}%</td><td>{v['tiers'].get('更贴',0)}/{v['tiers'].get('次贴',0)}/{v['tiers'].get('观察',0)}</td><td>{sum(1 for c in top.index if int(k) in top.loc[c,'cur'])}</td></tr>" for k, v in sorted(SUMMARY.items(), key=lambda z: int(z[0])))
mrows = ''.join(f"<tr><td>{d}</td><td>{v['up']}</td><td>{v['dn']}</td><td>{v['lu']}</td><td>{v['ld']}</td><td>{v['gap']}</td></tr>" for d, v in MK['per_day'].items())
style_c = collections.Counter(top['style'])
body = HEAD(f'综合前50 · {ASOF}', '../') + f"""
<p><a href="../index.html">← 总目录</a></p>
<h1>全形态逐一回测 · 综合推荐前50</h1><div class=meta>数据截至 <b>{ASOF} 收盘</b>（新加坡时间 UTC+8，同北京时间）｜ 生成于 {pd.Timestamp.now().strftime('%Y-%m-%d %H:%M')} UTC+8</div>
<section class=card><h2>结论先看</h2><ul>
<li>24 套形态（原 17 套 + 记忆里补充的 康龙化成/先导智能/蓝思科技/连板家族/力聚热能/福建水泥/华安证券 7 套）逐一校准、逐一回测、逐一出报告，见下表链接。</li>
<li>通过相位过滤、且至少命中一个模板的股票 {len(g)} 只：综合更贴资格 {gc.get('更贴',0)}、次贴资格 {gc.get('次贴',0)}、其余观察。前50 = <b>更贴 {tc.get('更贴',0)} / 次贴 {tc.get('次贴',0)} / 观察 {tc.get('观察',0)}</b>；机构偏向 {style_c.get('机构偏向',0)}、中性 {style_c.get('中性',0)}、游资偏向 {style_c.get('游资偏向',0)}。</li>
<li>综合分 = 0.35×资金分位 + 0.20×形态共振分位（各模板相似度×该模板历史“行情起点”倍数，同类模板只算一次）+ 0.20×业绩/增长分位 + 0.10×11-04 启动特征分位 + 0.15×持续性分位（命中模板的历史“行情起点−几日游”，机构偏向+、游资偏向−）。<b>更贴</b>=至少一个模板判“更贴”、无风险标签、主力10日不为净流出；<b>次贴</b>=至少一个模板判“更贴/次贴”且风险标签≤1。</li>
<li>重要的回测事实：单靠形态规则，多数模板 40 日“行情起点”概率和全市场随机抽样差不多（倍数≈0.9–1.1）；相对好的是 T13 钧达式低位异动量、T03 无量下杀V反首板、T10 回踩汇合放量回前高、T23 深坑刚反转、T11 板洗再板（但几日游也多）。所以排序里资金面权重最大，形态只是入口。</li>
</ul></section>
<section class=card><h2>数据刷新</h2><p>{esc(RF.get('text','—'))}</p><p>龙虎榜：{Z['LHB_RANGE'][0]} 至 {Z['LHB_RANGE'][1]}（{Z['LHB_RANGE'][2]} 个交易日）。主力资金流：新浪资金流向（主力=超大单+大单）日度，取到 {esc(str(F.mf_last.dropna().max()))}，覆盖 {int(F.mf10.notna().sum())}/{len(F)} 只。财务：2026 三季报（东财 CPD）；题材：东财 F10 核心题材；融资 11-03、股东户数/机构持股为最新季度快照；筹码为近似模型。</p></section>
<section class=card><h2>市场背景</h2><p>有效池 {MK['n']} 只中仅 <b>{MK['pct_above_ma200']*100:.0f}%</b> 在 MA200 上方，5日涨幅中位 {MK['median_ret5']*100:+.1f}%。</p><table><tr><th>日期</th><th>上涨</th><th>下跌</th><th>涨停</th><th>跌停</th><th>向上跳空</th></tr>{mrows}</table></section>
<section class=card><h2>24 套模板一览（校准 / 回测 / 当前分层）</h2><table><tr><th>#</th><th>模板</th><th>样例校准</th><th>历史事件</th><th>40日行情起点</th><th>相对基准</th><th>几日游</th><th>当前 更贴/次贴/观察</th><th>前50中命中</th></tr>{tsum}</table>
<p class=note>基准（全库每10日抽样）：行情起点 {B['p_行情起点']*100:.1f}%、几日游 {B['p_几日游']*100:.1f}%。</p></section>
<section class=card><h2>前50 名单</h2><table><tr><th>#</th><th>代码</th><th>名称</th><th>层级</th><th>综合分</th><th>来源模板</th><th>资金分</th><th>主力10日(亿)</th><th>机构龙虎榜60日(亿)</th><th>营收/净利同比</th><th>风格</th><th>风险</th></tr>{rows}</table></section>
{viewer_html('前50 K 线与四要素（点选切换；来源模板可跳转）')}
<section class=card><h2>局限</h2><ul class=note><li>形态规则是机械代理，标定日为推断；回测表明多数形态单独没有显著超额，排序主要靠资金面与业绩。</li><li>资金口径为公开数据近似（新浪“主力”=超大单+大单，≠真实机构；龙虎榜只覆盖上榜日；融资/股东户数/机构持股为旧快照）。</li><li>仅沪深，不含北交所；前复权；库内无已退市股票（回测有幸存者偏差）。</li></ul></section>
{DISC}""" + tail_js('../', dict(entries=ents))
os.makedirs(ROOT + 'top50', exist_ok=True); open(ROOT + 'top50/report.html', 'w').write(body)
top_out = [dict(rank=i, code=c, name=r['name'], tier=r.ctier, score=round(r.score, 1), templates=[f'T{k:02d}' for k in sorted(r.cur)], cap=r.cap, mf10=r.mf10, org_net60=r.org_net60, rev_yoy=r.rev_yoy, np_yoy=r.np_yoy, style=r['style'], risk=list(r.risk),
                main=TN[sorted(r.cur, key=lambda k: ({'更贴': 0, '次贴': 1, '观察': 2}[r.ttiers[k]], -r.cur[k]['level'], k))[0]]) for i, (c, r) in enumerate(top.iterrows(), 1)]
json.dump(top_out, open(OUT + 'top50.json', 'w'), ensure_ascii=False, indent=1, default=float)
pd.DataFrame(top_out).to_csv(ROOT + 'top50/top50.csv', index=False, encoding='utf-8-sig')
# index
li = ''.join(f"<tr><td>T{int(k):02d}</td><td><a href='{v['slug']}/report.html'>{esc(v['name'])}</a></td><td>{v['tiers'].get('更贴',0)}/{v['tiers'].get('次贴',0)}/{v['tiers'].get('观察',0)}</td><td>{(v['p_start'] or 0)*100:.1f}% ({N(v['lift'])}×)</td><td>{'；'.join(f'{a}' + ('✅' if c else '❌') for a, b, c in v['calib'])}</td></tr>" for k, v in sorted(SUMMARY.items(), key=lambda z: int(z[0])))
idx = HEAD(f'全形态报告目录 · {ASOF}', '') + f"""<h1>全形态逐一回测 · 报告目录</h1><div class=meta>数据截至 <b>{ASOF} 收盘</b>（UTC+8）</div>
<section class=card><h2><a href="top50/report.html">→ 综合推荐前50</a></h2><p class=note>每只票都链接回它命中的模板报告。</p></section>
<section class=card><h2>24 套模板报告</h2><table><tr><th>#</th><th>模板报告</th><th>当前 更贴/次贴/观察</th><th>历史40日行情起点(相对基准)</th><th>样例校准</th></tr>{li}</table></section>
{DISC}</body></html>"""
open(ROOT + 'index.html', 'w').write(idx)
print('top50', dict(tc), 'styles', dict(style_c))
