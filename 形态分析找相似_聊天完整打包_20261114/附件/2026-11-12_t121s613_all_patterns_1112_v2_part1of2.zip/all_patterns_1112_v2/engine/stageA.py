# universe + current features + phase gate
import pickle, json, pandas as pd, numpy as np, sys
from multiprocessing import Pool
import features, tpl
OUT = '/workspace/fuyao/all_patterns_1112_v2/engine/out'
ASOF = sys.argv[1] if len(sys.argv) > 1 else '2026-11-12'
R = pickle.load(open(f'{OUT}/scan_raw.pkl', 'rb'))
QT = json.load(open('/workspace/fuyao/summary_1104/qt_all.json'))
t17 = json.load(open('/workspace/fuyao/all_patterns_1112_v2/t17/scan_results.json'))
cur = {}; near = {}
for r in R:
    if 'err' in r or r['last'] != ASOF: continue
    for k, v in r['cur'].items(): cur.setdefault(r['code'], {})[k] = v
    for k, v in r['near'].items(): near.setdefault(r['code'], {})[k] = v
for x in t17['current']:
    lvl = {'更贴': 3, '次贴': 2, '观察': 1}[x['tier']]
    cur.setdefault(x['code'], {})[17] = dict(level=lvl, phase=f"粘合后阴跌洗盘末·{x['tier']}(T17原引擎)", seg=[x['wash_start'], ASOF], note=f"破位{x['wash_start']}→低点{x['wash_low_date']}，深{x['depth']*100:.1f}%，较低点抬升{x['lift']*100:.1f}%，粘合中位{x.get('med120',0)*100:.1f}%", t17score=x.get('score'))
codes = sorted(set(cur) | set(near))
def st(c):
    q = QT.get(c); return (not q) or ('ST' in q[1]) or ('退' in q[1])
codes = [c for c in codes if not st(c)]
def ff(c):
    try: return features.feats(c)
    except Exception as e: return dict(code=c, err=repr(e))
with Pool(8) as P: F = P.map(ff, codes, chunksize=4)
F = pd.DataFrame([f for f in F if 'err' not in f]).set_index('code')
F['gate'] = ''
F.loc[F.ret20 > .30, 'gate'] += '20日涨>30%;'; F.loc[F.ext > .15, 'gate'] += '距均线簇上沿>15%;'; F.loc[F.ret5 > .20, 'gate'] += '5日涨>20%;'
F.loc[F.lu20 >= 3, 'gate'] += '20日≥3板;'; F.loc[F.close < 2, 'gate'] += '股价<2;'; F.loc[~(F.fcap >= 15), 'gate'] += '流通值<15亿;'
F['cur'] = [cur.get(c, {}) for c in F.index]; F['near'] = [near.get(c, {}) for c in F.index]
F.to_pickle(f'{OUT}/stageA.pkl')
g = F[F.gate == '']
print('universe', len(F), 'pass gate', len(g), 'cur-hit pass', int((g.cur.map(len) > 0).sum()))
import collections
print('per tpl cur (pass gate):', sorted(collections.Counter(k for h in g.cur for k in h).items()))
print('per tpl cur (all):', sorted(collections.Counter(k for h in F.cur for k in h).items()))
