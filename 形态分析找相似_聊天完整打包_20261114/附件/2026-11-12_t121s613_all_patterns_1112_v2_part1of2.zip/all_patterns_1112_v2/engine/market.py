import pandas as pd, numpy as np, os, json, sys
from multiprocessing import Pool
D='/workspace/fuyao/market_daily/'; ASOF=sys.argv[1] if len(sys.argv)>1 else '2026-11-12'
QT=json.load(open('/workspace/fuyao/summary_1104/qt_all.json'))
def w(f):
    c=f[:-4]; q=QT.get(c)
    if not q or 'ST' in q[1] or '退' in q[1]: return None
    d=pd.read_csv(D+f)
    if len(d)<220 or d.date.iloc[-1]!=ASOF: return None
    d=d.tail(260).reset_index(drop=True); L=19.5 if c[2:5] in ('300','301','688','689') else 9.7
    p=d.close.pct_change()*100; m200=d.close.rolling(200).mean()
    out={}
    for i in range(len(d)-6,len(d)):
        out[d.date[i]]=dict(up=int(p[i]>0),dn=int(p[i]<0),lu=int(p[i]>=L),ld=int(p[i]<=-L),gap=int(d.low[i]>d.high[i-1]))
    return dict(a200=bool(d.close.iloc[-1]>m200.iloc[-1]),ret5=float(d.close.iloc[-1]/d.close.iloc[-6]-1),days=out)
fs=[x for x in os.listdir(D) if x[:2] in('sh','sz')]
with Pool(8) as P: R=[r for r in P.map(w,fs,chunksize=32) if r]
per={}
for r in R:
    for d,v in r['days'].items():
        s=per.setdefault(d,dict(up=0,dn=0,lu=0,ld=0,gap=0))
        for k in s: s[k]+=v[k]
per={k:v for k,v in per.items() if v['up']+v['dn']>len(R)*0.5}
M=dict(n=len(R),pct_above_ma200=float(np.mean([r['a200'] for r in R])),median_ret5=float(np.median([r['ret5'] for r in R])),per_day=dict(sorted(per.items())))
json.dump(M,open('/workspace/fuyao/all_patterns_1112_v2/engine/out/market.json','w'),ensure_ascii=False,indent=1);print(M)
