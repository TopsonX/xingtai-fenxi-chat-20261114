# main-force flow from Sina (r0=超大单, r1=大单; 主力=r0_net+r1_net) written in EM-like layout:
# kline = date, main_net, small_net(r3), mid_net(r2), big_net(r1), xl_net(r0), main_ratio%
import requests, json, os, sys, time, random, collections, concurrent.futures as cf
OUT = '/workspace/fuyao/all_patterns_1112_v2/engine/out'; FD = '/workspace/fuyao/all_patterns_1112_v2/flows/'
ASOF = sys.argv[1] if len(sys.argv) > 1 else '2026-11-12'
codes = json.load(open(f'{OUT}/need_codes.json'))
U = 'https://vip.stock.finance.sina.com.cn/quotes_service/api/json_v2.php/MoneyFlow.ssl_qsfx_lscjfb'
def f(code):
    p = FD + code + '.json'
    if os.path.exists(p):
        try:
            j = json.load(open(p))
            if j.get('src') == 'sina' and j['data']['klines'][-1][:10] >= ASOF: return code, 'cached'
        except Exception: pass
    for k in range(6):
        try:
            r = requests.get(U, params={'page': 1, 'num': 60, 'sort': 'opendate', 'asc': 0, 'daima': code}, headers={'User-Agent': 'Mozilla/5.0'}, timeout=15)
            a = r.json()
            if not a: return code, 'empty'
            kl = []
            for x in sorted(a, key=lambda z: z['opendate']):
                r0n, r1n, r2n, r3n = (float(x[f'r{i}_net']) for i in range(4))
                tot = sum(float(x[f'r{i}']) for i in range(4))
                m = r0n + r1n
                kl.append(f"{x['opendate']},{m:.2f},{r3n:.2f},{r2n:.2f},{r1n:.2f},{r0n:.2f},{(m / tot * 100 if tot else 0):.2f}")
            json.dump({'src': 'sina', 'url': r.url, 'fetched_at': time.strftime('%Y-%m-%d %H:%M') + ' UTC+8', 'data': {'klines': kl}}, open(p, 'w'))
            return code, 'ok' if kl[-1][:10] >= ASOF else 'ok_stale'
        except Exception:
            time.sleep(1 + k + random.random())
    return code, 'fail'
t0 = time.time()
with cf.ThreadPoolExecutor(4) as ex: res = list(ex.map(f, codes))
c = collections.Counter(s for _, s in res); print('sina flows', len(codes), c, round(time.time() - t0), 's')
last = collections.Counter()
for code, s in res:
    try: last[json.load(open(FD + code + '.json'))['data']['klines'][-1][:10]] += 1
    except Exception: pass
print('last dates', last.most_common(4))
json.dump({'res': res, 'last': last.most_common(6)}, open(f'{OUT}/flows_manifest.json', 'w'))
