"""Append the 2026-11-12 bar from Tencent realtime quotes (final after close) where kline APIs lag."""
import json, os, time, requests, tempfile, collections
from pathlib import Path
D = Path('/workspace/fuyao/market_daily'); T = '2026-11-12'
files = sorted(p.stem for p in D.glob('*.csv'))
def lastline(p):
    with open(p, 'rb') as f:
        f.seek(0, 2); n = f.tell(); f.seek(max(0, n - 300)); return f.read().decode().strip().split('\n')[-1]
need = [c for c in files if not lastline(D / f'{c}.csv').startswith(T)]
print('files', len(files), 'need', len(need))
st = collections.Counter(); resc = []; qts = {}
for i in range(0, len(need), 60):
    b = need[i:i + 60]
    for t in range(4):
        try:
            r = requests.get('https://qt.gtimg.cn/q=' + ','.join(b), timeout=15); r.encoding = 'gbk'; break
        except Exception as e:
            time.sleep(1 + t)
    else:
        st['batch_fail'] += 1; continue
    for line in r.text.split(';'):
        if '="' not in line: continue
        k, v = line.strip().split('="', 1); code = k.replace('v_', ''); f = v.rstrip('"').split('~')
        if len(f) < 40: continue
        qts[code] = f
time.sleep(0.1)
for c in need:
    f = qts.get(c)
    if not f: st['noquote'] += 1; continue
    ts = f[30][:8]
    if ts != T.replace('-', ''): st['not_today'] += 1; continue
    try:
        close, pre, op, vol, hi, lo = float(f[3]), float(f[4]), float(f[5]), float(f[6]), float(f[33]), float(f[34])
    except Exception:
        st['parse'] += 1; continue
    if vol <= 0 or op <= 0: st['suspended'] += 1; continue
    p = D / f'{c}.csv'
    lines = open(p).read().strip().split('\n')
    hdr, rows = lines[0], lines[1:]
    lc = float(rows[-1].split(',')[2]); ld = rows[-1].split(',')[0]
    if ld != '2026-11-11': st['gap_' + ld[:7]] += 1
    r = pre / lc if lc > 0 else 1
    if abs(r - 1) > 0.003 and ld == '2026-11-11':
        new = []
        for x in rows:
            a = x.split(','); 
            for j in (1, 2, 3, 4): a[j] = str(round(float(a[j]) * r, 3))
            new.append(','.join(a))
        rows = new; resc.append((c, round(r, 4)))
    rows.append(f'{T},{op},{close},{hi},{lo},{vol}')
    fd, tmp = tempfile.mkstemp(dir=str(D)); os.close(fd)
    open(tmp, 'w').write(hdr + '\n' + '\n'.join(rows) + '\n'); os.replace(tmp, p)
    st['appended'] += 1
after = collections.Counter(lastline(D / f'{c}.csv')[:10] for c in files)
out = {'stats': dict(st), 'rescaled': resc, 'after_top': after.most_common(5), 'n_files': len(files)}
json.dump(out, open('qt_append_log.json', 'w'), ensure_ascii=False, indent=1)
print(json.dumps(out, ensure_ascii=False)[:1500])
