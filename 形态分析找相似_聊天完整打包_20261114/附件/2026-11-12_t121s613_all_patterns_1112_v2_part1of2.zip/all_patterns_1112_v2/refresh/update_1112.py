#!/usr/bin/env python3
"""Refresh market_daily CSVs to latest official close (qfq) via Eastmoney, Tencent fallback."""
from __future__ import annotations

import collections
import concurrent.futures as cf
import json
import os
import random
import tempfile
import threading
import time
from pathlib import Path

import pandas as pd
import requests

D = Path("/workspace/fuyao/market_daily")
OUT = Path("/workspace/fuyao/all_patterns_1112_v2/refresh")
OUT.mkdir(parents=True, exist_ok=True)
TARGET = "2026-11-12"
CUTOFF = "2026-11-13"  # exclude partial intraday bar
THREADS = 12
RETRIES = 4
LMT = 30

UA = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Referer": "https://quote.eastmoney.com/",
}

thread_local = threading.local()
lock = threading.Lock()
stats = collections.Counter()
fail_list: list[dict] = []
last_dates = collections.Counter()


def session() -> requests.Session:
    s = getattr(thread_local, "s", None)
    if s is None:
        s = requests.Session()
        s.headers.update(UA)
        thread_local.s = s
    return s


def secid(code: str) -> str:
    return ("1." if code.startswith("sh") else "0.") + code[2:]


def fetch_em(code: str) -> list[list[str]] | None:
    url = (
        "https://push2his.eastmoney.com/api/qt/stock/kline/get"
        f"?secid={secid(code)}&fields1=f1,f2,f3,f4"
        f"&fields2=f51,f52,f53,f54,f55,f56&klt=101&fqt=1&end=20500101&lmt={LMT}"
    )
    last_err = None
    for t in range(RETRIES):
        try:
            r = session().get(url, timeout=20)
            if r.status_code in (429, 503, 502, 500):
                time.sleep(0.8 + 0.7 * t + random.random() * 0.4)
                last_err = f"http_{r.status_code}"
                continue
            r.raise_for_status()
            j = r.json()
            data = j.get("data")
            if not data:
                # empty / no data for this security
                return []
            klines = data.get("klines") or []
            rows = []
            for line in klines:
                parts = line.split(",")
                if len(parts) < 6:
                    continue
                rows.append(parts[:6])
            return rows
        except Exception as e:
            last_err = f"{type(e).__name__}:{e}"
            time.sleep(0.5 + 0.6 * t + random.random() * 0.3)
    raise RuntimeError(f"em_fail:{last_err}")


def fetch_tx(code: str) -> list[list[str]] | None:
    url = (
        "https://web.ifzq.gtimg.cn/appstock/app/fqkline/get"
        f"?param={code},day,2026-09-01,2026-12-31,120,qfq"
    )
    last_err = None
    for t in range(RETRIES):
        try:
            r = session().get(url, timeout=18)
            if r.status_code == 501 or r.status_code >= 500:
                last_err = f"http_{r.status_code}"
                time.sleep(0.4 + 0.5 * t)
                continue
            r.raise_for_status()
            j = r.json()
            dd = (j.get("data") or {}).get(code) or {}
            k = dd.get("qfqday") or dd.get("day") or []
            return [x[:6] for x in k]
        except Exception as e:
            last_err = f"{type(e).__name__}:{e}"
            time.sleep(0.4 + 0.5 * t)
    raise RuntimeError(f"tx_fail:{last_err}")


def atomic_write_csv(df: pd.DataFrame, path: Path) -> None:
    fd, tmp = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=str(path.parent))
    os.close(fd)
    tmp_path = Path(tmp)
    try:
        df.to_csv(tmp_path, index=False)
        os.replace(tmp_path, path)
    finally:
        if tmp_path.exists():
            try:
                tmp_path.unlink()
            except OSError:
                pass


def merge_and_write(path: Path, new_rows: list[list[str]]) -> str:
    new = pd.DataFrame(new_rows, columns=["date", "open", "close", "high", "low", "vol"])
    for col in ["open", "close", "high", "low", "vol"]:
        new[col] = pd.to_numeric(new[col], errors="coerce")
    new = new.dropna(subset=["date", "close"]).drop_duplicates("date", keep="last")
    new = new[new.date < CUTOFF]
    if new.empty:
        # keep existing; report its last date
        if path.exists() and path.stat().st_size > 0:
            old = pd.read_csv(path)
            if len(old):
                return str(old.date.iloc[-1])
        return "empty"

    if path.exists() and path.stat().st_size > 0:
        try:
            old = pd.read_csv(path)
        except Exception:
            old = pd.DataFrame(columns=["date", "open", "close", "high", "low", "vol"])
        if len(old):
            # keep older history, replace overlapping dates with newly fetched bars
            ov = old.merge(new, on="date", suffixes=("_o", "_n"))
            if len(ov):
                r = (ov.close_n / ov.close_o).median()
                if abs(r - 1) > 0.003:
                    with lock:
                        stats["qfq_rescaled"] += 1
                    for c in ["open", "close", "high", "low"]:
                        old[c] = (old[c] * r).round(3)
            old = old[~old.date.isin(set(new.date))]
            df = (
                pd.concat([old, new], ignore_index=True)
                .sort_values("date")
                .drop_duplicates("date", keep="last")
            )
        else:
            df = new.sort_values("date")
    else:
        df = new.sort_values("date")

    atomic_write_csv(df, path)
    return str(df.date.iloc[-1])


def process(code: str, retry_pass: bool = False) -> tuple[str, str, str | None]:
    """Return (status, last_date_or_tag, error_or_None)."""
    path = D / f"{code}.csv"
    src = "em"
    try:
        try:
            rows = fetch_em(code)
        except Exception as e_em:
            src = "tx"
            try:
                rows = fetch_tx(code)
            except Exception as e_tx:
                return ("fail", "fail", f"em={e_em}; tx={e_tx}")

        if rows is None:
            return ("fail", "fail", f"{src}:None")

        last = merge_and_write(path, rows)
        if last == "empty":
            return ("empty", "empty", None)
        if last < TARGET:
            return ("ok_stale", last, None)  # halted/delisted or no trade today
        return ("ok", last, None)
    except Exception as e:
        return ("fail", "fail", f"{type(e).__name__}:{e}")


def run_batch(codes: list[str], label: str) -> list[str]:
    fails: list[str] = []
    with cf.ThreadPoolExecutor(THREADS) as ex:
        futs = {ex.submit(process, c): c for c in codes}
        done = 0
        for fut in cf.as_completed(futs):
            code = futs[fut]
            status, last, err = fut.result()
            with lock:
                stats[status] += 1
                stats[f"src_pass_{label}"] += 1
                if status == "fail":
                    fails.append(code)
                    fail_list.append({"code": code, "pass": label, "reason": err})
                else:
                    last_dates[last] += 1
                done += 1
                if done % 400 == 0 or done == len(codes):
                    print(
                        f"[{label}] {done}/{len(codes)} {dict(stats)} "
                        f"top_dates={last_dates.most_common(5)}",
                        flush=True,
                    )
    return fails


def last_bar_histogram() -> dict:
    hist = collections.Counter()
    for p in D.glob("*.csv"):
        last = None
        with p.open() as f:
            next(f, None)
            for line in f:
                if line.strip():
                    last = line.split(",", 1)[0]
        hist[last or "EMPTY"] += 1
    return dict(hist)


def main() -> None:
    codes = sorted(p.stem for p in D.glob("*.csv"))
    print(f"BEFORE files={len(codes)}", flush=True)
    before = last_bar_histogram()
    print(
        "BEFORE hist:",
        {
            "2026-11-06": before.get("2026-11-06", 0),
            "2026-11-05": before.get("2026-11-05", 0),
            "2026-11-04": before.get("2026-11-04", 0),
            "older": sum(v for k, v in before.items() if k not in ("2026-11-06", "2026-11-05", "2026-11-04")),
        },
        flush=True,
    )
    (OUT / "before_hist.json").write_text(json.dumps(before, ensure_ascii=False, indent=2))

    t0 = time.time()
    fails = run_batch(codes, "pass1")
    print(f"pass1 fails={len(fails)} elapsed={time.time()-t0:.1f}s", flush=True)

    if fails:
        # reset per-code counters for pass2 reporting but keep fail_list
        print(f"retrying {len(fails)} failures", flush=True)
        time.sleep(2)
        # remove pass1 fail tallies for codes we will retry: just re-run and overwrite files
        # Adjust stats: subtract pass1 fail count for these, then add pass2 results
        with lock:
            stats["fail"] -= len(fails)
        fails2 = run_batch(fails, "pass2")
        print(f"pass2 fails={len(fails2)}", flush=True)
    else:
        fails2 = []

    after = last_bar_histogram()
    summary = {
        "files": len(codes),
        "stats": dict(stats),
        "fail_final": fails2,
        "fail_list": fail_list,
        "last_dates_during_run": dict(last_dates),
        "before": {
            "2026-11-06": before.get("2026-11-06", 0),
            "2026-11-05": before.get("2026-11-05", 0),
            "2026-11-04": before.get("2026-11-04", 0),
            "older": sum(v for k, v in before.items() if k not in ("2026-11-06", "2026-11-05", "2026-11-04")),
        },
        "after": {
            "2026-11-06": after.get("2026-11-06", 0),
            "2026-11-05": after.get("2026-11-05", 0),
            "2026-11-04": after.get("2026-11-04", 0),
            "older": sum(v for k, v in after.items() if k not in ("2026-11-06", "2026-11-05", "2026-11-04")),
        },
        "after_full": after,
        "elapsed_sec": round(time.time() - t0, 1),
    }
    (OUT / "update_log.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2))
    print("DONE", json.dumps({k: summary[k] for k in ("files", "stats", "before", "after", "elapsed_sec", "fail_final")}, ensure_ascii=False), flush=True)


if __name__ == "__main__":
    main()
