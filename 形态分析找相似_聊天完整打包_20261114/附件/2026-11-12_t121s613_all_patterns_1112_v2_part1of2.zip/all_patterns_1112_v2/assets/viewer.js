(function(){
const {createApp,ref,reactive,computed,watch,onMounted,nextTick,markRaw}=Vue;
const DATA=JSON.parse(document.getElementById('data').textContent);
function unpack(s){if(!s||s._ready)return;s.kline=s.kline.map(r=>({date:r[0],o:r[1],h:r[2],l:r[3],c:r[4],v:r[5],ma7:r[6],ma45:r[7],ma120:r[8],ma200:r[9],ma180:r[10],vma20:r[11]}));s.gaps=s.gaps||[];s._ready=true}
createApp({setup(){
const entries=markRaw(DATA.entries);entries.forEach(unpack);
const tiers=['全部',...Array.from(new Set(entries.map(e=>e.tier)))];
const tier=ref('全部'),q=ref('');
const h0=decodeURIComponent((location.hash||'').slice(1));
const first=entries.find(e=>h0&&(e.code===h0||e.id===h0))||entries[0];
const sel=ref(first?first.id:null),cv=ref(null),hover=ref(-1),my=ref(-1),view=reactive({start:0,count:200});let drag=null;
const filtered=computed(()=>entries.filter(e=>(tier.value==='全部'||e.tier===tier.value)&&(!q.value||e.name.includes(q.value)||e.code.includes(q.value))));
const stock=computed(()=>entries.find(e=>e.id===sel.value));
const status=computed(()=>{const s=stock.value;if(!s)return '';const sl=s.kline.slice(view.start,view.start+view.count);if(!sl.length)return '';const i=Math.min(sl.length-1,hover.value>=0?hover.value:sl.length-1);return hoverText({kline:sl},i)});
function clamp(s,c){const n=stock.value.kline.length;view.count=Math.max(Math.min(40,n),Math.min(n,Math.round(c)));view.start=Math.max(0,Math.min(n-view.count,Math.round(s)))}
function draw(){if(stock.value&&cv.value)drawKline(cv.value,stock.value,hover.value,view,my.value)}
function reset(){clamp(stock.value.defaultStart,stock.value.defaultCount);hover.value=-1;nextTick(draw)}
function select(id){sel.value=id;nextTick(reset)}
function pos(e){const r=cv.value.getBoundingClientRect();return {x:e.clientX-r.left,y:e.clientY-r.top,w:r.width}}
function down(e){const p=pos(e);drag={x:p.x,start:view.start};try{cv.value.setPointerCapture(e.pointerId)}catch(_){}}
function move(e){const p=pos(e);my.value=p.y;if(drag){clamp(drag.start-(p.x-drag.x)/(p.w-72)*view.count,view.count);hover.value=-1}else hover.value=Math.max(0,Math.min(view.count-1,Math.floor((p.x-56)/(p.w-72)*view.count)))}
function up(){drag=null} function leave(){if(!drag){hover.value=-1;my.value=-1}}
function zoom(f,a=.5){const an=view.start+a*view.count;const n=Math.max(40,Math.min(stock.value.kline.length,Math.round(view.count*f)));clamp(an-a*n,n);hover.value=-1}
function wheel(e){const p=pos(e);zoom(e.deltaY>0?1.15:1/1.15,Math.max(0,Math.min(1,(p.x-56)/(p.w-72))))}
function pan(n){clamp(view.start+n,view.count)}
function keys(e){if(['INPUT','SELECT'].includes(e.target.tagName)||!['ArrowDown','ArrowUp'].includes(e.key))return;e.preventDefault();const a=filtered.value,i=a.findIndex(s=>s.id===sel.value),j=Math.max(0,Math.min(a.length-1,i+(e.key==='ArrowDown'?1:-1)));if(a[j])select(a[j].id)}
watch([()=>view.start,()=>view.count,hover,my],()=>nextTick(draw));
watch(filtered,v=>{if(v.length&&!v.some(s=>s.id===sel.value))select(v[0].id)});
onMounted(()=>{window.addEventListener('keydown',keys);if(stock.value){reset();new ResizeObserver(draw).observe(cv.value)}
 window.addEventListener('hashchange',()=>{const h=decodeURIComponent(location.hash.slice(1));const e=entries.find(x=>x.code===h||x.id===h);if(e){tier.value='全部';select(e.id);cv.value.scrollIntoView({block:'center'})}});
 window.__qa={entries,select,view,stock:()=>stock.value,pan,zoom}});
return {entries,tiers,tier,q,sel,cv,view,filtered,stock,status,select,reset,down,move,up,leave,wheel,zoom,pan}}}).mount('#app');
})();
