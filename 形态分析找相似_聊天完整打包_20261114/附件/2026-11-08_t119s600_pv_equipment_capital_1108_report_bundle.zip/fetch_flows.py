import pathlib,pandas as pd,requests,json,concurrent.futures
O=pathlib.Path(__file__).parent;(O/'flows').mkdir(exist_ok=True);u=pd.read_csv(O/'universe.csv',dtype={'code':str});m=[]
def f(row):
 c=row['code'];p=O/'flows'/(c+'.json')
 try:
  if p.exists():return {'code':c,'status':'cached'}
  u='https://push2.eastmoney.com/api/qt/stock/fflow/daykline/get';params={'lmt':20,'klt':101,'secid':('1.'if c[0]=='6'else'0.')+c,'fields1':'f1,f2,f3,f7','fields2':'f51,f52,f53,f54,f55,f56,f57,f58,f59,f60,f61,f62,f63','ut':'b2884a393a59ad64002292a3e90d46a5'}
  r=requests.get(u,params=params,timeout=18);j=r.json()
  if (j.get('data')or{}).get('klines'):p.write_text(json.dumps(j,ensure_ascii=False));return {'code':c,'status':'ok','days':len(j['data']['klines'])}
  return {'code':c,'status':'empty'}
 except Exception as e:return {'code':c,'status':type(e).__name__}
with concurrent.futures.ThreadPoolExecutor(max_workers=5)as e:
 for i,x in enumerate(e.map(f,u.sort_values('equipment',ascending=False).to_dict('records'))):
  m.append(x)
  if i%25==0:print(i+1,x,flush=True);json.dump(m,open(O/'flow_fetch_manifest.json','w'),indent=2)
json.dump(m,open(O/'flow_fetch_manifest.json','w'),indent=2);print('DONE',pd.DataFrame(m).groupby('status').size().to_dict(),flush=True)
