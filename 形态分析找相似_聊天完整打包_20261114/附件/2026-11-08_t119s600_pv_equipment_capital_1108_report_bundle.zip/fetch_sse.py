# Public fallback documented in AkShare's stock_intraday_em implementation.
import pathlib,json,pandas as pd,requests,concurrent.futures
O=pathlib.Path(__file__).parent;u=pd.read_csv(O/'universe.csv',dtype={'code':str});u=u[~u.code.map(lambda c:(O/'ticks'/f'{c}_20261106.json').exists())];m=[]
def f(row):
 c=row['code'];q={'fields1':'f1,f2,f3,f4','fields2':'f51,f52,f53,f54,f55','mpi':'2000','ut':'bd1d9ddb04089700cf9c27f6f7426281','fltt':'2','pos':'-0','secid':('1.'if c[0]=='6'else'0.')+c}
 try:
  with requests.get('https://push2.eastmoney.com/api/qt/stock/details/sse',params=q,stream=True,timeout=(8,15))as r:
   if r.status_code!=200:return {'code':c,'http':r.status_code,'status':'http error'}
   for i,line in enumerate(r.iter_lines()):
    if line.startswith(b'data:'):
     j=json.loads(line[5:]);d=j.get('data')or{};details=d.get('details')or[]
     if details:
      (O/'ticks'/f'{c}_20261106.json').write_text(json.dumps(j,ensure_ascii=False));return {'code':c,'status':'ok','n':len(details)}
     return {'code':c,'status':'empty'}
    if i>8:break
  return {'code':c,'status':'empty stream'}
 except Exception as e:return {'code':c,'status':type(e).__name__}
with concurrent.futures.ThreadPoolExecutor(max_workers=5)as e:
 for i,z in enumerate(e.map(f,u.to_dict('records'))):
  m.append(z)
  if i%10==0:print(i,len(u),z,flush=True);json.dump(m,open(O/'sse_manifest.json','w'),indent=2)
json.dump(m,open(O/'sse_manifest.json','w'),indent=2);print('DONE',pd.DataFrame(m).groupby('status').size().to_dict(),flush=True)
