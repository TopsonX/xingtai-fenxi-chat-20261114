import pathlib,pandas as pd
O=pathlib.Path(__file__).parent;u=pd.read_csv(O/'universe.csv',dtype={'code':str});f=pd.read_parquet('/workspace/fuyao/summary_1104/cpd.parquet');f=f[(f.NOTICE_DATE.str[:10]<='2026-11-06')&f.SECURITY_CODE.isin(u.code)].sort_values(['REPORTDATE','NOTICE_DATE']).groupby('SECURITY_CODE').tail(1);f.to_csv(O/'finance_background.csv',index=False)
