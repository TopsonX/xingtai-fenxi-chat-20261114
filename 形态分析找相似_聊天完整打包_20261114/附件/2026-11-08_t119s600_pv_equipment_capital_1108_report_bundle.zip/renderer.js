function drawPV(ctx,W,H,rows,start,count,hover=-1){
 const up='#ef5d65',dn='#27c194',bg='#0b1424',mut='#8fa4be';ctx.clearRect(0,0,W,H);ctx.fillStyle=bg;ctx.fillRect(0,0,W,H);
 const L=64,R=20,T=37,B=28,P=H*.72,V=H*.2,g=rows.slice(start,start+count);if(!g.length)return;
 const vals=g.flatMap(r=>[r[3],r[4],...r.slice(6).filter(v=>v!==null&&v>0)]),lo=Math.min(...vals),hi=Math.max(...vals),pad=Math.max((hi-lo)*.06,.01),mn=lo-pad,mx=hi+pad;
 const x=i=>L+(i+.5)*(W-L-R)/g.length,y=v=>T+(mx-v)/(mx-mn)*(P-T),cw=Math.max(1,(W-L-R)/g.length*.63),vm=Math.max(...g.map(r=>r[5]),1);
 ctx.font='11px "Noto Sans CJK SC", sans-serif' ;ctx.lineWidth=.5;ctx.textAlign='right';for(let i=0;i<=5;i++){let v=mn+(mx-mn)*i/5,yy=y(v);ctx.strokeStyle='#233247';ctx.beginPath();ctx.moveTo(L,yy);ctx.lineTo(W-R,yy);ctx.stroke();ctx.fillStyle=mut;ctx.fillText(v.toFixed(2),L-7,yy+4)}
 g.forEach((r,i)=>{let col=r[2]>=r[1]?up:dn;ctx.fillStyle=col;ctx.strokeStyle=col;ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(x(i),y(r[3]));ctx.lineTo(x(i),y(r[4]));ctx.stroke();ctx.fillRect(x(i)-cw/2,Math.min(y(r[1]),y(r[2])),cw,Math.max(1,Math.abs(y(r[1])-y(r[2]))));ctx.globalAlpha=.65;ctx.fillRect(x(i)-cw/2,H-B-r[5]/vm*V,cw,r[5]/vm*V);ctx.globalAlpha=1;});
 const colors=['#e5e9f1','#5ba9ff','#c29aff','#f3d45a','#f29b4b'];for(let n=6;n<=10;n++){ctx.beginPath();ctx.lineWidth=n===9?1.6:1.15;ctx.strokeStyle=colors[n-6];let on=false;g.forEach((r,i)=>{if(r[n]===null||r[n]<=0){on=false;return}if(!on)ctx.moveTo(x(i),y(r[n]));else ctx.lineTo(x(i),y(r[n]));on=true});ctx.stroke();}
 ctx.textAlign='left';for(let i=0;i<6;i++){let j=Math.floor(i*(g.length-1)/5);ctx.fillStyle=mut;ctx.fillText(g[j][0],Math.min(W-83,Math.max(L,x(j)-28)),H-7)}
 const labels=['MA7','MA45','MA120','MA180','MA200'];labels.forEach((s,i)=>{ctx.fillStyle=colors[i];ctx.fillText(s,L+i*74,18)});
 if(hover>=start&&hover<start+g.length){let i=hover-start,r=g[i];ctx.strokeStyle='#e5e9f1';ctx.setLineDash([3,3]);ctx.beginPath();ctx.moveTo(x(i),T);ctx.lineTo(x(i),H-B);ctx.stroke();ctx.setLineDash([]);ctx.fillStyle='#e5e9f1';ctx.fillText(`${r[0]} 开${r[1]} 高${r[3]} 低${r[4]} 收${r[2]} 量${Math.round(r[5])}手`,L,32)}
}
