import pathlib,json,pandas as pd,zipfile,re,hashlib
O=pathlib.Path(__file__).parent;u=pd.read_csv(O/'universe.csv',dtype={'code':str});t=pd.read_csv(O/'tick_summary.csv',dtype={'code':str});miss=u[~u.code.isin(t.code)].copy();miss['gap']='最新快照未取得/日期无法验证（不是净流量为零）';miss.to_csv(O/'tick_failures.csv',index=False)
hand=(O/'handoff.md').read_text();extra='\n缺失行业快照7只：TCL中环、亚玛顿（两者日线也停更）、迈为股份、帝科股份、首航新能、弘元绿能、国晟科技。全池缺失41只详见tick_failures.csv。\n验证30项均通过；全部291只×3跨度独立Canvas渲染873次无异常，未运行浏览器端到端交互。validation.json与validation_notes.md已附。\n'
if '缺失行业快照7只'not in hand:hand+=extra
(O/'handoff.md').write_text(hand)
files=[]
for pattern in ['*.csv','*.py','*.js']:
 files+=list(O.glob(pattern))
for f in ['report.html','summary.json','counts.json','history_summary.json','tick_coverage.json','daily_audit.json','preview.png','canvas_preview.png','render_validation.json','validation.json','validation_notes.md','REPRODUCE.md','handoff.md','tick_fetch_first_attempt.json','tick_fetch_manifest.json','sse_manifest.json','flow_first_attempt.json','flow_fetch_manifest.json']:
 files.append(O/f)
files.append(O/'sources/equipment_public.csv');files=list(dict.fromkeys(p for p in files if p.exists()))
with zipfile.ZipFile(O/'report_bundle.zip','w',zipfile.ZIP_DEFLATED,compresslevel=7)as z:
 for p in files:z.write(p,str(p.relative_to(O)))
mb=(O/'report_bundle.zip').stat().st_size/1024/1024;hand=(O/'handoff.md').read_text();hand=re.sub(r'report_bundle.zip：\d+\.\d+ MiB',f'report_bundle.zip：{mb:.2f} MiB',hand);(O/'handoff.md').write_text(hand)
# Refresh handoff inside the zip without duplicate members.
with zipfile.ZipFile(O/'report_bundle.zip','w',zipfile.ZIP_DEFLATED,compresslevel=7)as z:
 for p in files:z.write(p,str(p.relative_to(O)))
man={'asof':'2026-11-06 收盘，新加坡时间 UTC+8','files':{f:{'bytes':(O/f).stat().st_size,'sha256':hashlib.sha256((O/f).read_bytes()).hexdigest()}for f in ['report.html','report_bundle.zip','summary.json','preview.png']},'validation_passed':json.load(open(O/'validation.json'))['passed'],'not_advice':'不构成投资建议'};(O/'delivery_manifest.json').write_text(json.dumps(man,ensure_ascii=False,indent=2));print(json.dumps(man,ensure_ascii=False,indent=2));print('zip members',len(files))
