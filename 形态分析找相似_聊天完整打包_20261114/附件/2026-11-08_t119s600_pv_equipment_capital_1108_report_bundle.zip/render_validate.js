const fs=require('fs'),vm=require('vm'),path=require('path');
const {createCanvas,GlobalFonts}=require('/workspace/fuyao/ma_coil_wash_600821_1108/qa_runtime/node_modules/@napi-rs/canvas');
GlobalFonts.registerFromPath('/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc','Noto Sans CJK SC');
const O=__dirname,payload=JSON.parse(fs.readFileSync(path.join(O,'chart_data.json'),'utf8'));
const context={};vm.createContext(context);vm.runInContext(fs.readFileSync(path.join(O,'renderer.js'),'utf8'),context);
let rendered=0,variants=0,errors=[];
for(const s of payload.stocks){try{const c=createCanvas(1100,520),ctx=c.getContext('2d');for(const n of [25,130,s.bars.length]){let count=Math.min(n,s.bars.length),start=Math.max(0,s.bars.length-count);context.drawPV(ctx,1100,520,s.bars,start,count,start+Math.floor(count/2));variants++;}if(s.code==='002578')fs.writeFileSync(path.join(O,'canvas_preview.png'),c.toBuffer('image/png'));rendered++;}catch(e){errors.push({code:s.code,error:String(e)})}}
const result={method:'standalone Canvas via napi; no browser or browser automation',canvas_rendered_stocks:rendered,render_variants:variants,errors,interactive_browser_e2e:'not run: browser interaction tools not available'};fs.writeFileSync(path.join(O,'render_validation.json'),JSON.stringify(result,null,2));console.log(result);
