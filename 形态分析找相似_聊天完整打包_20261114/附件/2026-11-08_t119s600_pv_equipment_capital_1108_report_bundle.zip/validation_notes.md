# 验证说明

- PASS union_unique
- PASS all_union_daily_scanned
- PASS equipment_60
- PASS all_union_interactive
- PASS stock_dates_not_future
- PASS source_daily_stable
- PASS MA7_all_recomputed
- PASS MA45_all_recomputed
- PASS MA120_all_recomputed
- PASS MA180_all_recomputed
- PASS MA200_all_recomputed
- PASS tick_names_match
- PASS tick_days_unique
- PASS partial_day_disclosed
- PASS current_tick_price_matches_daily
- PASS current_tick_volume_90_110
- PASS lhb_no_double_stock_date_range
- PASS lhb_additive_only_one_day
- PASS no_external_script
- PASS images_embedded
- PASS no_echarts
- PASS disclaimer
- PASS historical_tick_limits_visible
- PASS all_week_names_deep_notes
- PASS bundle_under_25MB
- PASS renderer.js_syntax
- PASS app.js_syntax
- PASS render_validate.js_syntax
- PASS standalone_canvas_render
- PASS all_stocks_canvas_render

仅离线数据断言、JS语法与独立Canvas渲染测试，未运行浏览器端到端交互；不宣称浏览器截图。历史服务503，缺失41只当前快照、近7日全池逐笔未完成；缺口在报告首屏及正文显著披露。
不构成投资建议
