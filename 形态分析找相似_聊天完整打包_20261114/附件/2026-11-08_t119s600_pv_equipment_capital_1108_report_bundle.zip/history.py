import pathlib,pandas as pd,numpy as np,json
O=pathlib.Path(__file__).parent;e=pd.read_csv(O/'pv_limitup_events.csv',dtype={'code':str}).fillna('');u=pd.read_csv(O/'universe.csv',dtype={'code':str});N=u.set_index('code').name.to_dict();count=json.load(open(O/'counts.json'));start=count['recent20_start'];top=[]
for c,g in e.groupby('code'):
 h=g[g.date>=start];top.append({'code':c,'name':N[c],'events2y':len(g),'events20':len(h),'events5':int((g.date>='2026-11-02').sum()),'last':g.date.max(),'recent_reason':g.sort_values('date').iloc[-1].reason,'max_lbc':pd.to_numeric(g.lbc,errors='coerce').max()})
top=pd.DataFrame(top).sort_values(['events2y','last'],ascending=False);top.to_csv(O/'limitup_rank.csv',index=False)
timeline=e.groupby('date').agg(events=('code','size'),names=('code','nunique')).reset_index();timeline.to_csv(O/'limitup_timeline.csv',index=False)
# Event close -> future close, all matched events, unfiltered by outcome; strict available horizons.
fwd=[]
for code,g in e.groupby('code'):
 p=pathlib.Path('/workspace/fuyao/market_daily')/(('sh'if code[0]=='6'else'sz')+code+'.csv');d=pd.read_csv(p);d=d[d.date<='2026-11-06'].sort_values('date').reset_index(drop=True);idx={day:i for i,day in enumerate(d.date)}
 for r in g.to_dict('records'):
  if r['date']not in idx:continue
  i=idx[r['date']];item={'code':code,'name':N[code],'date':r['date'],'category':u.set_index('code').loc[code,'category']}
  for n in [5,20]:
   if i+n<len(d):item[f'fwd{n}']=(d.close.iloc[i+n]/d.close.iloc[i]-1)*100
  fwd.append(item)
f=pd.DataFrame(fwd);f.to_csv(O/'historical_followthrough.csv',index=False)
monthly=e.assign(month=e.date.str[:7]).groupby('month').agg(events=('code','size'),names=('code','nunique')).reset_index();monthly.to_csv(O/'limitup_monthly.csv',index=False)
r={'rank':top.head(30).fillna('').to_dict('records'),'recent20':top[top.events20>0].sort_values(['events20','last'],ascending=False).fillna('').to_dict('records'),'top_days':timeline.nlargest(15,'events').to_dict('records'),'fwd':{str(n):{'n':int(f[f'fwd{n}'].notna().sum()),'median_close_pct':float(f[f'fwd{n}'].median()),'positive_rate':float((f.loc[f[f'fwd{n}'].notna(),f'fwd{n}']>0).mean()*100)}for n in [5,20]}}
json.dump(r,open(O/'history_summary.json','w'),ensure_ascii=False,indent=2);print(json.dumps(r['fwd'],ensure_ascii=False));print('top sessions',timeline.nlargest(8,'events').to_dict('records'))
