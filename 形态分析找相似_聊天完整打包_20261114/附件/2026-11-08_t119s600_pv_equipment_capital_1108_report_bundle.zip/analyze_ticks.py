import pandas as pd,numpy as np,pathlib,json,decimal
O=pathlib.Path(__file__).parent;u=pd.read_csv(O/'universe.csv',dtype={'code':str}).set_index('code');ev=pd.read_csv(O/'pv_limitup_events.csv',dtype={'code':str});res=[];clean={}
def analyze(code,day,t,source,pc=None):
 t=t.copy();t['tm']=t.d.str[-8:];t['amt']=t.p*t.v;t=t.sort_values('tm',kind='stable').reset_index(drop=True);c=t[(t.tm>='09:30:00')&(t.tm<='15:00:59')];a=t[t.tm<'09:30:00'];af=a[a.tm>='09:25:00'];fin=af.iloc[-1]if len(af)else None
 if c.empty:return
 p=pathlib.Path('/workspace/fuyao/market_daily')/(('sh'if code[0]=='6'else'sz')+code+'.csv');b=pd.read_csv(p);b=b[b.date<=day];exact=b[b.date==day]
 if exact.empty:return
 bar=exact.iloc[-1];pc=pc or float(b.close.iloc[-2]);vwap=c.amt.sum()/c.v.sum();net=lambda g:float((g.amt*g.dir.map({'U':1,'D':-1}).fillna(0)).sum()/1e8)
 aucvol=float(fin.v)if fin is not None else 0;cover=(c.v.sum()+aucvol)/(bar.vol*100)*100;rate=.2 if code.startswith(('30','68'))else .1;lim=float(decimal.Decimal(str(pc*(1+rate))).quantize(decimal.Decimal('.01'),rounding=decimal.ROUND_HALF_UP));atlim=c.p>=(lim-.005);seal=bool(abs(float(c.p.iloc[-1])-lim)<.011);touch=c[atlim].iloc[0].tm if atlim.any()else'';reopened=int(((~atlim)&atlim.cummax()).sum());change=(float(c.p.iloc[-1])/pc-1)*100;completeness='完整'if 90<=cover<=110 and c.tm.max()>='14:59:00'else'部分/需谨慎'
 n100=net(c[c.amt>=1e6]);verdict='封板接力（方向净额失真）'if seal else'主动买入'if n100>0 and change>0 else'下跌中承接/双向换手'if n100>0 else'冲高或下跌兑现'if change<0 else'上涨但大快照偏卖/分歧'
 if completeness!='完整':verdict+='·覆盖不全'
 r={'code':code,'name':u.loc[code,'name'],'date':day,'source':source,'category':u.loc[code,'category'],'equipment':int(u.loc[code,'equipment']),'records':len(t),'start':str(t.tm.min()),'end':str(t.tm.max()),'prev_raw':pc,'close_raw':float(c.p.iloc[-1]),'change_pct':change,'auction_price':float(fin.p)if fin is not None else None,'auction_gap_pct':(float(fin.p)/pc-1)*100 if fin is not None else None,'auction_shares':aucvol,'auction_amount_yi':aucvol*float(fin.p)/1e8 if fin is not None else None,'auction915':float(a.iloc[0].p)if len(a)else None,'auction920':float(a[a.tm<='09:20:00'].iloc[-1].p)if len(a[a.tm<='09:20:00'])else None,'amount_yi':c.amt.sum()/1e8,'net_yi':net(c),'net50_yi':net(c[c.amt>=5e5]),'net100_yi':n100,'open30_net_yi':net(c[c.tm<'10:00:00']),'morning_net_yi':net(c[c.tm<'11:31:00']),'afternoon_net_yi':net(c[(c.tm>='13:00:00')&(c.tm<'14:30:00')]),'tail_net_yi':net(c[c.tm>='14:30:00']),'vwap':vwap,'close_vs_vwap_pct':(float(c.p.iloc[-1])/vwap-1)*100,'coverage_pct':cover,'completeness':completeness,'sealed':seal,'first_touch':touch,'post_touch_below_snapshots':reopened,'limit_traded_amount_yi':float(c[atlim].amt.sum()/1e8),'verdict':verdict,'price_match_daily':abs(float(c.p.iloc[-1])-bar.close)<.025}
 res.append(r);clean[code+'_'+day]=c
for p in (O/'ticks').glob('*_20261106.json'):
 code=p.name[:6];
 if code not in u.index:continue
 j=json.load(open(p));data=j.get('data')or{};rows=[]
 for line in data.get('details',[]):
  z=line.split(',')
  try:rows.append({'d':'2026-11-06 '+z[0],'p':float(z[1]),'v':float(z[2])*100,'dir':{'2':'U','1':'D'}.get(z[4],'E')})
  except:pass
 if rows:
  daily=pd.read_csv('/workspace/fuyao/market_daily/'+('sh'if code[0]=='6'else'sz')+code+'.csv');day=daily.date.max();
  if day!='2026-11-06':continue
  t=pd.DataFrame(rows);t.d=day+' '+t.d.str[-8:];analyze(code,day,t,'东财details约3秒快照',float(data.get('prePrice')or 0))
j=json.load(open('/workspace/fuyao/junda_002865/ticks.json'));t=pd.DataFrame(j['ticks']);t['day']=t.d.str[:10]
for day,g in t[t.day>='2026-10-29'].groupby('day'):
 if not any(r['code']=='002865'and r['date']==day for r in res):analyze('002865',day,g,'既有东财历史导出source=em')
R=pd.DataFrame(res);R.to_csv(O/'tick_summary.csv',index=False)
F=[]
for p in (O/'flows').glob('*.json'):
 j=json.load(open(p));d=j.get('data')or{};code=p.stem
 if code not in u.index:continue
 for line in d.get('klines',[]):
  z=line.split(',')
  try:F.append({'code':code,'name':u.loc[code,'name'],'date':z[0],'main_yi':float(z[1])/1e8,'small_yi':float(z[2])/1e8,'medium_yi':float(z[3])/1e8,'big_yi':float(z[4])/1e8,'super_yi':float(z[5])/1e8,'category':u.loc[code,'category'],'equipment':int(u.loc[code,'equipment'])})
  except:pass
pd.DataFrame(F).to_csv(O/'flow_summary.csv',index=False)
json.dump({'names':R.code.nunique(),'stock_days':len(R),'equipment_names':R[R.equipment.eq(1)].code.nunique(),'records':int(R.records.sum()),'dates':R.groupby('date').size().to_dict(),'partial_days':R[R.completeness!='完整'][['code','date','coverage_pct','end']].to_dict('records'),'price_mismatch':R[~R.price_match_daily][['code','date','close_raw']].to_dict('records')},open(O/'tick_coverage.json','w'),ensure_ascii=False,indent=2)
print('ticks',R.code.nunique(),len(R),'flow',len(F));print(R[R.code.isin(['002578','603381','301697','300751','300274','300724','688516','688556','300776','603396'])][['code','name','date','change_pct','net_yi','net100_yi','coverage_pct','close_vs_vwap_pct','verdict']].round(2).to_string(index=False))
