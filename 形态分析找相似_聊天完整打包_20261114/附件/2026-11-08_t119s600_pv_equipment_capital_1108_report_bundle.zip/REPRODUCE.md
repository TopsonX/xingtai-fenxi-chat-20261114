# 复现
观察截至2026-11-06收盘，新加坡时间UTC+8；不刷新market_daily。

需要本机原始市场库、两年涨停CSV、一年龙虎榜CSV、summary_1104/cpd.parquet，以及离线Vue运行时。输出目录和全部脚本使用相对__file__路径；原始输入路径在脚本中明确给出。

```bash
python3 scan.py
python3 prepare_finance.py
python3 history.py
# 下面三个读取公开行情，只在需要重取时运行；缓存已在ticks/和flows/。
python3 fetch_ticks.py
python3 fetch_sse.py
python3 fetch_flows.py
python3 analyze_ticks.py
python3 build_report.py
python3 validate.py
```

公开请求清单保留在tick_fetch_first_attempt.json、tick_fetch_manifest.json、sse_manifest.json、flow_first_attempt.json、flow_fetch_manifest.json。网络重取可能不再给2026-11-06快照：不能将后来的行情重新打上本报告日期；复现应优先用本地已固定原始响应。没有把Fuyao密钥放进任何脚本、输出或压缩包。任务指定的密钥路径不存在，未绕找其他凭据。

数据口径：东财3秒快照按成交量手×100转股；925前虚拟量不累加；仅925最终竞价量单计。主动买卖是成交方向，不是实际资金身份；封板时方向偏卖不可当逃跑证据。大快照净额、东财委托规模资金流、龙虎榜机构/游资身份三种口径不可混为一谈。

验证：全部291只五组MA逐只重算；日线hash和mtime未改变；250只最新快照收盘价匹配日线、成交量覆盖90%—110%；钧达11-03半天单独标出。独立Canvas渲染291只×3跨度；不调用浏览器，不宣称交互端到端验证。

HTML可完全离线打开。压缩包不带海量原始快照；原始快照和完整请求审计保留在本机报告目录。preview.png为静态研究预览，canvas_preview.png为独立渲染预览，均非网页截图。

不构成投资建议
