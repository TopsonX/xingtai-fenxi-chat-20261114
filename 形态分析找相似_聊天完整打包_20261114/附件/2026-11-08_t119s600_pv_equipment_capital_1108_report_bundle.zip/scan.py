import pandas as pd,numpy as np,pathlib,json,re,hashlib
O=pathlib.Path(__file__).parent; ROOT=pathlib.Path('/workspace/fuyao/market_daily')
a=pd.read_csv('/workspace/archive_limitup_2y.csv',dtype={'code':str}).fillna('');a=a[a.date<='2026-11-06'].drop_duplicates(['date','code'])
q=json.load(open('/workspace/fuyao/summary_1104/qt_all.json'));names={k[-6:]:v[1] for k,v in q.items()if len(v)>2}
b=pd.read_csv(O/'sources/equipment_public.csv');b['code']=b.iloc[:,0].str.extract(r'(\d{6})');b['name']=b.iloc[:,0].str.replace(r'\s*\d{6}.*','',regex=True);names.update(dict(zip(b.code,b.name)))
latest=a.sort_values('date').groupby('code').tail(1).set_index('code');latestnames=latest.name.to_dict()
pat=r'光伏|硅料|硅片|电池片|太阳能电池|太阳能组件|光伏组件|逆变器|钙钛矿|TOPCon|TOPCON|HJT|BC电池|BC技术|光伏玻璃|光伏胶膜|光伏浆料|光伏边框|石英坩埚|光伏支架|异质结|硅棒|硅锭|N型电池'
sel=a.industry.str.contains('光伏',case=False)|a.reason.str.contains(pat,case=False,regex=True)

# A semiconductor silicon-wafer reason is not a photovoltaic catalyst.
false_silicon=sel & ~a.industry.str.contains('光伏') & ~a.reason.str.contains(r'光伏|钙钛矿|HJT|TOPCon|BC电池|太阳能|多晶硅',case=False) & a.reason.str.contains(r'半导体|芯片|VCSEL|抛光硅片',case=False)
a[false_silicon].to_csv(O/'excluded_semiconductor_events.csv',index=False)
ev=a[sel & ~false_silicon].copy();equipment=set(b.code)
extra={'300751':'迈为股份','688516':'奥特维','603396':'金辰股份','688556':'高测股份','300724':'捷佳伟创','300316':'晶盛机电','300776':'帝尔激光'};equipment.update(extra);names.update(extra)
allcodes=equipment|set(ev.code);excluded=[];rows=[]
equipproc=set('300751 688516 603396 688556 300724 300316 300776 688726 300029 300532 300700 002957 300809 688082 300567 300480 300757 688147 300056'.split())
main=set('600438 601012 002129 002459 688223 688599 688472 688303 600732 002865 002506 300093 603185 300118 300393 300345 300051 603778 688429 300080 002056 600481 002309 002218 600151'.split())
inverter=set('300274 605117 300763 688390 688032 688348 300827 688717 301658 002150'.split())
aux=set('603381 301697 600207 603806 601865 002623 688503 300842 002079 688680 688560 603212 001269 688408 603628 301266 301278 301168 301636 003022 002514 002865'.split())
station=set('000591 001258 000537 600821 600886 600905 600032 600163 000040 600642 600025 600674 600900'.split())
def category(code,txt):
 if code in equipproc:return '设备'
 if code in inverter:return '逆变器储能'
 if code in main:return '主链'
 if code in aux:return '辅材'
 if code in station:return '电站运营'
 if re.search('光伏设备|电池设备|硅片切割设备|串焊|PECVD|激光开槽',txt,re.I):return '设备'
 if re.search('光伏电站|电站运营|光伏发电|绿电',txt):return '电站运营'
 if re.search('逆变器|储能变流',txt):return '逆变器储能'
 if re.search('光伏玻璃|光伏胶膜|光伏浆料|光伏边框|光伏支架|石英坩埚|银浆|光伏焊带|背板',txt):return '辅材'
 if re.search('硅料|硅片|电池片|组件|HJT|TOPCon|BC电池',txt,re.I):return '主链'
 return '边缘嫁接'
for code in sorted(allcodes):
 name=names.get(code,latestnames.get(code,code));reason=' / '.join(ev[ev.code==code].tail(4).reason.tolist());ind=latest.loc[code,'industry']if code in latest.index else ''
 if not code.startswith(('0','3','6'))or re.search(r'ST|退',name,re.I):excluded.append({'code':code,'name':name,'reason':'ST/退市/北交所'});continue
 rows.append({'code':code,'name':name,'equipment':int(code in equipment),'limitup_related':int(code in set(ev.code)),'category':category(code,reason+' '+ind),'industry':ind,'recent_reason':reason,'match_basis':'东财BK1031公开成分'if code in set(b.code)else('设备核心补充'if code in equipment else'涨停原因/行业匹配')})
u=pd.DataFrame(rows);u.to_csv(O/'universe.csv',index=False);pd.DataFrame(excluded).to_csv(O/'excluded.csv',index=False);ev=ev[ev.code.isin(u.code)];ev.to_csv(O/'pv_limitup_events.csv',index=False)
K=[];D={};audit=[]
for r in rows:
 code=r['code'];p=ROOT/(('sh'if code[0]=='6'else'sz')+code+'.csv')
 if not p.exists():audit.append({'code':code,'status':'missing daily'});continue
 d=pd.read_csv(p);d=d[d.date<='2026-11-06'].sort_values('date').drop_duplicates('date').reset_index(drop=True)
 for n in [7,45,120,180,200]:d['ma'+str(n)]=d.close.rolling(n).mean()
 c=d.iloc[-1];prev=d.iloc[-2];ma={n:c['ma'+str(n)]for n in [7,45,120,180,200]};slope=(d.ma200.iloc[-1]/d.ma200.iloc[-21]-1)*100 if len(d)>220 else np.nan
 ret=lambda n:(c.close/d.close.iloc[-n-1]-1)*100 if len(d)>n else np.nan
 vratio=d.vol.iloc[-5:].mean()/d.vol.iloc[-25:-5].mean()if len(d)>25 else np.nan
 stage='长线下方反弹'if c.close<ma[200]and c.close>ma[45]else'弱势/下行'if c.close<ma[200]else'长线修复'
 if c.close>max(ma.values()):stage='多线之上/趋势候选'
 if ma[7]>ma[45]>ma[120]>ma[200]:stage='均线多头'
 if len(d)<200:stage='次新/长均线不足'
 stage+=('·放量'if vratio>=1.5 else'·缩量'if vratio<.8 else'·平量')
 k={**r,'asof':c.date,'close':c.close,'pct':(c.close/prev.close-1)*100,'ret5':ret(5),'ret20':ret(20),'ret60':ret(60),'volume5_prior20':vratio,'volume_today_prior20':c.vol/d.vol.iloc[-21:-1].mean(),'ma200_slope20':slope,'above200':int(c.close>=ma[200]),'above45':int(c.close>=ma[45]),'stage':stage,'vs2yhigh_pct':(c.close/d.high.iloc[-500:].max()-1)*100,'low20':d.low.iloc[-20:].min(),'high20':d.high.iloc[-20:].max(),'bars2y':int((d.date>='2024-09-06').sum()),**{'ma'+str(n):ma[n]for n in ma}}
 K.append(k);D[code]=d; audit.append({'code':code,'status':'ok','last':c.date,'rows':len(d),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'mtime':p.stat().st_mtime})
k=pd.DataFrame(K);k.to_csv(O/'kline_stage.csv',index=False);json.dump(audit,open(O/'daily_audit.json','w'),ensure_ascii=False,indent=2)
# Stock-date-range unique LHB: 1d is additive; multi-day disclosure is separate, not summed twice.
L=[]
for f in ['market_all.csv','market_org.csv']:
 t=pd.read_csv('/workspace/fuyao_lhb_market/'+f,dtype={'ticker':str});t=t[t.ticker.isin(u.code)].copy();t['origin']=f;L.append(t)
l=pd.concat(L,ignore_index=True);keys=['trade_date','ticker','range_days'];l=l.sort_values('origin',ascending=False).groupby(keys,dropna=False,as_index=False).first();l['range_days']=pd.to_numeric(l.range_days,errors='coerce');
for c in ['net_value','hot_money_net_value','org_net_value','buy_value','sell_value']:l[c]=pd.to_numeric(l[c],errors='coerce')
l['additive']=l.range_days.eq(1);l.to_csv(O/'lhb_events.csv',index=False)
ls=[]
for code,g in l.groupby('ticker'):
 row={'code':code,'name':names.get(code,latestnames.get(code,code)),'disclosures':len(g),'multi_day_disclosures':int((~g.additive).sum())}
 for label,h in [('year',g[g.additive]),('week',g[g.additive&(g.trade_date>='2026-11-02')])]:
  row[label+'_days']=h.trade_date.nunique()
  for c in ['net_value','hot_money_net_value','org_net_value']:row[label+'_'+c]=h[c].sum(min_count=1)/1e8
 ls.append(row)
pd.DataFrame(ls).to_csv(O/'lhb_summary.csv',index=False)
h=pd.read_csv('/workspace/fuyao_lhb_market/market_hot_money_stock_rows.csv',dtype={'ticker':str});h=h[h.ticker.isin(u.code)].drop_duplicates(['trade_date','ticker','range_days','hot_money_name']);h.to_csv(O/'lhb_seats.csv',index=False)
counts={'asof':'2026-11-06','archive_start':a.date.min(),'equipment':int(u.equipment.sum()),'limitup_names':int(u.limitup_related.sum()),'union':len(u),'events':len(ev),'daily_ok':len(k),'daily_stale':k[k['asof']!='2026-11-06'][['code','name','asof']].to_dict('records'),'excluded':len(excluded),'recent5_events':len(ev[ev.date>='2026-11-02']),'recent20_start':sorted(a.date.unique())[-20],'recent20_events':len(ev[ev.date>=sorted(a.date.unique())[-20]])}
json.dump(counts,open(O/'counts.json','w'),ensure_ascii=False,indent=2);print(json.dumps(counts,ensure_ascii=False))
print(k[k.equipment.eq(1)].groupby('category').agg(n=('code','count'),up5=('ret5',lambda x:(x>0).sum()),above200=('above200','sum'),median5=('ret5','median'),median20=('ret20','median')).round(2).to_string())
print('LHB WEEK',l[l.trade_date>='2026-11-02'][['trade_date','ticker','name','range_days','hot_money_net_value','org_net_value']].to_string(index=False))
