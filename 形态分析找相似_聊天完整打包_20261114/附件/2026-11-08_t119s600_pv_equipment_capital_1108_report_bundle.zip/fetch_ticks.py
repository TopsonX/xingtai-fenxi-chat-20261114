import pathlib,pandas as pd,requests,json,concurrent.futures,time
O=pathlib.Path(__file__).parent;u=pd.read_csv(O/'universe.csv',dtype={'code':str}); manifest=[]
def get(r):
 c=r['code'];p=O/'ticks'/(c+'_20261106.json')
 if p.exists():
  j=json.load(open(p));return dict(code=c,status='cached',n=len((j.get('data')or{}).get('details',[])))
 try:
  q={'secid':('1.'if c[0]=='6'else'0.')+c,'fields1':'f1,f2,f3,f4,f5','fields2':'f51,f52,f53,f54,f55','pos':'-100000','iscca':'1','fltt':'2'}
  r=requests.get('https://push2.eastmoney.com/api/qt/stock/details/get',params=q,timeout=18);j=r.json()
  if r.status_code==200 and (j.get('data')or{}).get('details'):
   p.write_text(json.dumps(j,ensure_ascii=False));return dict(code=c,status='ok',n=len(j['data']['details']))
  return dict(code=c,status='no data',http=r.status_code)
 except Exception as e:return dict(code=c,status=type(e).__name__)
with concurrent.futures.ThreadPoolExecutor(max_workers=6)as ex:
 for i,r in enumerate(ex.map(get,u.sort_values('equipment',ascending=False).to_dict('records'))):
  manifest.append(r)
  if i%20==0:print(i+1,'/',len(u),r,flush=True);json.dump(manifest,open(O/'tick_fetch_manifest.json','w'),indent=2)
json.dump(manifest,open(O/'tick_fetch_manifest.json','w'),indent=2);print('DONE',pd.DataFrame(manifest).groupby('status').size().to_dict(),flush=True)
