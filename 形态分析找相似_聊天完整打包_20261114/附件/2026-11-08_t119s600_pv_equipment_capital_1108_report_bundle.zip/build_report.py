import pathlib,json,pandas as pd,numpy as np,base64,html,re,io,zipfile,hashlib,warnings
warnings.filterwarnings('ignore')
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.patches import Rectangle
O=pathlib.Path(__file__).parent;ROOT=pathlib.Path('/workspace/fuyao/market_daily');font_manager.fontManager.addfont('/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc');plt.rcParams.update({'font.sans-serif':['Noto Sans CJK SC'],'axes.unicode_minus':False,'font.size':10})
U=pd.read_csv(O/'universe.csv',dtype={'code':str}).fillna('');K=pd.read_csv(O/'kline_stage.csv',dtype={'code':str});T=pd.read_csv(O/'tick_summary.csv',dtype={'code':str});F=pd.read_csv(O/'flow_summary.csv',dtype={'code':str});E=pd.read_csv(O/'pv_limitup_events.csv',dtype={'code':str}).fillna('');L=pd.read_csv(O/'lhb_events.csv',dtype={'ticker':str});LS=pd.read_csv(O/'lhb_summary.csv',dtype={'code':str});SEAT=pd.read_csv(O/'lhb_seats.csv',dtype={'ticker':str});FIN=pd.read_csv(O/'finance_background.csv',dtype={'SECURITY_CODE':str});C=json.load(open(O/'counts.json'));HC=json.load(open(O/'history_summary.json'));TC=json.load(open(O/'tick_coverage.json'))
N=U.set_index('code').name.to_dict();ku=K.set_index('code');today=T[T.date.eq('2026-11-06')].set_index('code');ff=F[F.date.eq('2026-11-06')].set_index('code');fin=FIN.set_index('SECURITY_CODE');wk=E[E.date>='2026-11-02'];currentcodes=set(wk.code)|set(U[U.equipment.eq(1)].code);L['current_pv_scope']=L.ticker.isin(currentcodes)|L.limit_reason.fillna('').str.contains('光伏|钙钛矿|HJT|TOPCon|逆变器',case=False)
# Contemporary LHB scope is narrower than the two-year historical union.
weekL=L[(L.trade_date>='2026-11-02')&L.current_pv_scope];one=weekL[weekL.range_days.eq(1)];yearone=L[L.range_days.eq(1)];cur=K[(K.equipment.eq(1))&(K['asof']=='2026-11-06')]
lf=lambda x:f'{float(x):+.2f}'if pd.notna(x)else'—'
f=lambda x,n=2:f'{float(x):.{n}f}'if pd.notna(x)else'—'
esc=lambda x:html.escape(str(x))
def table(df,cols=None):
 if cols is not None:df=df[cols]
 d=df.copy()
 for c in d:
  if pd.api.types.is_numeric_dtype(d[c]):d[c]=d[c].map(lambda x:f(x))
 return '<div class="scroll">'+d.fillna('—').to_html(index=False,escape=True,border=0,classes='data')+'</div>'
def stocklink(code):return f'<button class="stock" onclick="window.pickPV(\'{code}\')">{esc(N.get(code,code))} {code}</button>'
def stocktable(df,cols,labels):
 h='<div class="scroll"><table><thead><tr>'+''.join('<th>'+esc(x)+'</th>'for x in labels)+'</tr></thead><tbody>'
 for r in df.to_dict('records'):
  h+='<tr>'+''.join('<td>'+ (stocklink(r[c])if c=='code'else(f(r[c])if isinstance(r[c],(float,np.floating))else esc(r[c]if pd.notna(r[c])else'—')) )+'</td>'for c in cols)+'</tr>'
 return h+'</tbody></table></div>'
# Full-history rolling MA, display all available bars within archive window.
D={};stocks=[];priority=['002578','603381','301697','300751','300724','688516','603396','688556','300776','300316','300274','605117','300763','601012','600438','600732','688429']+wk.code.tolist();order={c:i for i,c in enumerate(dict.fromkeys(priority))}
for r in U.to_dict('records'):
 code=r['code'];d=pd.read_csv(ROOT/(('sh'if code[0]=='6'else'sz')+code+'.csv'));d=d[d.date<='2026-11-06'].sort_values('date').drop_duplicates('date').reset_index(drop=True)
 for w in [7,45,120,180,200]:d['ma'+str(w)]=d.close.rolling(w).mean()
 D[code]=d;x=d[d.date>='2024-09-06'];bars=x[['date','open','close','high','low','vol','ma7','ma45','ma120','ma180','ma200']].copy();
 for c in bars.columns[1:]:bars[c]=bars[c].round(3)
 arr=json.loads(bars.to_json(orient='values'));stocks.append({'code':code,'name':r['name'],'category':r['category'],'equipment':r['equipment'],'stage':ku.loc[code,'stage'],'asof':ku.loc[code,'asof'],'bars':arr})
stocks.sort(key=lambda r:(order.get(r['code'],9999),-r['equipment'],r['code']))
payload={'stocks':stocks,'columns':['date','open','close','high','low','vol','ma7','ma45','ma120','ma180','ma200']};(O/'chart_data.json').write_text(json.dumps(payload,ensure_ascii=False,separators=(',',':')))
# Representative matched price and snapshot-flow plots. Snapshot net is a convention, not investor identities.
BG='#0b1424';FG='#cbd7e8';UP='#ef5d65';DN='#27c194';colors=['#e5e9f1','#5ba9ff','#c29aff','#f3d45a','#f29b4b']
def style(ax):
 ax.set_facecolor(BG);ax.tick_params(colors=FG,labelsize=8);ax.grid(alpha=.12,color=FG)
 for s in ax.spines.values():s.set_color('#35465c')
 ax.title.set_color(FG);ax.yaxis.label.set_color(FG);ax.xaxis.label.set_color(FG)
def tickdf(code):
 p=O/'ticks'/f'{code}_20261106.json'
 if not p.exists():return None
 j=json.load(open(p));rows=[]
 for x in (j.get('data')or{}).get('details',[]):
  z=x.split(',')
  if '09:30:00'<=z[0]<='15:00:59':
   tm=pd.Timestamp('2026-11-06 '+z[0]);m=(tm.hour*60+tm.minute+tm.second/60)-(570 if tm.hour<12 else 660)
   rows.append([m,float(z[1]),float(z[1])*float(z[2])*100,1 if z[4]=='2'else-1 if z[4]=='1'else 0])
 return pd.DataFrame(rows,columns=['m','p','amt','dir'])
images=[]
for code in ['002578','603381','301697','300724','688516','300274']:
 d=D[code].tail(85).reset_index(drop=True);fig=plt.figure(figsize=(12.5,7),facecolor=BG);gs=fig.add_gridspec(3,2,height_ratios=[2.3,.65,1.8],hspace=.43,wspace=.23);a=fig.add_subplot(gs[0,:]);av=fig.add_subplot(gs[1,:],sharex=a);b=fig.add_subplot(gs[2,0]);bn=fig.add_subplot(gs[2,1]);
 for ax in [a,av,b,bn]:style(ax)
 for i,r in d.iterrows():
  col=UP if r.close>=r.open else DN;a.vlines(i,r.low,r.high,color=col,lw=.7);a.add_patch(Rectangle((i-.32,min(r.open,r.close)),.64,max(abs(r.close-r.open),.005),facecolor=col));av.bar(i,r.vol/1e4,color=col,width=.7)
 for w,col in zip([7,45,120,180,200],colors):a.plot(range(len(d)),d['ma'+str(w)],color=col,lw=1,label='MA'+str(w))
 a.legend(ncol=5,facecolor=BG,labelcolor=FG,fontsize=8);a.set_title(f'{N[code]} {code} · 日K与11-06快照资金');a.tick_params(labelbottom=False);ix=np.linspace(0,len(d)-1,6).astype(int);av.set_xticks(ix);av.set_xticklabels(d.date.iloc[ix].str[5:]);av.set_ylabel('万手');t=tickdf(code)
 if t is not None and len(t):
  b.plot(t.m,t.p,color='#71c5ff',lw=1);b.axhline(today.loc[code,'vwap'],color='#f3d45a',lw=.8,ls='--');b.set_title('连续竞价价格 / 全日VWAP');bn.plot(t.m,(t.amt*t.dir).cumsum()/1e8,color='#71c5ff',label='全快照主动净额');bn.plot(t.m,(t.amt*t.dir*(t.amt>=1e6)).cumsum()/1e8,color='#f3d45a',label='≥100万快照净额');bn.axhline(0,color=FG,lw=.6);bn.set_title('累计方向净额（亿元）');bn.legend(facecolor=BG,labelcolor=FG,fontsize=8)
 for ax in [b,bn]:ax.set_xticks([0,60,120,180,240]);ax.set_xticklabels(['9:30','10:30','11:30/13','14:00','15:00'])
 fig.text(.08,.015,'红涨绿跌；约3秒成交快照，不是逐笔委托。涨停成交方向偏卖不能直接解读为资金出逃。',color=FG,fontsize=9);p=O/'charts'/f'{code}_daily_tick.png';fig.savefig(p,dpi=115,bbox_inches='tight',facecolor=BG);plt.close(fig);images.append((code,p))
# Financial dimensional notes with explicit observations and hypothesis limits.
motives={
'002578':('边框是真业务，但本轮叠液冷铝材、机器人与扭亏，是跨题材高标接力，不等于设备订单复苏。','每经11-06盘后报道转述公司：前三季光伏收入占17.45%、毛利率3.13%，对利润贡献低；扣非仍亏834.85万元。'),
'603381':('真光伏铝边框，叠电池铝箔、人形机器人；四板更像成长想象+低基数业绩弹性接力。','营收同比与净利同比必须拆看；净利大增不代表光伏加工费已全面反转。'),
'301697':('真浆料/银粉方向，叠次新、半导体材料、电子皮肤；三板交易的是高弹性与筹码稀缺。','上市时间短、MA200不足；换手和封板不等于机构长期锁仓。'),
'300751':('HJT等电池设备技术切换的高弹性映射；本周急涨并非“安静潜伏”。','设备新订单、预收/合同负债与验收增长本次没有独立订单证据；不能从反弹倒推订单复苏。'),
'300724':('电池设备/新技术资本开支预期，属于真设备。','订单转收入与客户扩产兑现尚需公告；三季报是当下背景，不是历史涨停原因。'),
'688516':('串焊等设备需求与技术迭代预期，属于真设备。','量价反弹和利润恢复线索需与营收、现金回款交叉，不能把大快照净买当机构增持。'),
'603396':('电池/组件设备技术升级预期，真设备但资金延续性需验证。','短线放量与盈利改善是两套命题。'),
'688556':('硅片切割设备与切片需求修复预期。','主链扩产意愿、设备需求与盈利拐点不能从单周反弹确认。'),
'300776':('BC激光工艺等技术迭代弹性，真设备。','技术路线热度不等于新增设备订单已经回款。'),
'300316':('晶体生长设备，兼具半导体线索；不能把所有成交都归因光伏。','需要分业务订单结构；本次未补分部新签订单。'),
'688726':('电池片热制程/技术升级设备，真设备。','仍需验证新订单、毛利和验收，反弹未证明主链扩产周期重启。'),
'300274':('真逆变器/储能，资金交易盈利韧性与出海空间，但11-06有兑现。','不能把储能增长预期当全光伏主链反转；本次无最新出口订单原始明细。'),
'605117':('真逆变器/储能，偏出海和产品结构成长预期。','有利润不等于本期仍高增长，以下列营收和净利同比核对。'),
'300763':('真逆变器，海外需求及储能配套预期。','出口复苏假说需订单/区域营收佐证，不用K线代替。'),
'002865':('光伏电池本业，叠商业航天/太空光伏；本轮有技术想象和高换手。','既有历史tick仅10-29至11-04五天，其中11-03午后缺失；不能冒充本周完整逐笔。'),
'300093':('真HJT电池，但当周涨停叠算力服务/GPU采购，技术与算力双题材。','当周龙虎榜游资净额显著高于机构；不能据此证明纯HJT订单放量。'),
'600481':('真光伏硅片与传统节能业务，当前叠冷却塔/液冷。','液冷题材与硅片盈利修复必须拆开。'),
'603185':('真硅片/一体化及装备，博弈主链低位修复与TOPCon。','主链盈利持续反转需要价格、库存与现金流验证。'),
'002506':('真组件，GPC电池+储能系统的技术/产品弹性。','短线涨停不等于组件行业已恢复合理利润。'),
'002623':('真光伏玻璃，叠玻璃基板与钙钛矿玻璃。','本地日线止于11-02，不能确认后四日承接；最新状态留缺口。'),
'603628':('真光伏支架+储能+回购，产业链辅材分支。','放量上涨先看回踩与后续订单，不能直接视作吸筹。'),
'001269':('真石英坩埚，叠半导体石英坩埚和亏损收窄。','半导体增量与光伏耗材景气应分开核验。'),
'603212':('真胶膜等材料，叠半导体材料和减亏。','减亏不是盈利增长周期已确认。'),
'600207':('真光伏玻璃，博弈高透产品与国资、低位补涨。','玻璃涨价与单位盈利恢复本次没有独立报价确认。'),
'002309':('光伏储能+特种线缆+扭亏/国资，兼具业务和重整后弹性。','扭亏需剥离非经常性项目，不能仅用净利同比判断内生成长。'),
'002529':('光伏组件/HJT加汽车轻量化，跨产业链题材叠加。','汽车客户概念不等于光伏需求强，注意涨停后的高换手。'),
'002135':('光伏建筑一体化+装配式建筑+回购，偏BIPV嫁接，不是电池生产设备。','光伏新增收入、毛利贡献本次未获独立核验。'),
'600539':('光伏+机器视觉+先进封装/AI，多题材映射，边缘嫁接。','不能凭标签当成设备订单复苏的产业锚。'),
'000591':('真光伏电站运营，但当周叠机器人、“羊”字辈；不是光伏制造设备。','龙虎榜游资买、机构卖，偏交易性；电站现金流逻辑另看。'),
'001258':('真风光电站，疆电外送与三季报增长的运营分支。','电站运营不享有电池设备订单弹性，不能混作同一主线。'),
'002310':('电站新能源转型叠重组、扭亏与“东方”字辈，事件弹性。','字辈接力不构成产业景气证据。'),
'603366':('储能/空气能热泵叠光伏和“东方”字辈，跨题材接力。','不是纯光伏设备景气锚，需验证新增业务营收。'),
'688429':('光伏湿制程/叠栅技术与TOPCon电池，真技术分支但制造混合。','11-06机构净卖、游资小幅净买；不能将技术热度等同机构持续建仓。'),
}
important=list(dict.fromkeys(priority+list(motives)+['603806','688503','601012','600438','600732','688390','688717']))
# Add any current PV name with disclosed positive institutional one-day net.
important+=list(one[one.org_net_value>0].ticker);important=list(dict.fromkeys(c for c in important if c in N))
notes=[]
for code in important:
 k=ku.loc[code];tg=today.loc[code]if code in today.index else None;fg=ff.loc[code]if code in ff.index else None;lh=weekL[weekL.ticker.eq(code)];curreason=wk[wk.code.eq(code)].sort_values('date').tail(1);mot,extra=motives.get(code,(('当周原因：'+curreason.iloc[0].reason)if len(curreason)else('业务/历史关联：'+U.set_index('code').loc[code,'recent_reason']), '产业链业务真实不等于当前资金在交易这一项；无独立订单证据不宣称订单反转。'))
 fund='逐笔快照未取得，不能下主动资金结论。'if tg is None else f"11-06：{tg['verdict']}；全快照主动净额{lf(tg.net_yi)}亿，≥100万快照{lf(tg.net100_yi)}亿，开盘30分钟{lf(tg.open30_net_yi)}亿、尾盘{lf(tg.tail_net_yi)}亿；收盘相对VWAP {lf(tg.close_vs_vwap_pct)}%；成交量覆盖{f(tg.coverage_pct,1)}%。"
 if fg is not None:fund+=f" 另一口径东财主力净额{lf(fg.main_yi)}亿（大单+超大单，不是机构身份）。"
 if len(lh):
  singles=lh[lh.range_days.eq(1)];fund+=f" 当周单日榜机构{lf(singles.org_net_value.sum(min_count=1)/1e8)}亿、识别游资{lf(singles.hot_money_net_value.sum(min_count=1)/1e8)}亿；{len(lh[lh.range_days.ne(1)])}条多日榜另列、不叠加。"
 else:fund+=' 当周本地龙虎榜未披露该股，机构是否持续增持未知。'
 tech=f"{k.stage}；近5根{lf(k.ret5)}%、近20根{lf(k.ret20)}%，5日均量/此前20日均量{f(k.volume5_prior20)}倍。收{k.close:.2f}；MA7/45/120/180/200={f(k.ma7)}/{f(k.ma45)}/{f(k.ma120)}/{f(k.ma180)}/{f(k.ma200)}，MA200近20根斜率{lf(k.ma200_slope20)}%。距近500根最高价{k.vs2yhigh_pct:.2f}%（旧供给代理，非持仓）。20根成交区间{k.low20:.2f}—{k.high20:.2f}，只作换手/供给区代理，不是真实持仓成本。"
 if k['asof']!='2026-11-06':tech+=f" 最新仅{k['asof']}，不算截至11-06已确认。"
 if code in fin.index:
  z=fin.loc[code];finance=f"{str(z.REPORTDATE)[:10]}报告期，公告{str(z.NOTICE_DATE)[:10]}：营收{z.TOTAL_OPERATE_INCOME/1e8:.2f}亿，同比{lf(z.YSTZ)}%；归母{z.PARENT_NETPROFIT/1e8:.2f}亿，同比{lf(z.SJLTZ)}%。";growth='营收与归母均同比增长，存在当期增长佐证，但尚缺订单、扣非与现金回款完整交叉。'if z.YSTZ>0 and z.SJLTZ>0 and z.PARENT_NETPROFIT>0 else'当期营收/利润未形成同步正增长，资金更可能交易未来修复或题材弹性，不能当已兑现成长。'
 else:finance='';growth='财务缺项，留空；不推断增长。'
 notes.append({'code':code,'name':N[code],'fund':fund,'tech':tech,'theme':mot,'finance':finance,'growth':growth+' '+extra})
# Aggregate sector readings are disclosed samples, not total incremental cash.
breadth=[]
for cat,g in cur.groupby('category'):
 ts=today.loc[today.index.intersection(g.code)];fs=ff.loc[ff.index.intersection(g.code)];breadth.append({'分类':cat,'11-06有效日线':len(g),'一周上涨':int((g.ret5>0).sum()),'11-06上涨':int((g.pct>0).sum()),'MA200上方':int(g.above200.sum()),'周涨幅中位%':g.ret5.median(),'20根涨幅中位%':g.ret20.median(),'量比中位':g.volume5_prior20.median(),'快照覆盖股数':len(ts),'东财流量股数':len(fs),'东财主力净额亿_样本':fs.main_yi.sum(min_count=1)})
breadth=pd.DataFrame(breadth);breadth.to_csv(O/'equipment_breadth.csv',index=False)
ct=cur[cur.category.eq('设备')];sample=ff.loc[ff.index.intersection(cur.code)];org=one.org_net_value.sum(min_count=1)/1e8;hot=one.hot_money_net_value.sum(min_count=1)/1e8
paras=[
f"有资金在打，而且不只是边框小票：东财光伏设备60只非ST沪深成分中，58只有11-06日线，这58只近5根全部上涨；真生产设备核心迈为周涨35.24%、奥特维28.63%、捷佳16.21%，阳光电源25.55%。但这轮更像‘深跌后的预期修复+新技术弹性’，不是已确认的主链扩产牛市：58只中仅{int(cur.above200.sum())}只站在MA200上方，真设备子组{len(ct)}只中{int(ct.above200.sum())}只站上MA200。",
f"11-05涨停扩散到{int((wk.date=='2026-11-05').sum())}次后，11-06只剩{int((wk.date=='2026-11-06').sum())}次，闽发5板、永臻4板、贝特利3板延续，而58只有效行业成分仅{int((cur.pct>0).sum())}只收涨。高标在带情绪，不等于核心制造已转成长线主升。阳光当日快照≥100万净额{lf(today.loc['300274','net100_yi'])}亿、收盘低于VWAP {abs(today.loc['300274','close_vs_vwap_pct']):.2f}%；奥特维、捷佳等存在大快照承接，但价格仍回落，是双向博弈而非单边吸筹。",
f"席位证据偏交易性：当前光伏范围的当周单日龙虎榜，识别游资合计{lf(hot)}亿、机构专用{lf(org)}亿（仅披露样本，多日榜不叠加）。闽发11-06三日榜机构净卖0.60亿；金刚11-05游资净买0.71亿、机构0.08亿，贝特利11-06机构仅0.07亿。迈为等大票本周未上榜，不能说机构没来，也不能说已证实‘机构悄悄建仓’。迈为一周35%本身也谈不上安静。",
f"资金更可能在博弈三层：①反内卷/出清的底部估值修复；②HJT、BC、叠栅等技术切换带来的未来增长可选性；③边框/浆料/玻璃的高弹性，叠机器人、液冷、算力、次新、字辈接力。订单复苏、辅材普遍涨价和出口再加速，本次证据不足以坐实。重要限制：本次已逐股扫描{C['union']}只日K，实际取得{TC['names']}只、{TC['stock_days']}股日快照；主要是11-06，历史补充仅钧达10-29至11-04五天，未取得全池近7日逐笔，不能把单日承接说成连续建仓。"
]
summary={'asof':'2026-11-06 收盘（Asia/Singapore，UTC+8）','counts':C,'capital_conclusion':paras,'tick_coverage':TC,'flow_coverage_names':int(F.code.nunique()),'current_week_lhb_1day':{'stocks':int(one.ticker.nunique()),'records':len(one),'hot_money_net_yi':hot,'org_net_yi':org},'year_union_lhb_1day':{'stocks':int(yearone.ticker.nunique()),'records':len(yearone),'hot_money_net_yi':yearone.hot_money_net_value.sum(min_count=1)/1e8,'org_net_yi':yearone.org_net_value.sum(min_count=1)/1e8},'breadth':breadth.to_dict('records'),'deep_notes':notes,'history':HC,'gaps':['未取得全池近7日逐笔；历史tick服务HTTP503。','任务指定Fuyao密钥路径不存在，未查询/绕找其他凭据；高频接口文档返回动向指标，并非逐笔成交或OHLC分钟线。','东财历史资金流/五日分时请求实际只返回11-06，未将其冒充5日/20日。','迈为逐笔请求多次HTTP502，只有11-06分钟价格与东财日资金流，不能做其逐笔大单结论。','TCL中环本地日线止于10-30，亚玛顿止于11-02；未刷新、未冒充当前数据。','龙虎榜仅披露上榜席位；未取得全池融资变化、基金持仓变化和真实逐笔委托/封单队列。','业务分类为研究标签；多业务公司需看分部收入，不将历史光伏关联公司当前其他题材资金归为光伏。'],'not_advice':'不构成投资建议'}
(O/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2,default=lambda v:int(v)if isinstance(v,np.integer)else float(v)))
# Main offline document.
css='''*{box-sizing:border-box}body{margin:0;background:#080f1c;color:#d9e4f4;font:15px/1.85 system-ui,"Noto Sans CJK SC",sans-serif}main{max-width:1350px;margin:auto;padding:38px 30px}h1{font-size:35px;line-height:1.4;margin:10px 0}h2{font-size:25px;margin-top:48px;border-bottom:1px solid #2a3b53;padding-bottom:10px}h3{font-size:20px}p{margin:12px 0}a{color:#87c8ff}nav{display:flex;gap:16px;flex-wrap:wrap;margin:24px 0}section,.card,article{background:#101c2e;border:1px solid #26364e;border-radius:12px;padding:22px;margin:18px 0}.lead{font-size:18px}.warning{border-left:4px solid #f3cf60;background:#25241e;padding:14px 20px}.muted,small{color:#9cafc7}.metrics{display:grid;grid-template-columns:repeat(4,1fr);gap:12px}.metric{background:#14243c;border-radius:9px;padding:14px}.metric b{font-size:29px;color:#fff;display:block}.scroll{overflow:auto;max-height:700px}table{border-collapse:collapse;width:100%;font-size:13px;line-height:1.65;white-space:nowrap}td,th{text-align:left;border-bottom:1px solid #2b3a50;padding:9px 11px;vertical-align:top}th{position:sticky;top:0;background:#152840;color:#a4d0fa;z-index:1}td:last-child{white-space:normal;min-width:130px;max-width:550px}button,input,select{font:inherit;color:#d9e4f4;background:#182d49;border:1px solid #395171;border-radius:6px;padding:7px 10px}button{cursor:pointer}.stock{padding:1px 3px;border:0;color:#8bceff;background:none;white-space:nowrap}img{max-width:100%;border-radius:8px;margin-top:15px}summary{cursor:pointer;color:#8bceff}details{margin:12px 0}dt{font-weight:bold;color:#a8cfff}dd{margin:3px 0 14px}canvas{display:block;touch-action:none;cursor:crosshair}.controls{display:flex;gap:10px;flex-wrap:wrap}.tag{display:inline-block;padding:3px 10px;border-radius:5px;background:#243853;color:#f7d989}.footer{border-top:1px solid #33465e;margin-top:40px;padding:25px 0}@media(max-width:760px){main{padding:20px 12px}h1{font-size:27px}.metrics{grid-template-columns:1fr 1fr}section,article{padding:15px}}'''
H=['<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>光伏资金博弈全景 · 2026-11-06</title><style>'+css+'</style></head><body><main>','<span class="tag">资金面优先 · 日K全池扫描 / 当日快照 / 龙虎榜交叉</span><h1>钱在打光伏，但在赌什么？</h1><p class="muted">观察截至2026-11-06收盘；研究日2026-11-08，新加坡时间 UTC+8。离线报告，所有图表和Vue运行时已内嵌；日线原库未刷新。</p>','<section class="lead">'+''.join('<p>'+esc(p)+'</p>'for p in paras)+'</section>',f'<div class="metrics"><div class="metric"><b>{C["equipment"]}</b>行业全成分（非ST沪深）</div><div class="metric"><b>{C["union"]}</b>去重日K全池</div><div class="metric"><b>{TC["names"]}</b>实际快照覆盖股票</div><div class="metric"><b>{C["events"]}</b>两年光伏涨停事件</div></div>','<nav><a href="#scope">范围</a><a href="#week">本周</a><a href="#history">两年地图</a><a href="#lhb">龙虎榜</a><a href="#ticks">快照资金</a><a href="#interactive">可拖动K线</a><a href="#all">全池阶段</a><a href="#notes">重点逐股</a><a href="#games">博弈与证伪</a><a href="#limits">缺口</a></nav>']
H+=['<h2 id="scope">01 / 先把池子分清</h2>',f'<p>A层：公开东财BK1031成分69只，排北交所6只、ST类3只，保留60只（含全部真生产设备，并非只取涨停股）。B层：2024-09-06至2026-11-06档案，仅按涨停当日reason或industry匹配光伏、硅料/硅片/电池片、逆变器、钙钛矿、TOPCon、HJT、BC等；不从concept/product里“埋了光伏”来扩池。剔除半导体硅片语境且无光伏证据的事件后，保留{C["events"]}次、{C["limitup_names"]}只，两层并集{C["union"]}只。纯“光伏”字面匹配1317次/259只只是起点，本版加入明确太阳能技术词后增加关联票，逐条匹配事件在CSV中可查。</p>', '<p>分类标签：设备（生产装备）/主链（硅料硅片电池组件）/辅材/逆变器储能/电站运营/边缘嫁接。东财“光伏设备”是宽行业，不等于都是生产装备；闽发/永臻/贝特利的PV业务和机器人/次新等叠加题材分开看。分类是研究标签，不是营收占比审计。</p>','<p class="warning">“全部K线过一遍”=291只用代码逐根计算两年内OHLC、MA7/45/120/180/200及量价，再对重点逐股解读；不是声称逐只人工看盘。TCL中环最后K为10-30、亚玛顿11-02，已单独标记，不纳入11-06行业宽度。当前非ST名称快照过滤，不保证复原历史ST时点；有存续偏差。</p>',table(breadth)]
H+=['<h2 id="week">02 / 本周路径：扩散后，核心与高标分叉</h2>']
H.append('<section><h3>机构票还是游资一波流？先给资金画像</h3><p><b>接力路径较明确：</b>闽发5板、永臻4板、贝特利3板；金刚当周游资净额明显高于机构。贝特利11-06机构净买约718万元是参与，不足以把三板改判机构主导。永臻三日榜机构字段缺失，不能填零。</p><p><b>产业大票观察组，不是已证实机构票：</b>迈为、捷佳、奥特维、阳光。迈为当日东财主力+1.66亿但逐笔缺失；捷佳/奥特维有大快照承接，仍收跌；阳光则明显兑现。它们有真实业务与流动性承载，但缺少连续多日资金及机构持仓/席位证据，不能凭图形归为机构悄悄吸筹。</p><p><b>资金路径判断：</b>目前能确认的是“全行业反弹后，情绪高标继续接力、核心分歧”；尚不能确认产业机构在一波流退潮时接过主导权。一波流是否结束也需要后续交易日，不能现在预言必然结束。</p></section>')

for day,g in wk.groupby('date'):
 H.append(f'<article><h3>{day} · {len(g)}次</h3><p>'+ '；'.join(f'{esc(r.name)}({r.code}) {esc(r.board)} — {esc(r.reason)}'for r in g.itertuples())+'</p></article>')
H+=['<p>11-05首板扩散到硅片、组件、坩埚、胶膜、HJT，说明不是完全没有产业方向资金；11-06多数核心回落，但三个高标连板延续，说明拥挤后资金更愿意保留高辨识度筹码。应区分“题材高度”与“产业资金宽度”，后者尚未形成持续上攻确认。新闻09:33的“板块拉升”是盘中快讯，不拿来替代收盘分化。</p>']
H.append('<details><summary>当周逐股封板质量：档案封单/炸板/首封末封</summary>'+stocktable(wk.rename(columns={'break_n':'炸板次数','first_t':'首封','last_t':'末封','seal':'档案封单额'}),['code','date','board','炸板次数','首封','末封','档案封单额'],['名称/代码','日期','连板路径','炸板次数','首封','末封','档案封单额'])+'<p class="muted">封单额沿用当日涨停档案字段，不是从tick成交额推算；未独立取得挂单队列。</p></details>')
H+=['<h2 id="history">03 / 两年涨停地图：次数王 ≠ 当下最强</h2>',f'<p>可用“两年”起点是2024-09-06，不是完整自2024-11开始的精确滚动两年。近5交易日32次，近20个档案交易日（{C["recent20_start"]}起）43次。按股票-日期去重，只有当日光伏相关原因才计数；一家曾有光伏涨停，不代表其后每次涨停都归光伏。</p>']
rk=pd.read_csv(O/'limitup_rank.csv',dtype={'code':str});H.append(stocktable(rk.head(30),['code','events2y','events20','events5','last','recent_reason'],['名称/代码','两年次数','近20次','近5次','最近光伏涨停','最近相关原因']))
H.append('<h3>近20日最相关（先看频次，再看最近日期）</h3>');H.append(stocktable(rk[rk.events20>0].sort_values(['events20','last'],ascending=False),['code','events20','events5','last','recent_reason'],['名称/代码','近20次数','近5次数','最近日期','当时原因']))
monthly=pd.read_csv(O/'limitup_monthly.csv');H.append('<details><summary>两年完整月度时间线（逐日时间线另附CSV）</summary>'+table(monthly)+'</details>');H.append('<h3>历史最拥挤的交易日</h3>'+table(pd.DataFrame(HC['top_days'])))
for n,z in HC['fwd'].items():H.append(f'<p>历史相关涨停后{n}根收盘：可观察{z["n"]}个事件，收益中位{z["median_close_pct"]:+.2f}%，为正比例{z["positive_rate"]:.1f}%。不按未来涨幅选样；重叠事件不独立，涨停无法保证买入，未扣成本，且没有市场/行业超额对照，不能当策略胜率。</p>')
H.append('<p>历史次数王偏国晟、中利、海源、蓝丰等高弹性/转型票，不是稳定订单龙头排行榜。当前这一周既有产业大票同步反弹，也有熟悉的多题材高标接力；仅靠高标延续无法判定从几日游升级为产业新趋势。缺的是核心持续成交承接、长线结构修复和订单/利润增长的共同确认。</p>')
H+=['<h2 id="lhb">04 / 龙虎榜：识别游资与机构，不把历史池当当前光伏资金</h2>',f'<p>本地范围2025-11-07至2026-11-06。并集全池单日榜{len(yearone)}条、{yearone.ticker.nunique()}只：识别游资净额{lf(yearone.hot_money_net_value.sum(min_count=1)/1e8)}亿、机构{lf(yearone.org_net_value.sum(min_count=1)/1e8)}亿。这是“曾经有关光伏的股票”的全年披露，包含算力、机器人等其他行情，不是全年光伏净流入。</p>',f'<p>当周进一步收窄为当前光伏原因/行业成分/本周PV涨停票后，单日榜{len(one)}条、{one.ticker.nunique()}只，识别游资{lf(hot)}亿，机构{lf(org)}亿。润建、凯迪等仅历史光伏关联、当下在炒算力/机器人者，不拿来佐证本周光伏。缺失字段记“—”，不是认定零。</p>','<p class="warning">同一股票同一日、同一统计跨度去重；org与all按字段补全。只有range_days=1计入可加总净额，多日异常榜保留单列，避免与单日或滚动三日榜重复。机构专用席位可能包含量化/交易盘，不等于公募长线仓位；未上榜≠无机构；识别游资标签非完整资金身份。</p>']
ll=weekL[['trade_date','ticker','name','range_days','hot_money_net_value','org_net_value','limit_reason']].copy();ll[['hot_money_net_value','org_net_value']]/=1e8;ll.columns=['日期','代码','名称','统计天数','游资净亿','机构净亿','当期原因'];H.append(table(ll))
H.append('<h3>全池一年席位摘要（单日榜可加总，完整CSV）</h3>');H.append(stocktable(LS.sort_values('year_org_net_value',ascending=False),['code','year_days','year_hot_money_net_value','year_org_net_value','week_days','week_hot_money_net_value','week_org_net_value','multi_day_disclosures'],['名称/代码','一年单日上榜天','游资亿','机构亿','本周单日天','本周游资亿','本周机构亿','多日披露条数']))
ss=SEAT[(SEAT.trade_date>='2026-11-02')&SEAT.ticker.isin(currentcodes)].copy();ss['席位组净亿']=pd.to_numeric(ss.hot_money_item_net_value,errors='coerce')/1e8;ss['统计天数']=ss.range_days;H.append('<details><summary>当周识别游资席位组（逐条，不再加总滚动榜）</summary>'+table(ss[['trade_date','ticker','name','hot_money_name','统计天数','席位组净亿']])+'</details>')
H+=['<h2 id="ticks">05 / 竞价 + 快照：谁承接，谁兑现，谁在封板接力</h2>',f'<p>实际快照覆盖{TC["names"]}只、{TC["stock_days"]}股日、{TC["records"]:,}条，其中行业成分{TC["equipment_names"]}/60只。主要为11-06连续竞价与开盘竞价；旧钧达导出补10-29、10-30、11-02、11-03、11-04。11-03仅至11:30，不作全日结论。请求过全池，不等于全池都拿到数据；缺失股票和覆盖不完整日附在本节末。</p>','<p class="warning">东财details为约3秒成交快照/分笔汇总，不是真实逐笔委托。金额按价×成交股数；“≥50/100万”是单个快照合计额，不能叫真实大订单或据此识别机构。U/D只表示成交主动方向，所有交易都有买卖双方；净额不是新增现金。涨停板卖单打到买一封单常记为主动卖，因此永臻负净额不等于资金逃跑。09:15/09:20为虚拟竞价、非实际成交；竞价金额仅使用09:25最终打印。没有委托队列，不能从成交额推封单金额。</p>']
show=T.copy();show['竞价路径']=show.apply(lambda r:f'{f(r.auction915)}→{f(r.auction920)}→{f(r.auction_price)}',axis=1);show=show.sort_values(['equipment','date'],ascending=False);H.append(stocktable(show,['code','date','竞价路径','auction_gap_pct','auction_amount_yi','net_yi','net50_yi','net100_yi','open30_net_yi','tail_net_yi','close_vs_vwap_pct','coverage_pct','verdict'],['名称/代码','日期','9:15→9:20→9:25','跳空%','竞价额亿','主动净亿','≥50万净亿','≥100万净亿','开盘30m净亿','尾盘净亿','收盘/VWAP%','量覆盖%','判读']))
missing=U[~U.code.isin(T.code)];partial=T[T.completeness!='完整'];H.append('<details open><summary>没有取得快照的股票 / 不完整股日</summary><p>'+esc('；'.join(f'{r.name}({r.code})'for r in missing.itertuples()))+'</p>'+table(partial[['code','name','date','start','end','coverage_pct']])+'</details>')
H.append('<h3>另一口径：东财大单+超大单（仅11-06，完整可得样本）</h3><p>主力流量按平台委托规模分类，不是机构席位。与快照方向冲突时保留两套口径，不能选对自己有利的一边。比如迈为当日主力净额+1.66亿，却收跌，最多说明交易中有较大委托承接，尚不能证明长线机构吸筹。</p>');H.append(stocktable(F.sort_values('main_yi',ascending=False),['code','date','main_yi','big_yi','super_yi','category'],['名称/代码','日期','主力净亿','大单净亿','超大单净亿','分类']))
for code,p in images:H.append('<details><summary>'+esc(N[code])+' · 日K / 当日价格 / 累计方向净额图</summary><img alt="'+esc(N[code])+'日K与快照" src="data:image/png;base64,'+base64.b64encode(p.read_bytes()).decode()+'"></details>')
H+=['<h2 id="interactive">06 / 全池可拖动K线 · 不用ECharts</h2>','<div id="app"><section><div class="controls"><input v-model="query" placeholder="搜索代码/名称"><select v-model="group"><option>全部</option><option>行业全成分</option><option>设备</option><option>主链</option><option>辅材</option><option>逆变器储能</option><option>电站运营</option><option>边缘嫁接</option></select><select :value="selected" @change="select($event.target.value)"><option v-for="s in filtered" :key="s.code" :value="s.code">{{s.name}} {{s.code}}</option></select><button @click="reset">复位130根</button></div><h3>{{current.name}} {{current.code}} · {{current.category}}</h3><p class="muted">{{current.stage}} · 最后K {{current.asof}}。拖动平移，滚轮缩放，悬停看OHLC。白MA7、蓝MA45、紫MA120、黄MA180、橙MA200。全池均可切换。</p><div style="width:100%"><canvas ref="cv" @pointerdown="down" @pointermove="move" @pointerup="up" @pointercancel="up" @wheel.prevent="zoom"></canvas></div></section></div>']
cols=['code','category','asof','close','ret5','ret20','volume5_prior20','vs2yhigh_pct','ma7','ma45','ma120','ma180','ma200','ma200_slope20','stage'];labels=['名称/代码','分类','最后K日期','收盘','近5根%','近20根%','5/前20量比','距500根高点%','MA7','MA45','MA120','MA180','MA200','MA200/20根%','阶段']
H+=['<h2 id="all">07 / 行业全成分与并集全池：不遗漏弱票、深跌设备</h2>','<h3>行业60只：全部日线阶段</h3>',stocktable(K[K.equipment.eq(1)].sort_values(['category','ret5'],ascending=[True,False]),cols,labels),'<details><summary>展开并集全部291只（已含行业60只，不是增量）</summary>'+stocktable(K.sort_values(['category','ret5'],ascending=[True,False]),cols,labels)+'</details>','<p>阶段是机械分类：现价与均线相对位置、多头排序、5日均量/此前20日均量（≥1.5放量、＜0.8缩量）。“长线下方反弹”不等于马上反转，“多线之上”也不是买入指令。量价区间只作为潜在换手/供给代理；没有真实筹码持仓分布。</p>','<h2 id="notes">08 / 重点逐股：资金面先行，再看技术 / 题材 / 业绩 / 增长</h2>']
for n in notes:
 H.append('<article><h3>'+stocklink(n['code'])+'</h3><dl>'+''.join('<dt>'+k+'</dt><dd>'+esc(n[v])+'</dd>'for k,v in [('资金面','fund'),('技术/量价筹码','tech'),('当下在交易的题材假说','theme'),('业绩（只作当前背景）','finance'),('增长与证伪','growth')])+'</dl></article>')
H+=['<h2 id="games">09 / 到底在赌什么：假说、证据、失效点</h2>','<article><h3>① 出清 / 反内卷 / 超跌估值修复 —— 有价格证据，尚非利润反转</h3><p>行业有效58只一周全涨、设备与逆变器参与，支持资金在交易板块级低位修复；多数仍压在MA200下、主链多家三季报亏损，反驳“已进入确定扩产增长期”。若核心回吐11-04/05启动段、量能迅速回落且跌破MA45，修复主线即被削弱。产业确认应看真实减产出清、价格/库存、经营现金流，而不是再多几个涨停。</p></article>','<article><h3>② HJT / BC / 叠栅 / 钙钛矿技术切换 —— 买未来可选性，不等于所有路线都胜出</h3><p>迈为、捷佳、奥特维等真设备急涨，时创叠栅涨幅高，支持新技术资本开支预期；金刚叠算力、钧达叠太空光伏则有额外题材溢价。没有同期新签订单/验收/回款证据，不能直接说设备订单已复苏。若技术分支止于题材高换手、设备龙头无法持续收复MA45/120，技术行情将更接近几日游。</p></article>','<article><h3>③ 辅材价格/成长弹性 —— 最强高度在这里，但涨价未证实</h3><p>边框、浆料、坩埚、胶膜、玻璃都有本周涨停，市场在寻找主链低迷中更敏感的利润弹性；然而本次没有独立价格/加工费序列能证明普遍涨价。闽发光伏毛利率仅3.13%，公司明确利润贡献低，是反例。永臻净利大增而营收下滑，低基数不能当需求全面爆发；贝特利营收利润双增较扎实，但次新三板也有筹码与接力溢价。</p></article>','<article><h3>④ 储能 / 逆变器出海 —— 真分支，不替全行业背书</h3><p>阳光、德业、锦浪等周线反弹明显，但11-06阳光有大快照兑现；没有最新出口订单原始数据，不把“出海”当已核实增长加速。若逆变器强势与盈利增长不能延续，光伏主链也不能借它们的逻辑确认牛市。</p></article>','<article><h3>⑤ 机器人 / 液冷 / 算力 / 次新 / 字辈 —— 当周高标的强解释</h3><p>闽发=真边框+液冷/机器人；永臻=真边框+铝箔/机器人；贝特利=真浆料+次新/电子皮肤；金刚=HJT+GPU；双良=光伏+液冷；太阳能/日出东方/东方新能含字辈或跨题材。它们不是全都“假光伏”，而是PV真实敞口与交易催化不同。高标跌停/断板后若只有核心设备保持承接，才有从情绪链切到产业链的证据；若高标和核心一起缩量回吐，就是另一轮短周期轮动。</p></article>','<section><h3>下一次最重要的验证清单</h3><ol><li>设备核心至少3—5天能否在分歧日大快照/主力两口径同步承接，且收盘不再持续低于VWAP。</li><li>从3只高标扩展到主链+设备+逆变器，非ST行业上涨家数能否持续过半；MA45、MA120、MA200逐级修复，而非仅低位单周涨幅。</li><li>首轮分歧回踩是否缩量、前次放量平台是否守住；高标炸板与封板的质量要看真实封单和成交完整覆盖，不靠负方向净额猜。</li><li>新订单/验收回款、分部营收、扣非利润和经营现金流能否证明“增长”；低基数扭亏与大额非经常性损益必须剥离。</li></ol></section>','<h2 id="limits">10 / 数据边界、可复现文件与来源</h2>','<ul>'+''.join('<li>'+esc(x)+'</li>'for x in summary['gaps'])+'</ul>','<p>全池日线沿用本地前复权口径，未独立重建复权因子。均线按完整历史预热；展示起点2024-09-06。财务为本地东财业绩源的最新已公告2026三季报（截至11-06），没有把它当2024/2025涨停的当时原因。除闽发补充报道外，缺少扣非/分部订单明细的项目不填虚构数值。</p>','<p>来源：<a href="https://www.zhunshangshi.com/bk/1031.html">BK1031完整公开成分（69只）</a>；<a href="https://stock.eastmoney.com/hangye/hy1031.html">东财行业页</a>；<a href="https://www.nbd.com.cn/articles/2026-11-06/4641083.html">闽发风险公告报道（11-06盘后，新加坡时间）</a>；<a href="https://www.nbd.com.cn/articles/2026-11-06/4640298.html">11-06盘中快讯（不替代收盘）</a>；东财公开details/get及AkShare文档支持的details/sse、fflow/daykline；本地两年涨停档案、Fuyao一年龙虎榜、东财业绩CPD归档。链接仅供追溯，正文/图表可完全离线。</p>','<p>文件：summary.json、universe.csv、kline_stage.csv、tick_summary.csv、flow_summary.csv、lhb_summary.csv、lhb_events.csv、lhb_seats.csv、pv_limitup_events.csv、limitup_rank.csv、limitup_timeline.csv、historical_followthrough.csv、finance_background.csv、daily_audit.json与复现脚本。原始快照在ticks/；请求状态、覆盖比与失败清单均保留。preview.png为静态研究预览，不是浏览器截图。</p>','<div class="footer"><b>不构成投资建议</b></div></main>']
vue=pathlib.Path('/workspace/fuyao/gapup_after_wash_1106/interactive_qa/vue.global.prod.js').read_text();H+=['<script>'+vue+'</script>','<script id="pv-data" type="application/json">'+json.dumps(payload,ensure_ascii=False,separators=(',',':')).replace('</','<\\/')+'</script>','<script>const PV_DATA=JSON.parse(document.getElementById("pv-data").textContent);'+(O/'renderer.js').read_text()+(O/'app.js').read_text()+'</script></body></html>'];(O/'report.html').write_text(''.join(H))
# Visual summary preview; not a browser screenshot.
fig=plt.figure(figsize=(14,8.5),facecolor=BG);fig.text(.06,.91,'钱在打光伏，但尚未证实产业趋势反转',fontsize=24,color='white',weight='bold');fig.text(.06,.86,'截至 2026-11-06 收盘 · 新加坡时间 UTC+8 | 资金面优先',fontsize=12,color=FG);fig.text(.06,.78,f'行业60只 / 并集{C["union"]}只日K   ·   快照{TC["names"]}只 / {TC["stock_days"]}股日   ·   涨停{C["events"]}次',fontsize=14,color='#f3d45a');ax=fig.add_axes([.07,.28,.86,.43]);style(ax)
for code in ['002578','603381','301697','300751','688516','300274']:
 d=D[code];g=d[d.date>='2026-10-30'];ax.plot(range(len(g)),g.close/g.close.iloc[0]*100,label=N[code],lw=1.8)
ax.set_xticks(range(6));ax.set_xticklabels(['10-30','11-02','11-03','11-04','11-05','11-06']);ax.set_ylabel('10-30=100');ax.legend(ncol=3,facecolor=BG,labelcolor=FG,loc='upper left');fig.text(.07,.17,'高标：闽发5板 / 永臻4板 / 贝特利3板；核心设备、逆变器真反弹，但11-06明显分歧。',color=FG,fontsize=12);fig.text(.07,.12,'博弈：出清预期 + 技术切换可选性 + 辅材弹性；叠机器人 / 液冷 / 次新。',color=FG,fontsize=12);fig.text(.07,.07,'边界：快照主要为11-06，不冒充全池7日逐笔；未上龙虎榜不等于无机构。不构成投资建议。',color='#f3d45a',fontsize=11);fig.savefig(O/'preview.png',dpi=115,facecolor=BG);plt.close(fig)
# Bundle is small enough to relay even when HTML alone would be large.
files=['report.html','summary.json','universe.csv','kline_stage.csv','tick_summary.csv','flow_summary.csv','lhb_summary.csv','lhb_events.csv','lhb_seats.csv','pv_limitup_events.csv','limitup_rank.csv','limitup_timeline.csv','limitup_monthly.csv','historical_followthrough.csv','finance_background.csv','equipment_breadth.csv','preview.png','REPRODUCE.md','prepare_finance.py','scan.py','history.py','fetch_ticks.py','fetch_sse.py','fetch_flows.py','analyze_ticks.py','build_report.py','app.js','renderer.js','tick_coverage.json','daily_audit.json']
with zipfile.ZipFile(O/'report_bundle.zip','w',zipfile.ZIP_DEFLATED,compresslevel=7)as z:
 for f0 in files:z.write(O/f0,f0)
size=lambda p:round((O/p).stat().st_size/1024/1024,2)
hand=f'''# 光伏设备与历史涨停票资金博弈交接
观察截至：2026-11-06收盘；研究日2026-11-08，新加坡时间 UTC+8。
范围：行业全成分60（公开69去6北交所、3ST）；两年相关271；并集291。日K291全部代码扫描，当前有效行业58，其余TCL中环10-30/亚玛顿11-02。档案2024-09-06至2026-11-06，共1387次；过滤reason|industry而非concept/product，排半导体硅片非PV语境23次。

## 资金结论（8句）
1. 有钱真在打光伏，行业58只有效股近5根全部上涨，不只小票借壳。
2. 但只是反弹+预期交易，58只仅{int(cur.above200.sum())}只在MA200上，设备子组{len(ct)}只没有一只在MA200上。
3. 本周迈为+35.24%、奥特维+28.63%、捷佳+16.21%、阳光+25.55%，迈为并不安静；机构持续潜伏未获证实。
4. 11-05扩散14次涨停，11-06收窄至7次；高标闽发5板/永臻4板/贝特利3板，而有效行业仅{int((cur.pct>0).sum())}只当日上涨。
5. 阳光11-06≥100万快照方向净额{lf(today.loc['300274','net100_yi'])}亿，收低于VWAP2.50%；奥特维/捷佳有大快照承接但价格下跌，是双向换手。
6. 当前PV范围本周单日龙虎榜游资{lf(hot)}亿、机构{lf(org)}亿；多日榜不叠加，闽发11-06三日机构净卖0.60亿，金刚游资远高于机构。
7. 博弈出清/反内卷底部修复、新技术未来可选性、辅材弹性，叠机器人/液冷/算力/次新/字辈；未确认订单复苏、普遍涨价或出口增速再起。
8. 明确不能说“全池近7日tick全看完”：只有最近一日为主，历史补充仅钧达5股日，故不从单日资金推连续建仓。

## tick与其他证据覆盖
快照{TC['names']}只、{TC['stock_days']}股日、{TC['records']:,}条，行业{TC['equipment_names']}/60；东财details/get、文档支持的SSE公共备用，约3秒快照而非逐笔委托，另复用钧达source=em历史。最近快照主要11-06，10-29/30、11-02/03/04仅钧达，11-03午后缺失；10-28此前不用于当前结论。迈为tick多次HTTP502，仅分钟价格+日资金流；完整失败名单在report与coverage。东财日主力流量实际{F.code.nunique()}只，只有11-06，未伪称20日。
龙虎榜：一年并集单日{len(yearone)}条/{yearone.ticker.nunique()}只，识别游资{lf(yearone.hot_money_net_value.sum(min_count=1)/1e8)}亿、机构{lf(yearone.org_net_value.sum(min_count=1)/1e8)}亿；历史池非当期PV归因，本周另收窄范围。当前PV范围单日{len(one)}条/{one.ticker.nunique()}只。机构专用不等公募长线，未上榜不等无机构。

真设备：迈为/捷佳/奥特维/金辰/高测/晶盛/帝尔/拉普拉斯；真主链：隆基/通威/晶科/晶澳/天合/爱旭/弘元/协鑫等；真辅材：福斯特/聚和/帝科/永臻/贝特利/清源/安彩/欧晶/亚玛顿；逆变器：阳光/德业/锦浪/固德威/艾罗。闽发有真PV但仅17.45%收入、利润贡献低；永臻真边框叠机器人/铝箔，贝特利真浆料叠次新/电子皮肤；金刚HJT叠GPU，双良光伏叠液冷。太阳能/立新能源是运营不是制造设备；日出东方/东方新能含字辈，狮头/东南网架更偏嫁接，不作设备景气锚。

## 路径与交付
根目录：{O}
report.html：{size('report.html')} MiB，所有291只可切换Vue3+Canvas，拖动/滚轮/复位，含6张关键日K+快照图，无ECharts，无联网脚本。
report_bundle.zip：{size('report_bundle.zip')} MiB（推荐发此压缩包，解压打开report.html）。
summary.json、universe.csv、kline_stage.csv、tick_summary.csv、flow_summary.csv、lhb_summary.csv、lhb_events.csv、lhb_seats.csv、pv_limitup_events.csv、history_summary.json、preview.png（研究静态预览非浏览器截图）、复现脚本齐全。所有原始快照另存ticks/，不打包海量原始数据。
重要缺口：指定Fuyao密钥路径不存在，未绕找凭据；历史tick接口503；近7日逐笔无法补齐；东财5日分时实际只给11-06。无全池融资变化、真实封单队列、持仓、独立最新订单/辅材报价。
不构成投资建议
''';(O/'handoff.md').write_text(hand)
print(json.dumps({'html_mib':size('report.html'),'zip_mib':size('report_bundle.zip'),'deep_notes':len(notes),'stocks':len(stocks),'current_pv_lhb_hot_yi':hot,'org_yi':org,'tick':TC},ensure_ascii=False))
