from pathlib import Path
import json,sys,hashlib,collections
import pandas as pd,numpy as np
O=Path('/workspace/fuyao/ma_coil_600821_1108');j=json.loads((O/'report_data.json').read_text());E=j['entries'];S=j['summary'];errors=[]
assert len([e for e in E if e['kind']=='当前'])==S['scan']['current_stocks']
assert len([e for e in E if e['kind']=='历史'])==S['scan']['historical_events']
for e in E:
 assert e['kline'] and all(k in e['writeup']for k in ['技术形态','题材','业绩','增长'])
 assert 'ST'not in e['name'].upper()and'退'not in e['name']
 assert e['code'].startswith(('sh60','sh68','sz00','sz30'))
 if e['kind']=='当前':assert e['date']=='2026-11-06'and e['spread']<=.14 and e['peak180']<=.5 and e['bias180']<=.18
 if e['kind']=='历史':assert e['mfe40']>=.6 and e['mfe20']>=.35 and e['peak_volratio']>=2 and e['prepeak_mae']>=-.15 and e['peak_days']<=40
 if e['tier']=='更贴':assert e['med180']<=.055 and e['tight180']>=.8 and e['range180']<=.3 and abs(e['slope60'])<=.05 and e['spread']<=.1 and abs(e['dip_bias'])<=.035 and e['dip_pull']<=-.045
 if e['tier']=='次贴':assert e['med120']<=.065 and e['tight120']>=.7 and e['range120']<=.35 and abs(e['slope60'])<=.07 and e['spread']<=.12 and abs(e['dip_bias'])<=.05 and e['dip_pull']<=-.035
 # Check MA180 against source full-series average, not truncated display.
 d=pd.read_csv('/workspace/fuyao/market_daily/'+e['code']+'.csv');ix=d.index[d.date==e['date']][0];avg=d.close.iloc[ix-179:ix+1].mean();bar=next(b for b in e['kline']if b['date']==e['date']);assert abs(avg-bar['ma180'])<.00011
html=(O/'report.html').read_text();assert 'function drawKline' in html and 'vue' in html.lower() and 'cdn.jsdelivr.net'not in html and 'echarts.min.js'not in html.lower();assert html.rfind('不构成投资建议')>0
result={'data_assertions':'passed','entries':len(E),'current':S['scan']['current_stocks'],'historical':S['scan']['historical_events'],'detailed_four_dimensions':sum(e['tier']in ['更贴','次贴']for e in E),'all_entry_MA180_recomputed':'passed','current_high_level_exclusion':'passed','source_csv_modified':False,'template_image_read':True,'self_contained_vue_and_image':True,'renderer_source':'/workspace/fuyao/gapup_after_wash_1106/kline-vue-demo.html drawKline adapted','html_bytes':len(html.encode()),'html_sha256':hashlib.sha256(html.encode()).hexdigest(),'errors':errors}
(O/'validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(json.dumps(result,ensure_ascii=False,indent=2))
