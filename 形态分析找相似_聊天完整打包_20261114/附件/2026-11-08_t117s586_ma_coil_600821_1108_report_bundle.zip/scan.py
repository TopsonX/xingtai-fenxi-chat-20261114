from pathlib import Path
import pandas as pd,numpy as np,json,re,collections,multiprocessing as mp,time
O=Path('/workspace/fuyao/ma_coil_600821_1108');D=O.parent/'market_daily';ASOF='2026-11-06';W=[5,10,20,45,60,180]
q=json.load(open('/workspace/fuyao/summary_1104/qt_all.json'));names={k:v[1] for k,v in q.items() if isinstance(v,list) and len(v)>1}
try:
 for r in pd.read_parquet('/workspace/fuyao/summary_1104/ranked.parquet')[['code','name']].to_dict('records'):names.setdefault(r['code'],r['name'])
except:pass
def prep(p):
 d=pd.read_csv(p).sort_values('date').drop_duplicates('date',keep='last');d=d[d.date<=ASOF].copy()
 for k in ['open','high','low','close','vol']:d[k]=pd.to_numeric(d[k],errors='coerce')
 bad=d[['open','high','low','close','vol']].isna().any(axis=1)|(d.low<=0)|(d.high<d.low)|(d.vol<=0)|(d.high<d[['open','close']].max(axis=1))|(d.low>d[['open','close']].min(axis=1))
 # Preserve row chronology: invalid price bars contaminate rolling windows as NaN.
 d.loc[bad,['open','high','low','close','vol']]=np.nan;d=d.reset_index(drop=True)
 for w in W:d['ma'+str(w)]=d.close.rolling(w).mean()
 ma=d[['ma'+str(w) for w in W]];d['spread']=ma.max(axis=1)/ma.min(axis=1)-1;d.loc[d.ma180.isna(),'spread']=np.nan
 d['med120']=d.spread.rolling(120).median();d['tight120']=(d.spread<=.08).astype(float).rolling(120).mean();d['range120']=d.high.rolling(120).max()/d.low.rolling(120).min()-1
 d['slope60']=d.ma180/d.ma180.shift(60)-1;d['ret20']=d.close/d.close.shift(20)-1;d['ret60']=d.close/d.close.shift(60)-1
 d['peak180']=d.high.rolling(180).max()/d.ma180-1
 d['vol20']=d.vol.rolling(20).mean();d['vol120']=d.vol.rolling(120).mean();d['valid300']=d.close.rolling(300).count()==300
 d['priorhigh20']=d.high.rolling(20).max().shift(1)
 d['med180']=d.spread.rolling(180).median();d['tight180']=(d.spread<=.08).astype(float).rolling(180).mean();d['range180']=d.high.rolling(180).max()/d.low.rolling(180).min()-1
 return d,int(bad.sum())
def features(d,t):
 r=d.iloc[t];z=d.iloc[max(0,t-14):t+1];u=z.low/z.ma180-1
 pulls=z.low/d.priorhigh20.loc[z.index]-1;eligible=u[(pulls<=-.035)&(u.abs()<=.06)]
 ix=(eligible.abs()).idxmin() if len(eligible) else (u.abs()).idxmin();a=d.loc[ix];dip=float(a.low/a.ma180-1)
 prev=d.iloc[max(0,ix-20):ix];pull=float(a.low/prev.high.max()-1) if len(prev) else 0
 return {'date':r.date,'t':int(t),'close':float(r.close),'spread':float(r.spread),'med120':float(r.med120),'tight120':float(r.tight120),'range120':float(r.range120),'slope60':float(r.slope60),'ret20':float(r.ret20),'ret60':float(r.ret60),'bias180':float(r.close/r.ma180-1),'peak180':float(r.peak180),'volratio':float(r.vol20/r.vol120),'dip_date':a.date,'dip_bias':dip,'dip_pull':pull,'dip_age':int(t-ix),'med180':float(r.med180),'tight180':float(r.tight180),'range180':float(r.range180),'ma180':float(r.ma180),'boxhigh':float(d.high.iloc[t-119:t+1].max()),'boxlow':float(d.low.iloc[t-119:t+1].min())}
def tier(f,hist=False):
 dip=abs(f['dip_bias'])<=.035 and f['dip_pull']<=-.045
 if f['med180']<=.055 and f['tight180']>=.80 and f['range180']<=.30 and abs(f['slope60'])<=.05 and f['spread']<=.10 and dip:return '更贴'
 if f['med120']<=.065 and f['tight120']>=.70 and f['range120']<=.35 and abs(f['slope60'])<=.07 and f['spread']<=.12 and abs(f['dip_bias'])<=.05 and f['dip_pull']<=-.035:return '次贴'
 return '观察'
def run(p):
 code=p.stem;name=names.get(code,'');out={'code':code,'name':name,'events':[]}
 if not name or 'ST' in name.upper() or '退' in name:out['excluded']='unknown_name' if not name else 'ST_delisting';return out
 try:
  d,bad=prep(p);out.update(bars=len(d),bad_bars=bad,last=d.date.iloc[-1] if len(d) else None,first=d.date.iloc[0] if len(d) else None)
  if len(d)<300:return out
  # All entry features use only data <= t. Exclude high-level post-spike retracement.
  base=(d.med120<=.075)&(d.tight120>=.60)&(d.range120<=.40)&(d.slope60.abs()<=.08)&(d.spread<=.14)&(d.ret20<=.15)&(d.ret60<=.25)&(d.close/d.ma180>=.92)&(d.close/d.ma180<=1.18)&(d.peak180<=.50)&d.valid300
  if out['last']==ASOF and base.iloc[-1]:
   f=features(d,len(d)-1);f.update(code=code,name=name,tier=tier(f));out['current']=f
  ids=np.flatnonzero(base.to_numpy());last_event=-100
  for t in ids:
   if t+40>=len(d) or t<=last_event+40:continue
   f=features(d,int(t))
   if abs(f['dip_bias'])>.06 or f['dip_pull']>-.035:continue
   future=d.iloc[t+1:t+41];pk=future.high.idxmax();mfe=float(d.high.iloc[pk]/d.close.iloc[t]-1);m20=float(d.high.iloc[t+1:t+21].max()/d.close.iloc[t]-1)
   # Completed vertical-rise analog: >=60% within40, >=35% within20, peak avg volume >=2x preceding20.
   vr=float(d.vol.iloc[max(t+1,pk-4):pk+1].mean()/d.vol20.iloc[t]);mae=float(d.low.iloc[t+1:pk+1].min()/d.close.iloc[t]-1)
   if mfe<.60 or m20<.35 or vr<2 or mae<-.15:continue
   f.update(code=code,name=name,tier=tier(f,True),peak_date=d.date.iloc[pk],peak=float(d.high.iloc[pk]),mfe40=mfe,mfe20=m20,peak_days=int(pk-t),peak_volratio=vr,prepeak_mae=mae,ret40=float(d.close.iloc[t+40]/d.close.iloc[t]-1));out['events'].append(f);last_event=int(t)
 except Exception as e:out['error']=repr(e)
 return out
if __name__=='__main__':
 files=sorted(p for p in D.glob('*.csv') if re.match(r'^(sh(?:60|68)|sz(?:00|30))\d{4}\.csv$',p.name));start=time.time()
 with mp.Pool(8) as pool:res=pool.map(run,files,chunksize=15)
 events=[e for r in res for e in r['events']];current=[r['current'] for r in res if 'current'in r]
 for a in [events,current]:
  for f in a:f['score']=round(100-200*f['med120']-60*f['range120']-80*abs(f['slope60'])-100*abs(f['dip_bias'])+10*f['tight120'],2)
  a.sort(key=lambda f:({'更贴':0,'次贴':1,'观察':2}[f['tier']],-f['score']))
 def clean(x):
  if isinstance(x,dict):return {k:clean(v) for k,v in x.items()}
  if isinstance(x,list):return [clean(v) for v in x]
  if isinstance(x,float) and not np.isfinite(x):return None
  return x
 pd.DataFrame(events).to_csv(O/'historical_events.csv',index=False);pd.DataFrame(current).to_csv(O/'current_candidates.csv',index=False)
 log={'asof':ASOF,'library_files':len(list(D.glob('*.csv'))),'sh_sz_files':len(files),'eligible_named_nonST':sum(not r.get('excluded') for r in res),'excluded':dict(collections.Counter(r.get('excluded') for r in res if r.get('excluded'))),'other_market_files':len(list(D.glob('*.csv')))-len(files),'bars_scanned':sum(r.get('bars',0) for r in res),'invalid_bars':sum(r.get('bad_bars',0) for r in res),'short_lt300':sum(r.get('bars',300)<300 for r in res),'stale':[{'code':r['code'],'name':r['name'],'last':r['last']} for r in res if r.get('last') and r['last']!=ASOF],'errors':[r for r in res if r.get('error')],'date_start':min(r['first'] for r in res if r.get('first')),'historical_events':len(events),'historical_stocks':len(set(f['code']for f in events)),'historical_tiers':dict(collections.Counter(f['tier']for f in events)),'current_stocks':len(current),'current_tiers':dict(collections.Counter(f['tier']for f in current)),'runtime_sec':round(time.time()-start,2)}
 (O/'scan_results.json').write_text(json.dumps(clean({'log':log,'current':current,'events':events}),ensure_ascii=False,indent=2,allow_nan=False));print(json.dumps(log,ensure_ascii=False,indent=2));print('CURRENT TOP',[(f['code'],f['name'],f['tier'],f['score'])for f in current[:25]]);print('HIST TOP',[(f['code'],f['name'],f['tier'],f['date'],f['mfe40'])for f in events[:25]])
