from pathlib import Path
import json,sys,html,collections,shutil
import pandas as pd,numpy as np
O=Path('/workspace/fuyao/ma_coil_600821_1108');sys.path.insert(0,str(O));import scan
J=json.loads((O/'scan_results.json').read_text());T=json.loads((O/'template.json').read_text())
# Long-stale/terminated listings are excluded conservatively; do not turn stale data into current candidates.
excluded={r['code'] for r in J['log']['stale'] if r['last']<'2026-09-01' or not (scan.q.get(r['code'],['']*61)+['']*61)[60].strip()}
J['events']=[f for f in J['events'] if f['code']not in excluded]
# Recheck actual benchmark sessions rather than mistaking holiday breaks for halts.
calendar=pd.read_csv(scan.D/'sh601398.csv').date.tolist();calpos={dt:i for i,dt in enumerate(calendar)}
continuity_removed={'current':[],'events':[]}
for group in ['current','events']:
 keep=[]
 for f in J[group]:
  dates=pd.read_csv(scan.D/(f['code']+'.csv'),usecols=['date']).date.tolist();t=dates.index(f['date']);end=t if group=='current' else dates.index(f['peak_date']);window=dates[max(0,t-20):end+1];idx=[calpos[x] for x in window if x in calpos]
  if any(b-a>4 for a,b in zip(idx,idx[1:])):continuity_removed[group].append({'code':f['code'],'date':f['date'],'reason':'价格序列相邻记录间缺失超过3个基准交易日，保守剔除'})
  else:keep.append(f)
 J[group]=keep
(O/'continuity_exclusions.json').write_text(json.dumps(continuity_removed,ensure_ascii=False,indent=2))
L=J['log'];L['continuity_exclusions']={k:len(v) for k,v in continuity_removed.items()};L['current_stocks']=len(J['current']);L['excluded']['long_stale_or_delisted']=len(excluded);L['eligible_named_nonST']-=len(excluded)
L.update(historical_events=len(J['events']),historical_stocks=len({f['code']for f in J['events']}),historical_tiers=dict(collections.Counter(f['tier']for f in J['events'])))
L['current_tiers']=dict(collections.Counter(f['tier']for f in J['current']))
def pct(x):return '未披露'if x is None else f'{x*100:.2f}%'
def money(x):return '未披露'if x is None else f'{x/1e8:.2f}亿元'
def yoy(x):return '未披露'if x is None else f'{x:+.2f}%'
def source(code):
 p=O/'sources'/(code+'.json');return json.loads(p.read_text()) if p.exists()else{}
def writeup(f,kind):
 s=source(f['code']);fd=((s.get('finance',{}).get('result')or{}).get('data')or[]);td=((s.get('theme',{}).get('result')or{}).get('data')or[])
 fd=[a for a in fd if (a.get('NOTICE_DATE')or'9999')[:10]<='2026-11-06'];a=fd[0]if fd else{}
 main=next((a['MAINPOINT_CONTENT']for a in td if a['KEY_CLASSIF']=='主营业务'),'本次公开源未返回主营业务，暂不认定具体题材。')
 boards=next((a['MAINPOINT_CONTENT']for a in td if a['KEY_CLASSIF']=='所属板块'),'未返回板块标签')
 # Board labels and business descriptions are evidence, not a claim of catalyst/revenue exposure.
 theme=main[:310]+('…'if len(main)>310 else'')+' 板块标签（不等于订单或业绩）：'+boards[:180]
 if a:
  earn=f"2026年前三季度（累计，非单季）：营业收入{money(a.get('TOTAL_OPERATE_INCOME'))}；归母净利润{money(a.get('PARENT_NETPROFIT'))}；公告日期{str(a.get('NOTICE_DATE',''))[:10]}。"
  g=f"收入同比{yoy(a.get('YSTZ'))}，归母净利润同比{yoy(a.get('SJLTZ'))}。"
  rev=a.get('YSTZ');profit=a.get('SJLTZ');net=a.get('PARENT_NETPROFIT')
  g+=('营收与利润均增长，但不能由此推出后续持续增长。'if rev is not None and profit is not None and rev>0 and profit>0 and net and net>0 else '不作“双增”认定；需区分利润基数、非经常损益和持续经营改善。')
  if net is not None and net<0:g+='归母仍亏损，不能把同比变动直接当作盈利增长。'
 else:earn='本次公开接口未返回截至2026-11-06已公告的2026年前三季度可用数值；不补写营收、净利润。';g='缺乏可用同口径业绩数据，增长证据不足，不给盈利增长结论。'
 if kind=='历史':earn+=' 此处仅为截至研究时点的财务背景，不是该历史事件当时已知信息，也不解释当年涨因。'
 tech=f"{f['date']}：六线离散{pct(f['spread'])}，近120日离散中位{pct(f['med120'])}、≤8%占比{pct(f['tight120'])}，箱体幅度{pct(f['range120'])}；MA180近60日变化{pct(f['slope60'])}。{f['dip_date']}回踩距MA180 {pct(f['dip_bias'])}，相对前20日高点回落{pct(f['dip_pull'])}；当前价距MA180 {pct(f['bias180'])}。"
 if kind=='历史':tech+=f"后验峰值{f['peak_date']} {f['peak']:.3f}，{f['peak_days']}交易日内最大上探{pct(f['mfe40'])}；这不是可实现收益率，亦不代表今天处在同一阶段。"
 else:tech+='未确认起爆；当前只认定压缩/回踩候选。放量收越箱顶并回踩不破才增加确认；放量跌破回踩低点或MA180且不能收回则形态失效。'
 return {'技术形态':tech,'题材':theme,'业绩':earn,'增长':g,'finance_url':s.get('finance_url',''),'theme_url':s.get('theme_url',''),'finance_available':bool(a)}
entries=[];cache={}
def add(f,kind):
 f=dict(f);f['kind']=kind;f['id']=kind+':'+f['code']+':'+f['date'];f['writeup']=writeup(f,kind)
 code=f['code']
 if code not in cache:cache[code]=scan.prep(scan.D/(code+'.csv'))[0]
 d=cache[code];t=int(d.index[d.date==f['date']][0]);end=len(d) if kind=='当前' else min(len(d),t+101);start=max(0,t-420)
 z=d.iloc[start:end].copy().rename(columns={'open':'o','high':'h','low':'l','close':'c','vol':'v','vol20':'vma20'})
 f['kline']=json.loads(z[['date','o','h','l','c','v','ma5','ma10','ma20','ma45','ma60','ma180','vma20']].to_json(orient='records',double_precision=4))
 f['gaps']=[];f['washes']=[];f['title']=kind+' · '+f['tier'];f['anchorIndex']=t-start
 f['defaultStart']=max(0,f['anchorIndex']-210);f['defaultCount']=min(280,len(z)-f['defaultStart'])
 f['markers']=[{'date':f['date'],'price':f['close'],'text':'筛选锚点 '+f['date'],'color':'#f5c542'},{'date':f['dip_date'],'price':float(d.loc[d.date==f['dip_date'],'low'].iloc[0]),'text':'回踩MA180 '+f['dip_date'],'color':'#4aa3ff'}]
 if kind=='历史':f['markers'].append({'date':f['peak_date'],'price':f['peak'],'text':'后验峰值 '+f['peak_date'],'color':'#ff6b6b'})
 if kind=='当前':
  r=d.iloc[t];f['stage']='粘合待确认'
  if r.close>=r.ma20 and f['dip_pull']<=-.035:f['stage']='回踩后收回·待突破'
  if r.close>=.97*f['boxhigh'] and f['volratio']>=1.3 and f['ret20']>0:f['stage']='近箱顶蓄势·未确认启动'
 else:f['stage']='已走出·仅供历史形态对照'
 entries.append(f)
for f in J['current']:add(f,'当前')
for f in J['events']:add(f,'历史')
f={**T['dip_anchor'],'code':'sh600821','name':'金开新能','tier':'更贴','score':100,'peak_date':'2026-03-20','peak':12.2,'mfe40':T['peak_vs_dip_close'],'peak_days':24};add(f,'模板');entries[-1]['title']='用户模板 · 最后一跌到加速';entries[-1]['markers'].append({'date':'2026-03-20','price':12.2,'text':'模板峰值 12.20','color':'#ff6b6b'})
thresholds={
 '均线':'MA5/10/20/45/60/180，日收盘简单均线，全序列计算后切窗',
 '离散':'max(MA)/min(MA)-1，箱体幅度=窗口最高价/最低价-1',
 '连续性':'当前最近20根、历史锚点前20根至峰值，按工商银行交易日历核查；相邻价格记录缺失超过3个市场交易日则保守剔除，不把复牌大跳变当自然启动',
 '共同入口':'近120日离散中位≤7.5%，离散≤8%日占比≥60%，120日箱体幅度≤40%，MA180近60日变化绝对值≤8%，当日六线离散≤14%；近20/60日涨幅≤15%/25%，收盘/MA180处于0.92~1.18；近180日最高/当前MA180≤1.50；最近300根均有效',
 '更贴':'近180日离散中位≤5.5%，≤8%占比≥80%，180日箱体幅度≤30%，MA180近60日变化绝对值≤5%，当日离散≤10%；近15日内存在相对前20日高点回落≥4.5%、低点距当日MA180绝对偏离≤3.5%的回踩',
 '次贴':'不满足更贴但近120日离散中位≤6.5%，≤8%占比≥70%，箱体幅度≤35%，MA180近60日变化绝对值≤7%，当日离散≤12%；近15日回踩偏离≤5%、回落≥3.5%',
 '观察':'仅过共同入口，未达更贴/次贴；可能缺最后一跌、压缩较松或周期较短',
 '历史后验':'40交易日内最高价相对锚点收盘≥60%，20日内最高价≥35%；峰值前最多5根均量/锚点20日均量≥2；锚点后至峰值最大下探不低于-15%；必须具备完整40根后续日线。按时间先后取首个合格锚点，同股40交易日冷却。不是预测模型或回测胜率。',
 '评分':'100−200×120日离散中位−60×120日箱体幅度−80×|MA180斜率|−100×|回踩偏离|+10×紧密占比；仅在同一层内排序，不是上涨概率。'}
empty=[f'{kind}·{tier}为空；不强行补位'for kind,key in [('当前','current_tiers'),('历史','historical_tiers')]for tier in ['更贴','次贴','观察']if not L[key].get(tier)]
finance_counts={kind:sum(e['writeup']['finance_available']for e in entries if e['kind']==kind and e['tier']in ['更贴','次贴'])for kind in ['当前','历史']}
summary={'report':str(O/'report.html'),'handoff':str(O/'handoff.md'),'scan':L,'template':T,'thresholds':thresholds,'empty_tier_notes':empty or ['当前及历史三层均有样本；没有为填层而调阈值。'],'finance_available_detailed_writeups':finance_counts,'details_count':sum(e['tier']in ['更贴','次贴']for e in entries),'sources_date':'2026-11-08 Asia/Singapore (UTC+8)','caveats':['历史成功事件为后验条件筛选，不能计算预测成功率','当前候选只是长期粘合/近MA180回踩，不等于即将暴涨','仅使用现有日线库，未刷新；价格沿用本地复权口径，未独立重建复权因子','按研究时点名称剔除ST及退市，无法完整恢复历史ST时点标签；长期停更或停更且本地报价失效票保守剔除','财务为2026年前三季度已公告数；不作为历史事件时点因果证据','北交所不纳入；本库未发现bj文件','低点接近MA180不是支撑必然有效；峰值涨幅不等于实际收益']}
(O/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2));(O/'report_data.json').write_text(json.dumps({'summary':summary,'entries':entries},ensure_ascii=False,separators=(',',':'),allow_nan=False))
# Explicit renderer reuse, not an ECharts replacement.
src=Path('/workspace/fuyao/gapup_after_wash_1106/kline-vue-demo.html').read_text();js=src[src.index('    const UP ='):src.index('    createApp({')]
js=js.replace('function drawKline(canvas, stock, hover)','function drawKline(canvas, stock, hover, view, mouseY)')
js=js.replace('const bars = stock.kline','const bars = stock.kline.slice(view.start,view.start+view.count)',1)
js=js.replace("const MA = { ma7: '#f5c542', ma45: '#4aa3ff', ma120: '#c77dff', ma200: '#bfbfbf' }","const MA = {ma5:'#eee',ma10:'#fc82cb',ma20:'#b783ff',ma45:'#4aa3ff',ma60:'#ff9246',ma180:'#f5c542'}")
js=js.replace("['ma7', 'ma45', 'ma120', 'ma200']","Object.keys(MA)")
js=js.replace('for (const b of bars) {','for (const b of bars) { if(b.l==null||b.h==null)continue;',1)
js=js.replace('const b = bars[i]\n        const color', 'const b = bars[i]\n        if(b.l==null||b.h==null)continue\n        const color')
js=js.replace('const ypad = (ymax - ymin) * 0.06','const ypad = Math.max(ymax-ymin,ymax*.01)*.06').replace('vmax *= 1.08','vmax = Math.max(1,vmax*1.08)')
js=js.replace("const legend = [['MA7', MA.ma7], ['MA45', MA.ma45], ['MA120', MA.ma120], ['MA200', MA.ma200]]","const legend=Object.entries(MA).map(([k,v])=>[k.toUpperCase(),v])").replace('const lw = 186','const lw = 395').replace('lx += 46','lx += 65')
js=js.replace("ctx.fillText(stock.name + ' ' + stock.code + '  ｜  ' + stock.title, px, py - 12)","ctx.fillText(stock.name+' '+stock.code+' ｜ '+bars[0].date+' — '+bars[n-1].date,px,py-12)")
js=js.replace("ctx.fillText(t >= 100 ? t.toFixed(0) : t.toFixed(1), px - 8, yP(t))","ctx.fillText(t.toFixed(2), px-8, yP(t))")
js=js.replace('ctx.setLineDash([])\n      }',"if(mouseY>=py&&mouseY<=py+ph){ctx.moveTo(px,mouseY);ctx.lineTo(px+pw,mouseY);ctx.stroke()}\n        ctx.setLineDash([])\n      }",1)
marker='''
      for(const [mi,m]of(stock.markers||[]).entries()){
        const i=idxOf(bars,m.date);if(i<0)continue;const x=xAt(i),y=yP(m.price);ctx.strokeStyle=m.color;ctx.setLineDash([3,4]);ctx.beginPath();ctx.moveTo(x,py+35);ctx.lineTo(x,py+ph);ctx.stroke();ctx.setLineDash([]);ctx.fillStyle=m.color;ctx.font='11px sans-serif';ctx.textAlign='left';const tx=Math.max(px+8,Math.min(x+8,px+pw-200));ctx.fillText(m.text,tx,py+50+mi*18);ctx.beginPath();ctx.arc(x,y,4,0,Math.PI*2);ctx.fill();
      }
'''
js=js.replace("      ctx.save()\n      ctx.beginPath()\n      ctx.rect(vx",marker+"      ctx.save()\n      ctx.beginPath()\n      ctx.rect(vx",1)
(O/'renderer.js').write_text(js)
vue=Path('/workspace/fuyao/gapup_after_wash_1106/interactive_qa/vue.global.prod.js').read_text();payload=(O/'report_data.json').read_text().replace('</','<\\/')
shell=(O/'shell.html').read_text();out=shell.replace('/*__VUE__*/',vue).replace('/*__DATA__*/',payload).replace('/*__RENDERER__*/',js);out=out.replace('src="user_chart_600821.png"','src="data:image/png;base64,'+__import__('base64').b64encode((O/'user_chart_600821.png').read_bytes()).decode()+'"');(O/'report.html').write_text(out)
# All quantitative results downloadable as transparent tables; no hidden top-N truncation.
pd.DataFrame(J['events']).to_csv(O/'historical_events.csv',index=False);pd.DataFrame(J['current']).to_csv(O/'current_candidates.csv',index=False)
(O/'handoff.md').write_text('# 金开新能均线粘合全库筛选交接\n\n报告：'+str(O/'report.html')+'\n\n'+json.dumps(L,ensure_ascii=False,indent=2)+'\n\n## 阈值\n'+''.join(f'- **{k}**：{v}\n'for k,v in thresholds.items())+'\n## 模板\n'+json.dumps(T,ensure_ascii=False,indent=2)+'\n\n## 空层\n'+'\n'.join(summary['empty_tier_notes'])+'\n\n## 交付\nreport.html为离线Vue3+Canvas单文件；drawKline明确复用gapup demo，支持拖动、滚轮、双击复位、搜索/层级/当前历史切换。report_data.json保留全部命中数据；两份CSV保留全部历史事件及当前候选；sources/保留公开财务与题材JSON及URL。\n\n## 限制\n'+'\n'.join('- '+x for x in summary['caveats'])+'\n\n不构成投资建议。\n')
print(json.dumps({'log':L,'finance':finance_counts,'entries':len(entries),'html_bytes':(O/'report.html').stat().st_size,'empty':empty},ensure_ascii=False,indent=2))
