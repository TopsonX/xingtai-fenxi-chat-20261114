import json,requests,concurrent.futures as cf
from pathlib import Path
O=Path('/workspace/fuyao/ma_coil_600821_1108');S=O/'sources';S.mkdir(exist_ok=True)
j=json.loads((O/'scan_results.json').read_text());codes=sorted(set(f['code']for f in j['current']+j['events'] if f['tier']in ['更贴','次贴'])|{'sh600821'})
U='https://datacenter-web.eastmoney.com/api/data/v1/get';U2='https://datacenter.eastmoney.com/securities/api/data/v1/get'
def fetch(code):
 p=S/(code+'.json')
 if p.exists():return
 out={'code':code,'fetched_at':'2026-11-08 Asia/Singapore (UTC+8)'}
 par={'reportName':'RPT_LICO_FN_CPD','columns':'SECURITY_CODE,SECURITY_NAME_ABBR,REPORTDATE,NOTICE_DATE,TOTAL_OPERATE_INCOME,YSTZ,PARENT_NETPROFIT,SJLTZ,BASIC_EPS,WEIGHTAVG_ROE,MGJYXJJE,PUBLISHNAME','filter':f'(SECURITY_CODE="{code[2:]}")(REPORTDATE=\'2026-09-30\')','pageSize':5}
 try:
  r=requests.get(U,params=par,timeout=20);out['finance']=r.json();out['finance_url']=r.url
 except Exception as e:out['finance_error']=str(e)
 sec=code[2:]+('.SH'if code.startswith('sh')else'.SZ');par={'reportName':'RPT_F10_CORETHEME_CONTENT','columns':'SECUCODE,KEY_CLASSIF,KEYWORD,MAINPOINT_CONTENT','filter':f'(SECUCODE="{sec}")','pageSize':40}
 try:
  r=requests.get(U2,params=par,timeout=20);out['theme']=r.json();out['theme_url']=r.url
 except Exception as e:out['theme_error']=str(e)
 p.write_text(json.dumps(out,ensure_ascii=False,indent=1))
with cf.ThreadPoolExecutor(12) as ex:list(ex.map(fetch,codes))
print('codes',len(codes),'finance_ok',sum(bool((json.loads((S/(c+'.json')).read_text()).get('finance',{}).get('result')or{}).get('data'))for c in codes))
