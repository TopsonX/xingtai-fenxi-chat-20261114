from playwright.sync_api import sync_playwright
from pathlib import Path
import json
O=Path('/workspace/fuyao/ma_coil_600821_1108')
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/google-chrome',headless=True,args=['--no-sandbox'])
 page=b.new_page(viewport={'width':1500,'height':1050},device_scale_factor=1);errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 page.goto((O/'report.html').as_uri(),wait_until='load');page.wait_for_function('window.__coilQA && document.querySelector("canvas").width>0')
 first=page.evaluate('({code:__coilQA.stock().code,start:__coilQA.view.start,count:__coilQA.view.count})');cv=page.locator('canvas');cv.scroll_into_view_if_needed();r=cv.bounding_box();x=r['x']+r['width']*.5;y=r['y']+r['height']*.4
 page.screenshot(path=str(O/'preview.png'),full_page=True)
 page.mouse.move(x,y);page.mouse.down();page.mouse.move(x+180,y,steps=15);page.mouse.up();page.wait_for_timeout(100);drag=page.evaluate('({...__coilQA.view})');assert drag['start']<first['start'],(drag,first)
 page.mouse.move(x,y);page.mouse.wheel(0,-300);page.wait_for_timeout(100);zoom=page.evaluate('({...__coilQA.view})');assert zoom['count']<drag['count']
 page.mouse.dblclick(x,y);page.wait_for_timeout(100);reset=page.evaluate('({...__coilQA.view})');assert reset['start']==first['start']and reset['count']==first['count']
 page.mouse.move(x,y);page.wait_for_timeout(50);assert '开 'in page.locator('.status').inner_text()
 page.get_by_role('button',name='历史',exact=True).click();page.wait_for_timeout(80);assert page.evaluate('__coilQA.stock().kind')=='历史'
 page.get_by_role('button',name='模板',exact=True).click();page.wait_for_timeout(80);assert page.evaluate('__coilQA.stock().code')=='sh600821'
 page.screenshot(path=str(O/'template_kline.png'),full_page=True)
 # Render representative histories at both ends and all tiers; payload data checked separately for every entry.
 ids=page.evaluate('(()=>{let e=__coilQA.entries;return [...new Set([e[0].id,e[e.length-1].id,...e.filter((s,i)=>i%25===0).map(s=>s.id)])]})()')
 for id in ids:
  page.evaluate('(id)=>__coilQA.select(id)',id);page.wait_for_timeout(15)
 page.get_by_role('button',name='当前',exact=True).click();page.locator('input[placeholder="搜索代码 / 名称"]').fill('601128');page.wait_for_timeout(80);assert '常熟银行'in page.locator('.list').inner_text()
 page.locator('input[placeholder="搜索代码 / 名称"]').fill('zzzz-empty');page.wait_for_timeout(50);assert '本层为空'in page.locator('.list').inner_text();page.locator('input[placeholder="搜索代码 / 名称"]').fill('')
 page.set_viewport_size({'width':480,'height':1000});page.wait_for_timeout(100);page.screenshot(path=str(O/'mobile.png'),full_page=True)
 assert not errors,errors
 result={'offline_load':'passed','drag':'passed','zoom':'passed','doubleclick_reset':'passed','crosshair_status':'passed','current_historical_template_switch':'passed','search_and_empty_state':'passed','representative_charts':len(ids),'mobile':'passed','first':first,'drag_after':drag,'zoom_after':zoom,'reset':reset,'errors':errors}
 (O/'browser_validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(json.dumps(result,ensure_ascii=False,indent=2));b.close()
